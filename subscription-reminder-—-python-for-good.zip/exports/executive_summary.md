# Subscription Reminder — Executive Summary Report

- **Generated:** 2026-11-24
- **Total Active Records:** 36
- **Normalized Monthly Spend:** $756.52
- **Annualized Projection:** $9,078.25
- **Budget Limit ($450.00/mo):** 168.1% utilized
- **Average / Median Monthly Cost:** $21.01 / $12.00

## Threshold Warning Indicators

- **[CRITICAL] Monthly Budget Limit Breached**: Normalized monthly spend ($756.52) exceeds your $450.00 ceiling by $306.52.
- **[CRITICAL] 3 Overdue Renewals Detected**: Unresolved renewals totaling $102.44 (Adobe Creative Cloud, AWS Personal Sandbox, The Economist Digital).
- **[WARNING] 4 High-Cost Outliers Flagged**: Exceeds 2.5x average monthly cost ($52.54): Adobe Creative Cloud ($59.99/mo), Coursera Plus ($59.00/mo), Fresh Meal Prep Box ($62.83/mo), Enterprise Lab Suite ($185.00/mo).
- **[WARNING] 7 Renewals Due Within 7 Days**: Upcoming charges totaling $142.48 requiring review.

## Category Spend Breakdown

| Category | Count | Monthly Equivalent | Annual Projection | Share |
| --- | ---: | ---: | ---: | ---: |
| Cloud & Dev | 10 | $276.52 | $3,318.22 | 36.6% |
| Education | 3 | $117.75 | $1,413.00 | 15.6% |
| Productivity | 5 | $114.99 | $1,379.88 | 15.2% |
| Utilities | 3 | $90.25 | $1,083.00 | 11.9% |
| Fitness & Health | 3 | $47.32 | $567.87 | 6.3% |
| News & Reading | 5 | $45.16 | $541.88 | 6.0% |
| Streaming & Media | 3 | $40.47 | $485.64 | 5.3% |
| Security & VPN | 4 | $24.06 | $288.76 | 3.2% |

## Subscription Ledger

| Name | Category | Cycle | Cost | Renewal Date | Status |
| --- | --- | --- | ---: | --- | --- |
| Adobe Creative Cloud | Productivity | Monthly | $59.99 | 2026-11-13 | Overdue (11d) |
| AWS Personal Sandbox | Cloud & Dev | Monthly | $18.45 | 2026-11-20 | Overdue (4d) |
| The Economist Digital | News & Reading | Monthly | $24.00 | 2026-11-23 | Overdue (1d) |
| GitHub Copilot Pro | Cloud & Dev | Monthly | $10.00 | 2026-11-24 | Due Today |
| Spotify Duo | Streaming & Media | Monthly | $16.99 | 2026-11-26 | Due Soon (2d) |
| Coursera Plus | Education | Monthly | $59.00 | 2026-11-27 | Due Soon (3d) |
| Fresh Meal Prep Box | Utilities | Weekly | $14.50 | 2026-11-28 | Due Soon (4d) |
| Notion Plus | Productivity | Monthly | $12.00 | 2026-11-29 | Due Soon (5d) |
| Proton VPN Plus | Security & VPN | Monthly | $9.99 | 2026-11-30 | Due Soon (6d) |
| Vercel Pro Hosting | Cloud & Dev | Monthly | $20.00 | 2026-12-01 | Due Soon (7d) |
| Local Bike Share Pass | Utilities | Weekly | $5.00 | 2026-12-03 | Active (9d) |
| Netflix Standard | Streaming & Media | Monthly | $15.49 | 2026-12-04 | Active (10d) |
| iCloud+ 200GB | Cloud & Dev | Monthly | $2.99 | 2026-12-06 | Active (12d) |
| Google One 100GB | Cloud & Dev | Monthly | $1.99 | 2026-12-08 | Active (14d) |
| ChatGPT Plus | Productivity | Monthly | $20.00 | 2026-12-09 | Active (15d) |
| 1Password Families | Security & VPN | Monthly | $4.99 | 2026-12-10 | Active (16d) |
| Enterprise Lab Suite | Cloud & Dev | Monthly | $185.00 | 2026-12-11 | Active (17d) |
| Campus Gym Membership | Fitness & Health | Monthly | $34.50 | 2026-12-12 | Active (18d) |
| Figma Professional | Productivity | Monthly | $15.00 | 2026-12-13 | Active (19d) |
| Micro Archive Tier | Cloud & Dev | Monthly | $0.99 | 2026-12-14 | Active (20d) |
| YouTube Premium Student | Streaming & Media | Monthly | $7.99 | 2026-12-15 | Active (21d) |
| Strava Summit | Fitness & Health | Monthly | $11.99 | 2026-12-16 | Active (22d) |
| NYTimes Academic | News & Reading | Monthly | $4.00 | 2026-12-18 | Active (24d) |
| Headspace Student | Fitness & Health | Annual | $9.99 | 2026-12-20 | Active (26d) |
| DigitalOcean Droplet | Cloud & Dev | Monthly | $12.00 | 2026-12-22 | Active (28d) |
| Linear Standard | Productivity | Monthly | $8.00 | 2026-12-23 | Active (29d) |
| O Reilly Learning | Education | Quarterly | $139.00 | 2026-12-27 | Active (33d) |
| Substack Tech Newsletter | News & Reading | Quarterly | $15.00 | 2027-01-04 | Active (41d) |
| JetBrains All Products | Cloud & Dev | Annual | $289.00 | 2027-01-08 | Active (45d) |
| Readwise Reader | News & Reading | Quarterly | $23.97 | 2027-01-15 | Active (52d) |
| Cloudflare Registrar (.dev) | Cloud & Dev | Annual | $12.18 | 2027-01-21 | Active (58d) |
| Medium Membership | News & Reading | Annual | $50.00 | 2027-01-27 | Active (64d) |
| Backblaze B2 Backup | Security & VPN | Annual | $99.00 | 2027-02-04 | Active (72d) |
| Bitwarden Premium | Security & VPN | Annual | $10.00 | 2027-02-20 | Active (88d) |
| Amazon Prime Student | Utilities | Annual | $69.00 | 2027-02-28 | Active (96d) |
| DataCamp Annual | Education | Annual | $149.00 | 2027-03-16 | Active (112d) |