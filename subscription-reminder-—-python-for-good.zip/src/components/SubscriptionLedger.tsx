import {
  AlertTriangle,
  ArrowUpDown,
  ChevronLeft,
  ChevronRight,
  Pencil,
  Plus,
  RefreshCw,
  Search,
  Trash2,
} from 'lucide-react';
import { useMemo, useState } from 'react';
import {
  SUBSCRIPTION_CATEGORIES,
  type EnrichedSubscription,
  type RenewalStatus,
  type SubscriptionRecord,
  type ThresholdSettings,
} from '../types/subscription';
import { formatCurrency } from '../utils/analytics';

interface SubscriptionLedgerProps {
  enriched: EnrichedSubscription[];
  settings: ThresholdSettings;
  onAdd: () => void;
  onEdit: (record: SubscriptionRecord) => void;
  onDelete: (id: string) => Promise<void>;
  onMarkRenewed: (record: EnrichedSubscription) => Promise<void>;
}

type SortField = 'renewalDate' | 'cost' | 'monthlyEquivalent' | 'name';

export function SubscriptionLedger({
  enriched,
  settings,
  onAdd,
  onEdit,
  onDelete,
  onMarkRenewed,
}: SubscriptionLedgerProps) {
  const [searchQuery, setSearchQuery] = useState('');
  const [selectedCategory, setSelectedCategory] = useState<string>('All');
  const [statusFilter, setStatusFilter] = useState<'All' | RenewalStatus>('All');
  const [sortField, setSortField] = useState<SortField>('renewalDate');
  const [sortAsc, setSortAsc] = useState(true);
  const [pageSize, setPageSize] = useState<number>(10);
  const [currentPage, setCurrentPage] = useState<number>(1);
  const [busyId, setBusyId] = useState<string | null>(null);

  const filtered = useMemo(() => {
    const q = searchQuery.trim().toLowerCase();
    return enriched
      .filter((item) => {
        if (selectedCategory !== 'All' && item.category !== selectedCategory) return false;
        if (statusFilter !== 'All' && item.status !== statusFilter) return false;
        if (!q) return true;
        return (
          item.name.toLowerCase().includes(q) ||
          item.category.toLowerCase().includes(q) ||
          (item.notes ?? '').toLowerCase().includes(q) ||
          item.billingCycle.toLowerCase().includes(q)
        );
      })
      .sort((a, b) => {
        let cmp = 0;
        if (sortField === 'name') {
          cmp = a.name.localeCompare(b.name);
        } else if (sortField === 'cost') {
          cmp = a.cost - b.cost;
        } else if (sortField === 'monthlyEquivalent') {
          cmp = a.monthlyEquivalent - b.monthlyEquivalent;
        } else {
          cmp = a.renewalDate.localeCompare(b.renewalDate);
        }
        return sortAsc ? cmp : -cmp;
      });
  }, [enriched, searchQuery, selectedCategory, statusFilter, sortField, sortAsc]);

  const totalPages = pageSize === 0 ? 1 : Math.max(1, Math.ceil(filtered.length / pageSize));
  const safePage = Math.min(currentPage, totalPages);
  const visibleRows =
    pageSize === 0
      ? filtered
      : filtered.slice((safePage - 1) * pageSize, safePage * pageSize);

  const toggleSort = (field: SortField) => {
    if (sortField === field) {
      setSortAsc(!sortAsc);
    } else {
      setSortField(field);
      setSortAsc(true);
    }
    setCurrentPage(1);
  };

  const handleDelete = async (id: string) => {
    setBusyId(id);
    try {
      await onDelete(id);
    } finally {
      setBusyId(null);
    }
  };

  const handleRenew = async (item: EnrichedSubscription) => {
    setBusyId(item.id);
    try {
      await onMarkRenewed(item);
    } finally {
      setBusyId(null);
    }
  };

  return (
    <div className="space-y-4">
      <div className="bg-[#101827] border border-slate-800 rounded-xl p-4 flex flex-col lg:flex-row lg:items-center lg:justify-between gap-3">
        <div className="flex flex-wrap items-center gap-3 flex-1">
          <div className="relative flex-1 min-w-[220px] max-w-sm">
            <Search className="w-4 h-4 text-slate-500 absolute left-3 top-1/2 -translate-y-1/2 pointer-events-none" />
            <input
              type="text"
              value={searchQuery}
              onChange={(e) => {
                setSearchQuery(e.target.value);
                setCurrentPage(1);
              }}
              placeholder="Search name, category, or notes..."
              className="w-full pl-9 pr-3 py-2 text-sm rounded-lg border border-slate-700 bg-[#0B111C] text-slate-100 placeholder-slate-500 focus:outline-none focus:ring-2 focus:ring-teal-500/30 focus:border-teal-500"
            />
          </div>

          <select
            aria-label="Filter by category"
            value={selectedCategory}
            onChange={(e) => {
              setSelectedCategory(e.target.value);
              setCurrentPage(1);
            }}
            className="px-3 py-2 text-sm rounded-lg border border-slate-700 bg-[#0B111C] text-slate-200 focus:outline-none focus:ring-2 focus:ring-teal-500/30"
          >
            <option value="All">All Categories</option>
            {SUBSCRIPTION_CATEGORIES.map((cat) => (
              <option key={cat} value={cat}>
                {cat}
              </option>
            ))}
          </select>

          <div className="flex items-center gap-1 p-1 bg-[#0B111C] border border-slate-800 rounded-lg">
            {(['All', 'Overdue', 'Due Soon', 'Active'] as const).map((status) => (
              <button
                key={status}
                type="button"
                onClick={() => {
                  setStatusFilter(status);
                  setCurrentPage(1);
                }}
                className={`px-3 py-1 text-xs font-medium rounded-md transition-colors whitespace-nowrap ${
                  statusFilter === status
                    ? 'bg-teal-500 text-slate-950 font-semibold'
                    : 'text-slate-400 hover:text-slate-100'
                }`}
              >
                {status}
              </button>
            ))}
          </div>
        </div>

        <button
          type="button"
          onClick={onAdd}
          className="inline-flex items-center justify-center gap-1.5 px-4 py-2 text-sm font-semibold rounded-lg bg-teal-500 text-slate-950 hover:bg-teal-400 transition-colors whitespace-nowrap shrink-0"
        >
          <Plus className="w-4 h-4" />
          Add Subscription
        </button>
      </div>

      <div className="bg-[#101827] border border-slate-800 rounded-xl overflow-hidden">
        {visibleRows.length === 0 ? (
          <div className="p-12 text-center">
            <p className="text-sm font-medium text-slate-200">No matching subscription records</p>
            <p className="text-xs text-slate-400 mt-1">
              Adjust your search keyword, category, or renewal window filter.
            </p>
          </div>
        ) : (
          <div className="overflow-x-auto">
            <table className="w-full text-left border-collapse">
              <thead>
                <tr className="border-b border-slate-800 bg-[#0B111C] text-xs font-medium text-slate-400">
                  <th className="py-3 px-5">
                    <button
                      type="button"
                      onClick={() => toggleSort('name')}
                      className="inline-flex items-center gap-1 hover:text-slate-100"
                    >
                      Subscription
                      <ArrowUpDown className="w-3 h-3" />
                    </button>
                  </th>
                  <th className="py-3 px-4">Category</th>
                  <th className="py-3 px-4">Cycle</th>
                  <th className="py-3 px-4 text-right">
                    <button
                      type="button"
                      onClick={() => toggleSort('cost')}
                      className="inline-flex items-center gap-1 hover:text-slate-100 ml-auto"
                    >
                      Billed Cost
                      <ArrowUpDown className="w-3 h-3" />
                    </button>
                  </th>
                  <th className="py-3 px-4 text-right">
                    <button
                      type="button"
                      onClick={() => toggleSort('monthlyEquivalent')}
                      className="inline-flex items-center gap-1 hover:text-slate-100 ml-auto"
                    >
                      Monthly Eq.
                      <ArrowUpDown className="w-3 h-3" />
                    </button>
                  </th>
                  <th className="py-3 px-4">
                    <button
                      type="button"
                      onClick={() => toggleSort('renewalDate')}
                      className="inline-flex items-center gap-1 hover:text-slate-100"
                    >
                      Renewal Date
                      <ArrowUpDown className="w-3 h-3" />
                    </button>
                  </th>
                  <th className="py-3 px-4">Status</th>
                  <th className="py-3 px-5 text-right">Actions</th>
                </tr>
              </thead>
              <tbody className="divide-y divide-slate-800/70 text-sm">
                {visibleRows.map((item) => {
                  const isBusy = busyId === item.id;
                  return (
                    <tr key={item.id} className="hover:bg-slate-800/40 transition-colors">
                      <td className="py-3 px-5">
                        <div className="flex items-center gap-1.5 font-medium text-slate-100">
                          <span>{item.name}</span>
                          {item.isAnomaly && (
                            <span
                              title={`Cost outlier (>= ${settings.anomalyMultiplier}x avg)`}
                              className="inline-flex items-center gap-1 text-[11px] font-medium text-amber-400"
                            >
                              <AlertTriangle className="w-3.5 h-3.5" />
                              Outlier
                            </span>
                          )}
                        </div>
                        {item.notes && (
                          <div className="text-xs text-slate-400 truncate max-w-[260px]">
                            {item.notes}
                          </div>
                        )}
                      </td>
                      <td className="py-3 px-4 text-xs text-slate-300 whitespace-nowrap">
                        {item.category}
                      </td>
                      <td className="py-3 px-4 text-xs text-slate-300 whitespace-nowrap">
                        {item.billingCycle}
                        {!item.autoRenew && (
                          <span className="text-slate-500"> · Manual</span>
                        )}
                      </td>
                      <td className="py-3 px-4 text-right font-mono tabular-nums text-slate-100 whitespace-nowrap">
                        {formatCurrency(item.cost, settings.currencySymbol)}
                      </td>
                      <td className="py-3 px-4 text-right font-mono tabular-nums text-slate-400 whitespace-nowrap">
                        {formatCurrency(item.monthlyEquivalent, settings.currencySymbol)}
                      </td>
                      <td className="py-3 px-4 font-mono tabular-nums text-xs text-slate-300 whitespace-nowrap">
                        {item.renewalDate}
                      </td>
                      <td className="py-3 px-4 font-mono tabular-nums text-xs whitespace-nowrap">
                        {item.status === 'Overdue' ? (
                          <span className="text-rose-400 font-semibold">
                            Overdue ({Math.abs(item.daysUntilRenewal)}d)
                          </span>
                        ) : item.status === 'Due Soon' ? (
                          <span className="text-amber-400 font-medium">
                            {item.daysUntilRenewal === 0
                              ? 'Due today'
                              : `Due in ${item.daysUntilRenewal}d`}
                          </span>
                        ) : (
                          <span className="text-emerald-400">
                            Active ({item.daysUntilRenewal}d)
                          </span>
                        )}
                      </td>
                      <td className="py-3 px-5 text-right whitespace-nowrap">
                        <div className="inline-flex items-center gap-1">
                          <button
                            type="button"
                            disabled={isBusy}
                            onClick={() => handleRenew(item)}
                            title="Advance renewal date by one billing cycle"
                            className="p-1.5 rounded-md text-slate-400 hover:text-teal-300 hover:bg-teal-500/15 transition-colors"
                            aria-label={`Renew ${item.name}`}
                          >
                            <RefreshCw className="w-3.5 h-3.5" />
                          </button>
                          <button
                            type="button"
                            disabled={isBusy}
                            onClick={() => onEdit(item)}
                            title="Edit subscription"
                            className="p-1.5 rounded-md text-slate-400 hover:text-slate-100 hover:bg-slate-800 transition-colors"
                            aria-label={`Edit ${item.name}`}
                          >
                            <Pencil className="w-3.5 h-3.5" />
                          </button>
                          <button
                            type="button"
                            disabled={isBusy}
                            onClick={() => handleDelete(item.id)}
                            title="Delete subscription"
                            className="p-1.5 rounded-md text-slate-400 hover:text-rose-400 hover:bg-rose-500/15 transition-colors"
                            aria-label={`Delete ${item.name}`}
                          >
                            <Trash2 className="w-3.5 h-3.5" />
                          </button>
                        </div>
                      </td>
                    </tr>
                  );
                })}
              </tbody>
            </table>
          </div>
        )}

        <div className="px-5 py-3 border-t border-slate-800 bg-[#0B111C] flex flex-wrap items-center justify-between gap-3 text-xs text-slate-400">
          <div className="flex items-center gap-3">
            <span className="font-mono tabular-nums">
              Showing {visibleRows.length} of {filtered.length} matching records
            </span>
            <label className="inline-flex items-center gap-1.5">
              <span>Rows per page:</span>
              <select
                value={pageSize}
                onChange={(e) => {
                  setPageSize(Number(e.target.value));
                  setCurrentPage(1);
                }}
                className="px-2 py-1 rounded border border-slate-700 bg-[#101827] text-slate-200 font-mono"
              >
                <option value={10}>10</option>
                <option value={20}>20</option>
                <option value={0}>All</option>
              </select>
            </label>
          </div>

          {pageSize > 0 && totalPages > 1 && (
            <div className="flex items-center gap-2">
              <button
                type="button"
                disabled={safePage <= 1}
                onClick={() => setCurrentPage((p) => Math.max(1, p - 1))}
                className="p-1.5 rounded-md border border-slate-700 bg-[#101827] text-slate-200 hover:bg-slate-800 disabled:opacity-40"
                aria-label="Previous page"
              >
                <ChevronLeft className="w-3.5 h-3.5" />
              </button>
              <span className="font-mono tabular-nums">
                Page {safePage} / {totalPages}
              </span>
              <button
                type="button"
                disabled={safePage >= totalPages}
                onClick={() => setCurrentPage((p) => Math.min(totalPages, p + 1))}
                className="p-1.5 rounded-md border border-slate-700 bg-[#101827] text-slate-200 hover:bg-slate-800 disabled:opacity-40"
                aria-label="Next page"
              >
                <ChevronRight className="w-3.5 h-3.5" />
              </button>
            </div>
          )}
        </div>
      </div>
    </div>
  );
}
