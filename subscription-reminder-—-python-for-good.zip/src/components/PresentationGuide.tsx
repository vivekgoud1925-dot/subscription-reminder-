import {
  ArrowRight,
  Check,
  CheckCircle2,
  Copy,
  DatabaseBackup,
  Download,
  Play,
  RefreshCw,
  ShieldAlert,
} from 'lucide-react';
import { useState } from 'react';
import {
  PYTHON_MAIN_SOURCE,
  PYTHON_README,
  PYTHON_REQUIREMENTS,
} from '../data/pythonSourceTemplate';
import type { NavView, StorageRecoveryEvent, SubscriptionRecord } from '../types/subscription';
import { serializeRecordsToCsv } from '../utils/analytics';

interface PresentationGuideProps {
  records: SubscriptionRecord[];
  onNavigate: (view: NavView) => void;
  onSeedSampleData: () => Promise<void>;
  onSimulateCorruption: () => Promise<StorageRecoveryEvent | null>;
  onOpenAddModal: () => void;
}

type CodeTab = 'python' | 'readme' | 'requirements' | 'csv' | 'json';

const EMBLEM_IMG = '/src/assets/images/emblem_python_good_1795534388205.jpg';

const PIPELINE_STAGES = [
  { step: '01', title: 'Input Capture', desc: 'CLI prompt, GUI modal, or CSV upload' },
  { step: '02', title: 'Sanitization', desc: 'Whitespace trim & formula neutralization' },
  { step: '03', title: 'Regex & Calendar', desc: 'ISO date validity & cost range checks' },
  { step: '04', title: 'Analytics Engine', desc: 'Monthly normalization & outlier alerts' },
  { step: '05', title: 'Disk Persistence', desc: 'Atomic JSON & CSV sync with recovery' },
];

const BRIEF_MATRIX = [
  { feature: 'Interactive Terminal Interface', type: 'Must-Have', view: 'Interactive Terminal', target: 'terminal' as NavView },
  { feature: 'Defensive Input Validation', type: 'Must-Have', view: 'Terminal & Add Modal', target: 'terminal' as NavView },
  { feature: 'Core Business Logic Engine', type: 'Must-Have', view: 'Workspace Summary', target: 'overview' as NavView },
  { feature: 'Local Data Persistence (JSON/CSV)', type: 'Must-Have', view: 'Disk Storage + Recovery', target: 'exports' as NavView },
  { feature: 'Record Query & Search', type: 'Must-Have', view: 'Records Grid', target: 'ledger' as NavView },
  { feature: 'Executive Summary Generation', type: 'Must-Have', view: 'Workspace Summary', target: 'overview' as NavView },
  { feature: 'Visual Data Plotting', type: 'Must-Have', view: 'Visual Analytics', target: 'analytics' as NavView },
  { feature: 'Multi-Format Summary Export (.md/.txt/.csv)', type: 'Stretch', view: 'Backups & Export', target: 'exports' as NavView },
  { feature: 'Threshold Warning Indicators', type: 'Stretch', view: 'Workspace Summary', target: 'overview' as NavView },
  { feature: 'Interactive GUI + CLI Dual View', type: 'Stretch', view: 'Full Application', target: 'overview' as NavView },
  { feature: 'Bulk CSV Import with Error Logs', type: 'Stretch', view: 'Backups & Export', target: 'exports' as NavView },
];

export function PresentationGuide({
  records,
  onNavigate,
  onSeedSampleData,
  onSimulateCorruption,
  onOpenAddModal,
}: PresentationGuideProps) {
  const [codeTab, setCodeTab] = useState<CodeTab>('python');
  const [copied, setCopied] = useState(false);
  const [actionFeedback, setActionFeedback] = useState<string | null>(null);
  const [emblemFailed, setEmblemFailed] = useState(false);

  const activeSource =
    codeTab === 'python'
      ? PYTHON_MAIN_SOURCE
      : codeTab === 'readme'
      ? PYTHON_README
      : codeTab === 'requirements'
      ? PYTHON_REQUIREMENTS
      : codeTab === 'csv'
      ? serializeRecordsToCsv(records)
      : JSON.stringify(records, null, 2);

  const activeFilename =
    codeTab === 'python'
      ? 'subscription_reminder.py'
      : codeTab === 'readme'
      ? 'README.md'
      : codeTab === 'requirements'
      ? 'requirements.txt'
      : codeTab === 'csv'
      ? 'sample_subscriptions.csv'
      : 'sample_subscriptions.json';

  const handleCopy = async () => {
    await navigator.clipboard.writeText(activeSource);
    setCopied(true);
    setTimeout(() => setCopied(false), 1800);
  };

  const handleDownload = () => {
    const blob = new Blob([activeSource], { type: 'text/plain;charset=utf-8' });
    const url = URL.createObjectURL(blob);
    const a = document.createElement('a');
    a.href = url;
    a.download = activeFilename;
    a.click();
    URL.revokeObjectURL(url);
  };

  const handleSeed = async () => {
    await onSeedSampleData();
    setActionFeedback('Restored 36 curated sample entries (including overdue, due-soon, and boundary edge cases).');
  };

  const handleCorruptionDemo = async () => {
    const event = await onSimulateCorruption();
    setActionFeedback(
      event?.reason ??
        'Simulated corrupted JSON on disk and verified automatic clean template recovery.'
    );
  };

  return (
    <div className="space-y-5">
      <section className="bg-[#101827] border border-slate-800 rounded-xl overflow-hidden grid grid-cols-1 lg:grid-cols-12 items-stretch">
        <div className="lg:col-span-4 bg-slate-900 relative min-h-[200px]">
          {!emblemFailed ? (
            <img
              src={EMBLEM_IMG}
              alt="Geometric interlocking rings sculpture symbolizing automated renewal cycles"
              referrerPolicy="no-referrer"
              onError={() => setEmblemFailed(true)}
              className="w-full h-full object-cover"
            />
          ) : (
            <div className="w-full h-full bg-slate-900 flex items-center justify-center p-6 text-slate-400 text-xs font-medium">
              Project #16 Emblem
            </div>
          )}
        </div>

        <div className="lg:col-span-8 p-5 flex flex-col justify-between gap-4">
          <div>
            <div className="text-xs font-medium text-teal-400">
              System Architecture &amp; Viva Presentation Deck
            </div>
            <h2 className="text-lg font-bold text-slate-100 mt-1">
              Five-Stage Fault-Tolerant Processing Pipeline
            </h2>
            <p className="text-xs text-slate-400 mt-1 leading-relaxed">
              Every subscription record passes through deterministic sanitization, regex validation, and calendar verification before atomic serialization to JSON and CSV.
            </p>
          </div>

          <div className="grid grid-cols-1 sm:grid-cols-5 gap-2.5">
            {PIPELINE_STAGES.map((stage, idx) => (
              <div
                key={stage.step}
                className="p-3 rounded-lg border border-slate-800 bg-[#0B111C] space-y-1 relative"
              >
                <div className="flex items-center justify-between text-[11px] font-mono text-teal-400 font-semibold">
                  <span>{stage.step}</span>
                  {idx < PIPELINE_STAGES.length - 1 && (
                    <ArrowRight className="w-3 h-3 text-slate-600 hidden sm:inline" />
                  )}
                </div>
                <div className="text-xs font-semibold text-slate-100">{stage.title}</div>
                <div className="text-[11px] text-slate-400 leading-snug">{stage.desc}</div>
              </div>
            ))}
          </div>
        </div>
      </section>

      {/* Section 9: Live Presentation Walkthrough */}
      <section className="bg-[#101827] border border-slate-800 rounded-xl p-5 space-y-4">
        <div className="flex flex-wrap items-center justify-between gap-3">
          <div>
            <h2 className="text-sm sm:text-base font-semibold text-slate-100">
              College Presentation Walkthrough (Project #16 Rubric)
            </h2>
            <p className="text-xs text-slate-400 mt-0.5">
              Follow this 4-step live sequence during your college demo to verify every core requirement and stretch feature.
            </p>
          </div>
          <div className="flex flex-wrap items-center gap-2">
            <button
              type="button"
              onClick={handleSeed}
              className="inline-flex items-center gap-1.5 px-3 py-1.5 text-xs font-medium rounded-lg border border-slate-700 bg-[#0B111C] text-slate-200 hover:bg-slate-800 whitespace-nowrap"
            >
              <DatabaseBackup className="w-3.5 h-3.5" />
              Reset 36 Sample Records
            </button>
            <button
              type="button"
              onClick={handleCorruptionDemo}
              className="inline-flex items-center gap-1.5 px-3 py-1.5 text-xs font-medium rounded-lg border border-amber-500/30 bg-amber-500/15 text-amber-300 hover:bg-amber-500/25 whitespace-nowrap"
            >
              <ShieldAlert className="w-3.5 h-3.5" />
              Test Corrupt File Recovery
            </button>
          </div>
        </div>

        {actionFeedback && (
          <div className="p-3 rounded-lg bg-emerald-500/15 border border-emerald-500/30 text-xs text-emerald-300 flex items-center gap-2">
            <CheckCircle2 className="w-4 h-4 shrink-0 text-emerald-400" />
            <span>{actionFeedback}</span>
          </div>
        )}

        <div className="grid grid-cols-1 md:grid-cols-2 gap-3.5">
          <div className="p-4 rounded-lg border border-slate-800 bg-[#0B111C] space-y-2">
            <div className="text-xs font-semibold text-slate-100">
              01. Launch Branded Terminal &amp; Menu
            </div>
            <p className="text-xs text-slate-400 leading-relaxed">
              Open the Interactive Terminal to display the welcome screen, clear numeric menu options, and fixed-width ASCII tabular records.
            </p>
            <button
              type="button"
              onClick={() => onNavigate('terminal')}
              className="inline-flex items-center gap-1.5 text-xs font-medium text-teal-400 hover:text-teal-300"
            >
              <Play className="w-3.5 h-3.5" />
              Open Interactive Terminal
            </button>
          </div>

          <div className="p-4 rounded-lg border border-slate-800 bg-[#0B111C] space-y-2">
            <div className="text-xs font-semibold text-slate-100">
              02. Demonstrate Defensive Input Validation
            </div>
            <p className="text-xs text-slate-400 leading-relaxed">
              Trigger "Test Bad Inputs" in the Add Modal or "Demo Validation Catch" in the Terminal to show blank names, negative costs, and invalid dates like 2026-02-30 being rejected cleanly.
            </p>
            <button
              type="button"
              onClick={onOpenAddModal}
              className="inline-flex items-center gap-1.5 text-xs font-medium text-teal-400 hover:text-teal-300"
            >
              <Play className="w-3.5 h-3.5" />
              Launch Add Modal Validation Demo
            </button>
          </div>

          <div className="p-4 rounded-lg border border-slate-800 bg-[#0B111C] space-y-2">
            <div className="text-xs font-semibold text-slate-100">
              03. Present Analytics &amp; Threshold Warnings
            </div>
            <p className="text-xs text-slate-400 leading-relaxed">
              Show normalized monthly/annual totals, overdue flags, outlier alerts, and the 12-month forecast &amp; quadrant scatter plots.
            </p>
            <button
              type="button"
              onClick={() => onNavigate('analytics')}
              className="inline-flex items-center gap-1.5 text-xs font-medium text-teal-400 hover:text-teal-300"
            >
              <Play className="w-3.5 h-3.5" />
              Open Visual Analytics
            </button>
          </div>

          <div className="p-4 rounded-lg border border-slate-800 bg-[#0B111C] space-y-2">
            <div className="text-xs font-semibold text-slate-100">
              04. Verify Persistence &amp; Multi-Format Exports
            </div>
            <p className="text-xs text-slate-400 leading-relaxed">
              Reload the page or run option [6] in Terminal to prove JSON/CSV disk persistence, then download the Markdown summary or Audit Log.
            </p>
            <button
              type="button"
              onClick={() => onNavigate('exports')}
              className="inline-flex items-center gap-1.5 text-xs font-medium text-teal-400 hover:text-teal-300"
            >
              <RefreshCw className="w-3.5 h-3.5" />
              Inspect Disk Files &amp; Exports
            </button>
          </div>
        </div>
      </section>

      {/* Brief Feature Coverage Matrix */}
      <section className="bg-[#101827] border border-slate-800 rounded-xl overflow-hidden">
        <div className="px-5 py-3.5 border-b border-slate-800">
          <h2 className="text-sm sm:text-base font-semibold text-slate-100">
            Problem Brief Coverage Matrix
          </h2>
        </div>
        <div className="overflow-x-auto">
          <table className="w-full text-left border-collapse text-sm">
            <thead>
              <tr className="border-b border-slate-800 bg-[#0B111C] text-xs font-medium text-slate-400">
                <th className="py-2.5 px-5">Requirement from Brief</th>
                <th className="py-2.5 px-4">Priority</th>
                <th className="py-2.5 px-4">Implementation Location</th>
                <th className="py-2.5 px-5 text-right">Jump</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-slate-800/70 text-xs sm:text-sm">
              {BRIEF_MATRIX.map((row) => (
                <tr key={row.feature} className="hover:bg-slate-800/40">
                  <td className="py-2.5 px-5 font-medium text-slate-100">{row.feature}</td>
                  <td className="py-2.5 px-4 text-slate-400">{row.type}</td>
                  <td className="py-2.5 px-4 text-slate-300">{row.view}</td>
                  <td className="py-2.5 px-5 text-right">
                    <button
                      type="button"
                      onClick={() => onNavigate(row.target)}
                      className="text-xs font-medium text-teal-400 hover:text-teal-300"
                    >
                      Open View
                    </button>
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      </section>

      {/* Downloadable Python 3.10+ Source Code for Submission */}
      <section className="bg-[#101827] border border-slate-800 rounded-xl overflow-hidden">
        <div className="px-5 py-3.5 border-b border-slate-800 flex flex-wrap items-center justify-between gap-3">
          <div>
            <h2 className="text-sm sm:text-base font-semibold text-slate-100">
              Submission-Ready Python 3.10+ Source &amp; Sample Datasets
            </h2>
            <p className="text-xs text-slate-400 mt-0.5">
              Download the standalone Python script, README, and 36-entry JSON/CSV datasets for your college repository or lab viva.
            </p>
          </div>

          <div className="flex flex-wrap items-center gap-2">
            <div className="flex items-center gap-1 p-1 bg-[#0B111C] border border-slate-800 rounded-lg">
              {(
                [
                  { id: 'python', label: 'subscription_reminder.py' },
                  { id: 'readme', label: 'README.md' },
                  { id: 'requirements', label: 'requirements.txt' },
                  { id: 'csv', label: 'sample.csv' },
                  { id: 'json', label: 'sample.json' },
                ] as const
              ).map((tab) => (
                <button
                  key={tab.id}
                  type="button"
                  onClick={() => setCodeTab(tab.id)}
                  className={`px-2.5 py-1 text-xs font-medium rounded-md transition-colors whitespace-nowrap ${
                    codeTab === tab.id
                      ? 'bg-teal-500 text-slate-950 font-semibold'
                      : 'text-slate-400 hover:text-slate-100'
                  }`}
                >
                  {tab.label}
                </button>
              ))}
            </div>

            <button
              type="button"
              onClick={handleCopy}
              className="inline-flex items-center gap-1.5 px-3 py-1.5 text-xs font-medium rounded-lg border border-slate-700 bg-[#0B111C] text-slate-200 hover:bg-slate-800 whitespace-nowrap"
            >
              {copied ? <Check className="w-3.5 h-3.5 text-emerald-400" /> : <Copy className="w-3.5 h-3.5" />}
              {copied ? 'Copied' : 'Copy'}
            </button>
            <button
              type="button"
              onClick={handleDownload}
              className="inline-flex items-center gap-1.5 px-3 py-1.5 text-xs font-semibold rounded-lg bg-teal-500 text-slate-950 hover:bg-teal-400 whitespace-nowrap"
            >
              <Download className="w-3.5 h-3.5" />
              Download {activeFilename}
            </button>
          </div>
        </div>

        <pre className="p-5 bg-[#060A12] text-slate-200 text-xs font-mono leading-relaxed overflow-x-auto max-h-[420px]">
          {activeSource}
        </pre>
      </section>
    </div>
  );
}
