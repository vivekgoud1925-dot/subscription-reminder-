import {
  BarChart3,
  BookOpen,
  Database,
  FileSpreadsheet,
  LayoutDashboard,
  ListChecks,
  Sparkles,
  Terminal,
  X,
} from 'lucide-react';
import type { DiskStats, NavView } from '../types/subscription';

interface SidebarProps {
  activeView: NavView;
  onSelectView: (view: NavView) => void;
  totalCount: number;
  overdueCount: number;
  diskStats: DiskStats;
  mobileOpen: boolean;
  onCloseMobile: () => void;
}

const NAV_ITEMS: Array<{
  id: NavView;
  label: string;
  icon: typeof LayoutDashboard;
}> = [
  { id: 'overview', label: 'Workspace', icon: LayoutDashboard },
  { id: 'animation', label: 'Live Animation', icon: Sparkles },
  { id: 'ledger', label: 'Records Grid', icon: ListChecks },
  { id: 'terminal', label: 'CLI Terminal', icon: Terminal },
  { id: 'analytics', label: 'Analytics', icon: BarChart3 },
  { id: 'exports', label: 'Backups & Export', icon: FileSpreadsheet },
  { id: 'presentation', label: 'Demo & Python', icon: BookOpen },
];

function formatBytes(bytes: number): string {
  if (bytes < 1024) return `${bytes} B`;
  return `${(bytes / 1024).toFixed(1)} KB`;
}

export function Sidebar({
  activeView,
  onSelectView,
  totalCount,
  overdueCount,
  diskStats,
  mobileOpen,
  onCloseMobile,
}: SidebarProps) {
  const navContent = (
    <div className="flex h-full flex-col justify-between bg-[#0B111C] text-slate-200 w-[216px] border-r border-slate-800/90 select-none">
      <div>
        <div className="flex items-center justify-between px-4 h-[52px] border-b border-slate-800/90">
          <div className="flex items-center gap-2.5 min-w-0">
            <div className="w-6 h-6 rounded-md bg-teal-500 flex items-center justify-center text-slate-950 text-xs font-bold shrink-0">
              SR
            </div>
            <span className="font-semibold text-sm tracking-tight text-slate-50 truncate">
              SubReminder
            </span>
          </div>
          <button
            type="button"
            onClick={onCloseMobile}
            className="lg:hidden p-1.5 rounded-lg text-slate-400 hover:text-white hover:bg-slate-800"
            aria-label="Close navigation menu"
          >
            <X className="w-4 h-4" />
          </button>
        </div>

        <div className="px-2.5 py-3">
          <nav className="space-y-0.5" aria-label="Application modules">
            {NAV_ITEMS.map((item) => {
              const Icon = item.icon;
              const isActive = activeView === item.id;
              return (
                <button
                  key={item.id}
                  type="button"
                  onClick={() => {
                    onSelectView(item.id);
                    onCloseMobile();
                  }}
                  className={`w-full flex items-center justify-between px-3 py-2 rounded-lg text-[13px] font-medium transition-colors whitespace-nowrap ${
                    isActive
                      ? 'bg-teal-500/15 text-teal-300 border border-teal-500/30'
                      : 'text-slate-400 hover:text-slate-100 hover:bg-slate-800/70 border border-transparent'
                  }`}
                >
                  <span className="flex items-center gap-2.5 min-w-0">
                    <Icon
                      className={`w-4 h-4 shrink-0 ${
                        isActive ? 'text-teal-400' : 'text-slate-500'
                      }`}
                    />
                    <span className="truncate">{item.label}</span>
                  </span>
                  <span className="flex items-center gap-1.5 font-mono tabular-nums text-[11px]">
                    {item.id === 'ledger' && (
                      <span className={isActive ? 'text-teal-300' : 'text-slate-500'}>
                        {totalCount}
                      </span>
                    )}
                    {item.id === 'overview' && overdueCount > 0 && (
                      <span className="text-rose-400 font-semibold">{overdueCount}</span>
                    )}
                  </span>
                </button>
              );
            })}
          </nav>
        </div>
      </div>

      <div className="p-3.5 m-2.5 rounded-lg bg-[#101827] border border-slate-800 text-xs space-y-2">
        <div className="flex items-center gap-1.5 font-medium text-slate-200">
          <Database className="w-3.5 h-3.5 text-teal-400 shrink-0" />
          <span>Backend Disk Engine</span>
        </div>
        <div className="space-y-1 font-mono tabular-nums text-[11px] text-slate-400">
          <div className="flex justify-between">
            <span>subscriptions.json</span>
            <span className="text-slate-200">{formatBytes(diskStats.jsonBytes)}</span>
          </div>
          <div className="flex justify-between">
            <span>subscriptions.csv</span>
            <span className="text-slate-200">{formatBytes(diskStats.csvBytes)}</span>
          </div>
          <div className="flex justify-between">
            <span>Snapshots / Audit</span>
            <span className="text-slate-200">
              {diskStats.backupCount} · {formatBytes(diskStats.auditLogBytes)}
            </span>
          </div>
        </div>
      </div>
    </div>
  );

  return (
    <>
      <aside className="hidden lg:block shrink-0 h-full">
        {navContent}
      </aside>

      {mobileOpen && (
        <div className="fixed inset-0 z-50 lg:hidden flex">
          <div
            className="fixed inset-0 bg-black/60"
            onClick={onCloseMobile}
            aria-hidden="true"
          />
          <div className="relative z-10 h-full">{navContent}</div>
        </div>
      )}
    </>
  );
}
