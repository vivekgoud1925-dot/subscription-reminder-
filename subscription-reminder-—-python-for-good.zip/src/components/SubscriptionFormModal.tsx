import { AlertCircle, CheckCircle2, ShieldCheck, X } from 'lucide-react';
import { useEffect, useMemo, useState } from 'react';
import {
  BILLING_CYCLES,
  SUBSCRIPTION_CATEGORIES,
  type SubscriptionInput,
  type SubscriptionRecord,
} from '../types/subscription';
import { validateSubscriptionInput } from '../utils/validation';

interface SubscriptionFormModalProps {
  open: boolean;
  editingRecord: SubscriptionRecord | null;
  onClose: () => void;
  onSubmit: (input: SubscriptionInput, editingId?: string) => Promise<void>;
}

const DEFAULT_FORM: SubscriptionInput = {
  name: '',
  category: 'Cloud & Dev',
  cost: '',
  billingCycle: 'Monthly',
  renewalDate: new Date(Date.now() + 14 * 86400000).toISOString().slice(0, 10),
  autoRenew: true,
  notes: '',
};

export function SubscriptionFormModal({
  open,
  editingRecord,
  onClose,
  onSubmit,
}: SubscriptionFormModalProps) {
  const [form, setForm] = useState<SubscriptionInput>(DEFAULT_FORM);
  const [touched, setTouched] = useState(false);
  const [submitting, setSubmitting] = useState(false);
  const [serverError, setServerError] = useState<string | null>(null);

  useEffect(() => {
    if (!open) return;
    if (editingRecord) {
      setForm({
        name: editingRecord.name,
        category: editingRecord.category,
        cost: editingRecord.cost.toFixed(2),
        billingCycle: editingRecord.billingCycle,
        renewalDate: editingRecord.renewalDate,
        autoRenew: editingRecord.autoRenew,
        notes: editingRecord.notes ?? '',
      });
    } else {
      setForm({
        ...DEFAULT_FORM,
        renewalDate: new Date(Date.now() + 14 * 86400000).toISOString().slice(0, 10),
      });
    }
    setTouched(false);
    setServerError(null);
  }, [open, editingRecord]);

  const validation = useMemo(() => validateSubscriptionInput(form), [form]);

  if (!open) return null;

  const handleFillInvalidDemo = () => {
    setTouched(true);
    setForm({
      name: '   12345   ',
      category: 'Cloud & Dev',
      cost: '-49.99',
      billingCycle: 'Monthly',
      renewalDate: '2026-02-30',
      autoRenew: true,
      notes: 'Demonstrating defensive validation errors',
    });
  };

  const handleFillValidDemo = () => {
    setTouched(true);
    setForm({
      name: '  Linear   Workspace  ',
      category: 'Productivity',
      cost: '$16.00',
      billingCycle: 'Monthly',
      renewalDate: new Date(Date.now() + 5 * 86400000).toISOString().slice(0, 10),
      autoRenew: true,
      notes: 'Sanitizes whitespace and dollar symbol automatically',
    });
  };

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    setTouched(true);
    setServerError(null);
    if (!validation.valid) return;

    try {
      setSubmitting(true);
      await onSubmit(form, editingRecord?.id);
      onClose();
    } catch (err) {
      setServerError(err instanceof Error ? err.message : 'Failed to save subscription.');
    } finally {
      setSubmitting(false);
    }
  };

  return (
    <div
      className="fixed inset-0 z-50 flex items-center justify-center bg-black/70 p-4"
      role="dialog"
      aria-modal="true"
      aria-labelledby="sub-modal-title"
    >
      <div className="w-full max-w-2xl bg-[#101827] border border-slate-800 rounded-xl shadow-2xl overflow-hidden">
        <div className="flex items-center justify-between px-6 py-4 border-b border-slate-800">
          <div>
            <h2 id="sub-modal-title" className="text-base font-semibold text-slate-100">
              {editingRecord ? `Edit Subscription — ${editingRecord.name}` : 'Record New Subscription'}
            </h2>
            <p className="text-xs text-slate-400 mt-0.5">
              Real-time sanitization and boundary checks enforce domain integrity before saving.
            </p>
          </div>
          <button
            type="button"
            onClick={onClose}
            className="p-2 rounded-lg text-slate-400 hover:text-slate-100 hover:bg-slate-800 transition-colors"
            aria-label="Close modal"
          >
            <X className="w-4 h-4" />
          </button>
        </div>

        <form onSubmit={handleSubmit} className="p-6 space-y-5">
          {!editingRecord && (
            <div className="flex flex-wrap items-center justify-between gap-2 pb-4 border-b border-slate-800">
              <span className="text-xs font-medium text-slate-300 flex items-center gap-1.5">
                <ShieldCheck className="w-4 h-4 text-teal-400" />
                Quick Presentation Test Presets
              </span>
              <div className="flex items-center gap-2">
                <button
                  type="button"
                  onClick={handleFillInvalidDemo}
                  className="px-3 py-1.5 text-xs font-medium rounded-lg border border-rose-500/30 text-rose-300 bg-rose-500/15 hover:bg-rose-500/25 transition-colors whitespace-nowrap"
                >
                  Test Bad Inputs
                </button>
                <button
                  type="button"
                  onClick={handleFillValidDemo}
                  className="px-3 py-1.5 text-xs font-medium rounded-lg border border-slate-700 text-slate-200 bg-slate-800 hover:bg-slate-700 transition-colors whitespace-nowrap"
                >
                  Test Auto-Sanitize
                </button>
              </div>
            </div>
          )}

          <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
            <div className="sm:col-span-2">
              <label htmlFor="sub-name" className="block text-xs font-medium text-slate-300 mb-1.5">
                Subscription Name
              </label>
              <input
                id="sub-name"
                type="text"
                value={form.name}
                onChange={(e) => {
                  setTouched(true);
                  setForm({ ...form, name: e.target.value });
                }}
                placeholder="e.g., GitHub Copilot Pro"
                className={`w-full px-3.5 py-2 text-sm rounded-lg border bg-[#0B111C] text-slate-100 placeholder-slate-500 focus:outline-none focus:ring-2 ${
                  touched && validation.errors.name
                    ? 'border-rose-500/60 focus:ring-rose-500/30'
                    : 'border-slate-700 focus:ring-teal-500/30 focus:border-teal-500'
                }`}
              />
              {touched && validation.errors.name && (
                <p className="mt-1 text-xs text-rose-400 flex items-center gap-1">
                  <AlertCircle className="w-3.5 h-3.5 shrink-0" />
                  {validation.errors.name}
                </p>
              )}
            </div>

            <div>
              <label htmlFor="sub-cost" className="block text-xs font-medium text-slate-300 mb-1.5">
                Expected Cost (USD)
              </label>
              <input
                id="sub-cost"
                type="text"
                value={form.cost}
                onChange={(e) => {
                  setTouched(true);
                  setForm({ ...form, cost: e.target.value });
                }}
                placeholder="e.g., 14.99"
                className={`w-full px-3.5 py-2 text-sm font-mono tabular-nums rounded-lg border bg-[#0B111C] text-slate-100 placeholder-slate-500 focus:outline-none focus:ring-2 ${
                  touched && validation.errors.cost
                    ? 'border-rose-500/60 focus:ring-rose-500/30'
                    : 'border-slate-700 focus:ring-teal-500/30 focus:border-teal-500'
                }`}
              />
              {touched && validation.errors.cost && (
                <p className="mt-1 text-xs text-rose-400 flex items-center gap-1">
                  <AlertCircle className="w-3.5 h-3.5 shrink-0" />
                  {validation.errors.cost}
                </p>
              )}
            </div>

            <div>
              <label htmlFor="sub-date" className="block text-xs font-medium text-slate-300 mb-1.5">
                Renewal Date (YYYY-MM-DD)
              </label>
              <input
                id="sub-date"
                type="text"
                value={form.renewalDate}
                onChange={(e) => {
                  setTouched(true);
                  setForm({ ...form, renewalDate: e.target.value });
                }}
                placeholder="2026-12-15"
                className={`w-full px-3.5 py-2 text-sm font-mono tabular-nums rounded-lg border bg-[#0B111C] text-slate-100 placeholder-slate-500 focus:outline-none focus:ring-2 ${
                  touched && validation.errors.renewalDate
                    ? 'border-rose-500/60 focus:ring-rose-500/30'
                    : 'border-slate-700 focus:ring-teal-500/30 focus:border-teal-500'
                }`}
              />
              {touched && validation.errors.renewalDate && (
                <p className="mt-1 text-xs text-rose-400 flex items-center gap-1">
                  <AlertCircle className="w-3.5 h-3.5 shrink-0" />
                  {validation.errors.renewalDate}
                </p>
              )}
            </div>

            <div>
              <label htmlFor="sub-cycle" className="block text-xs font-medium text-slate-300 mb-1.5">
                Billing Cycle
              </label>
              <select
                id="sub-cycle"
                value={form.billingCycle}
                onChange={(e) => setForm({ ...form, billingCycle: e.target.value })}
                className="w-full px-3.5 py-2 text-sm rounded-lg border border-slate-700 bg-[#0B111C] text-slate-100 focus:outline-none focus:ring-2 focus:ring-teal-500/30"
              >
                {BILLING_CYCLES.map((c) => (
                  <option key={c} value={c}>
                    {c}
                  </option>
                ))}
              </select>
            </div>

            <div>
              <label htmlFor="sub-cat" className="block text-xs font-medium text-slate-300 mb-1.5">
                Category
              </label>
              <select
                id="sub-cat"
                value={form.category}
                onChange={(e) => setForm({ ...form, category: e.target.value })}
                className="w-full px-3.5 py-2 text-sm rounded-lg border border-slate-700 bg-[#0B111C] text-slate-100 focus:outline-none focus:ring-2 focus:ring-teal-500/30"
              >
                {SUBSCRIPTION_CATEGORIES.map((c) => (
                  <option key={c} value={c}>
                    {c}
                  </option>
                ))}
              </select>
            </div>

            <div className="sm:col-span-2">
              <label htmlFor="sub-notes" className="block text-xs font-medium text-slate-300 mb-1.5">
                Notes (optional)
              </label>
              <input
                id="sub-notes"
                type="text"
                value={form.notes ?? ''}
                onChange={(e) => setForm({ ...form, notes: e.target.value })}
                placeholder="Billing account, student plan, or cancellation note"
                className="w-full px-3.5 py-2 text-sm rounded-lg border border-slate-700 bg-[#0B111C] text-slate-100 placeholder-slate-500 focus:outline-none focus:ring-2 focus:ring-teal-500/30"
              />
            </div>

            <div className="sm:col-span-2 flex items-center gap-2">
              <input
                id="sub-autorenew"
                type="checkbox"
                checked={form.autoRenew ?? true}
                onChange={(e) => setForm({ ...form, autoRenew: e.target.checked })}
                className="h-4 w-4 rounded border-slate-600 bg-slate-900 text-teal-500 focus:ring-teal-500"
              />
              <label htmlFor="sub-autorenew" className="text-sm text-slate-300">
                Auto-renew enabled
              </label>
            </div>
          </div>

          <div className="pt-3 border-t border-slate-800">
            <p className="text-xs font-medium text-slate-400 mb-2">
              Defensive Validation Checklist
            </p>
            <div className="grid grid-cols-1 sm:grid-cols-2 gap-2">
              {validation.checks.map((chk) => (
                <div key={chk.field} className="flex items-start gap-2 text-xs py-1">
                  {chk.passed ? (
                    <CheckCircle2 className="w-3.5 h-3.5 text-emerald-400 shrink-0 mt-0.5" />
                  ) : (
                    <AlertCircle className="w-3.5 h-3.5 text-rose-400 shrink-0 mt-0.5" />
                  )}
                  <div>
                    <span className="font-medium text-slate-200">{chk.label}: </span>
                    <span className={chk.passed ? 'text-slate-400' : 'text-rose-400'}>
                      {chk.message}
                    </span>
                  </div>
                </div>
              ))}
            </div>
          </div>

          {serverError && (
            <div className="p-3 rounded-lg bg-rose-500/15 border border-rose-500/30 text-xs text-rose-300">
              {serverError}
            </div>
          )}

          <div className="flex items-center justify-end gap-3 pt-2 border-t border-slate-800">
            <button
              type="button"
              onClick={onClose}
              className="px-4 py-2 text-sm font-medium rounded-lg border border-slate-700 text-slate-300 hover:bg-slate-800 transition-colors whitespace-nowrap"
            >
              Cancel
            </button>
            <button
              type="submit"
              disabled={submitting || (touched && !validation.valid)}
              className="px-4 py-2 text-sm font-semibold rounded-lg bg-teal-500 text-slate-950 hover:bg-teal-400 disabled:opacity-50 disabled:cursor-not-allowed transition-colors whitespace-nowrap"
            >
              {submitting
                ? 'Saving to JSON & CSV...'
                : editingRecord
                ? 'Save Changes'
                : 'Save Subscription'}
            </button>
          </div>
        </form>
      </div>
    </div>
  );
}
