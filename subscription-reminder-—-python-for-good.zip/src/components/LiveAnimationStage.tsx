import {
  Database,
  FileText,
  LineChart,
  Maximize2,
  Minimize2,
  Pause,
  Play,
  ShieldCheck,
  Sparkles,
} from 'lucide-react';
import { motion } from 'motion/react';
import { useEffect, useMemo, useRef, useState } from 'react';
import type {
  EnrichedSubscription,
  ExecutiveSummary,
  ThresholdSettings,
} from '../types/subscription';
import { formatCurrency } from '../utils/analytics';
import { AnimatedCounter } from './AnimatedCounter';

type VisualMode = 'solar' | 'radar' | 'wave';

interface LiveAnimationStageProps {
  enriched: EnrichedSubscription[];
  summary: ExecutiveSummary;
  settings: ThresholdSettings;
  isFullscreen?: boolean;
  onToggleFullscreen?: () => void;
}

const STORY_STEPS = [
  {
    step: '01',
    short: 'Input Guard',
    title: 'Defensive Input Validation',
    caption: 'Regex & calendar checks intercept blank names, negative costs, and impossible dates like 2026-02-30.',
    icon: ShieldCheck,
    color: '#2DD4BF',
  },
  {
    step: '02',
    short: 'Disk Engine',
    title: 'Atomic JSON & CSV Persistence',
    caption: 'Synchronizes every change to disk snapshots with automatic recovery from missing or corrupted files.',
    icon: Database,
    color: '#38BDF8',
  },
  {
    step: '03',
    short: 'Outlier Math',
    title: 'Renewal & Anomaly Intelligence',
    caption: 'Normalizes weekly, monthly, quarterly & annual plans while flagging budget breaches and overdue bills.',
    icon: LineChart,
    color: '#FBBF24',
  },
  {
    step: '04',
    short: 'CLI & Export',
    title: 'Multi-Format Reporting Pipeline',
    caption: 'Compiles terminal tables, Markdown executive summaries, audit trails, and interactive cashflow charts.',
    icon: FileText,
    color: '#FB7185',
  },
];

interface StarParticle {
  x: number;
  y: number;
  vx: number;
  vy: number;
  r: number;
  alpha: number;
  hue: string;
}

interface DataPacket {
  hubIndex: number;
  t: number;
  speed: number;
  color: string;
  size: number;
}

interface Shockwave {
  x: number;
  y: number;
  r: number;
  maxR: number;
  alpha: number;
  color: string;
}

export function LiveAnimationStage({
  enriched,
  summary,
  settings,
  isFullscreen = false,
  onToggleFullscreen,
}: LiveAnimationStageProps) {
  const canvasRef = useRef<HTMLCanvasElement>(null);
  const [mode, setMode] = useState<VisualMode>('solar');
  const [paused, setPaused] = useState(false);
  const [stepIdx, setStepIdx] = useState(0);
  const [hoveredId, setHoveredId] = useState<string | null>(null);
  const shockwavesRef = useRef<Shockwave[]>([]);

  // Cycle Project #16 architecture stages smoothly
  useEffect(() => {
    const prefersReduced =
      typeof window !== 'undefined' &&
      window.matchMedia('(prefers-reduced-motion: reduce)').matches;
    if (prefersReduced || paused) return;

    const timer = setInterval(() => {
      setStepIdx((prev) => (prev + 1) % STORY_STEPS.length);
    }, 3400);
    return () => clearInterval(timer);
  }, [paused]);

  // Real-time 60fps HTML5 physics, packet stream, radar beam & cashflow wave canvas
  useEffect(() => {
    const canvas = canvasRef.current;
    if (!canvas) return;
    const ctx = canvas.getContext('2d');
    if (!ctx) return;

    const prefersReduced =
      typeof window !== 'undefined' &&
      window.matchMedia('(prefers-reduced-motion: reduce)').matches;

    let animId = 0;
    let width = 0;
    let height = 0;
    let tick = 0;
    const mouse = { x: -9999, y: -9999 };

    const stars: StarParticle[] = [];
    const packets: DataPacket[] = [];
    const colors = ['#2DD4BF', '#38BDF8', '#FBBF24', '#FB7185'];

    const initEntities = () => {
      stars.length = 0;
      const count = Math.min(85, Math.max(48, Math.floor((width * height) / 11000)));
      for (let i = 0; i < count; i++) {
        stars.push({
          x: Math.random() * width,
          y: Math.random() * height,
          vx: (Math.random() - 0.5) * 0.35,
          vy: (Math.random() - 0.5) * 0.35,
          r: 1 + Math.random() * 1.9,
          alpha: 0.25 + Math.random() * 0.55,
          hue: i % 5 === 0 ? '56, 189, 248' : '45, 212, 191',
        });
      }

      packets.length = 0;
      for (let i = 0; i < 16; i++) {
        const hubIndex = i % 4;
        packets.push({
          hubIndex,
          t: (i / 16) + Math.random() * 0.15,
          speed: 0.004 + Math.random() * 0.0035,
          color: colors[hubIndex],
          size: 2.2 + Math.random() * 1.5,
        });
      }
    };

    const resize = () => {
      const parent = canvas.parentElement;
      if (!parent) return;
      const dpr = Math.min(window.devicePixelRatio || 1, 2);
      width = parent.clientWidth;
      height = parent.clientHeight;
      canvas.width = width * dpr;
      canvas.height = height * dpr;
      canvas.style.width = `${width}px`;
      canvas.style.height = `${height}px`;
      ctx.setTransform(dpr, 0, 0, dpr, 0, 0);
      if (stars.length === 0) initEntities();
    };

    const handleMove = (e: MouseEvent) => {
      const rect = canvas.getBoundingClientRect();
      mouse.x = e.clientX - rect.left;
      mouse.y = e.clientY - rect.top;
    };

    const handleLeave = () => {
      mouse.x = -9999;
      mouse.y = -9999;
    };

    const handleClick = (e: MouseEvent) => {
      const rect = canvas.getBoundingClientRect();
      shockwavesRef.current.push({
        x: e.clientX - rect.left,
        y: e.clientY - rect.top,
        r: 6,
        maxR: Math.min(width, height) * 0.45,
        alpha: 0.85,
        color: '45, 212, 191',
      });
    };

    resize();
    window.addEventListener('resize', resize);
    canvas.addEventListener('mousemove', handleMove);
    canvas.addEventListener('mouseleave', handleLeave);
    canvas.addEventListener('click', handleClick);

    const draw = () => {
      ctx.clearRect(0, 0, width, height);

      const cx = width / 2;
      const cy = height / 2 - 10;

      // Subtle atmospheric radial nebula wash
      const bgGlow = ctx.createRadialGradient(cx, cy, 12, cx, cy, Math.max(width, height) * 0.65);
      bgGlow.addColorStop(0, 'rgba(20, 184, 166, 0.13)');
      bgGlow.addColorStop(0.45, 'rgba(14, 165, 233, 0.05)');
      bgGlow.addColorStop(1, 'rgba(5, 9, 17, 0)');
      ctx.fillStyle = bgGlow;
      ctx.fillRect(0, 0, width, height);

      // Interactive constellation particles
      for (let i = 0; i < stars.length; i++) {
        const p = stars[i];
        if (!paused && !prefersReduced) {
          p.x += p.vx;
          p.y += p.vy;
          if (p.x < 0 || p.x > width) p.vx *= -1;
          if (p.y < 0 || p.y > height) p.vy *= -1;

          const dx = p.x - mouse.x;
          const dy = p.y - mouse.y;
          const distM = Math.hypot(dx, dy);
          if (distM < 130 && distM > 1) {
            p.x += (dx / distM) * 0.85;
            p.y += (dy / distM) * 0.85;
          }
        }

        ctx.beginPath();
        ctx.arc(p.x, p.y, p.r, 0, Math.PI * 2);
        ctx.fillStyle = `rgba(${p.hue}, ${p.alpha})`;
        ctx.fill();

        for (let j = i + 1; j < stars.length; j++) {
          const q = stars[j];
          const d = Math.hypot(p.x - q.x, p.y - q.y);
          if (d < 118) {
            ctx.beginPath();
            ctx.moveTo(p.x, p.y);
            ctx.lineTo(q.x, q.y);
            ctx.strokeStyle = `rgba(45, 212, 191, ${(1 - d / 118) * 0.16})`;
            ctx.lineWidth = 0.8;
            ctx.stroke();
          }
        }
      }

      // 4 Architecture Corner Hubs + Bezier Signal Streams into Central Core
      const padX = Math.max(54, width * 0.11);
      const padY = Math.max(76, height * 0.17);
      const hubs = [
        { x: padX, y: padY, ctrlX: cx * 0.55, ctrlY: padY * 1.35 },
        { x: width - padX, y: padY, ctrlX: width - cx * 0.55, ctrlY: padY * 1.35 },
        { x: width - padX, y: height - padY - 24, ctrlX: width - cx * 0.55, ctrlY: height - padY * 1.2 },
        { x: padX, y: height - padY - 24, ctrlX: cx * 0.55, ctrlY: height - padY * 1.2 },
      ];

      hubs.forEach((h, idx) => {
        ctx.beginPath();
        ctx.moveTo(h.x, h.y);
        ctx.quadraticCurveTo(h.ctrlX, h.ctrlY, cx, cy);
        ctx.strokeStyle =
          idx === stepIdx ? 'rgba(45, 212, 191, 0.34)' : 'rgba(51, 65, 85, 0.25)';
        ctx.lineWidth = idx === stepIdx ? 1.5 : 1;
        ctx.stroke();
      });

      // Animate streaming energy packets along Bezier fibers
      if (mode !== 'wave') {
        packets.forEach((pkt) => {
          if (!paused && !prefersReduced) {
            pkt.t += pkt.speed;
            if (pkt.t >= 1) {
              pkt.t = 0;
              if (pkt.hubIndex === 2 && summary.overdueCount > 0 && Math.random() > 0.55) {
                shockwavesRef.current.push({
                  x: cx,
                  y: cy,
                  r: 22,
                  maxR: Math.min(width, height) * 0.38,
                  alpha: 0.65,
                  color: '251, 113, 133',
                });
              }
            }
          }
          const h = hubs[pkt.hubIndex];
          const t = pkt.t;
          const inv = 1 - t;
          const px = inv * inv * h.x + 2 * inv * t * h.ctrlX + t * t * cx;
          const py = inv * inv * h.y + 2 * inv * t * h.ctrlY + t * t * cy;

          ctx.beginPath();
          ctx.arc(px, py, pkt.size, 0, Math.PI * 2);
          ctx.fillStyle = pkt.color;
          ctx.shadowColor = pkt.color;
          ctx.shadowBlur = 10;
          ctx.fill();
          ctx.shadowBlur = 0;
        });
      }

      // Radar Sweep Beam Mode
      if (mode === 'radar') {
        const angle = (tick * 0.022) % (Math.PI * 2);
        const radius = Math.min(width, height) * 0.37;
        ctx.save();
        ctx.translate(cx, cy);
        ctx.rotate(angle);
        const sweepGrad = ctx.createLinearGradient(0, 0, radius, 0);
        sweepGrad.addColorStop(0, 'rgba(45, 212, 191, 0.02)');
        sweepGrad.addColorStop(1, 'rgba(45, 212, 191, 0.28)');
        ctx.beginPath();
        ctx.moveTo(0, 0);
        ctx.arc(0, 0, radius, -0.45, 0);
        ctx.closePath();
        ctx.fillStyle = sweepGrad;
        ctx.fill();

        ctx.beginPath();
        ctx.moveTo(0, 0);
        ctx.lineTo(radius, 0);
        ctx.strokeStyle = 'rgba(45, 212, 191, 0.85)';
        ctx.lineWidth = 1.8;
        ctx.stroke();
        ctx.restore();
      }

      // Cashflow Harmonic Wave Mode
      if (mode === 'wave') {
        const waveConfigs = [
          { amp: 28, freq: 0.012, speed: 0.032, color: 'rgba(45, 212, 191, 0.55)', yOff: 0 },
          { amp: 20, freq: 0.018, speed: -0.024, color: 'rgba(56, 189, 248, 0.45)', yOff: 18 },
          { amp: 14, freq: 0.025, speed: 0.04, color: 'rgba(251, 191, 36, 0.3)', yOff: -16 },
        ];
        waveConfigs.forEach((wc) => {
          ctx.beginPath();
          for (let x = 0; x <= width; x += 6) {
            const env = Math.sin((x / width) * Math.PI);
            const y =
              cy +
              wc.yOff +
              Math.sin(x * wc.freq + tick * wc.speed) * wc.amp * env +
              Math.cos(x * wc.freq * 0.5 - tick * wc.speed * 0.7) * (wc.amp * 0.4);
            if (x === 0) ctx.moveTo(x, y);
            else ctx.lineTo(x, y);
          }
          ctx.strokeStyle = wc.color;
          ctx.lineWidth = 2;
          ctx.stroke();
        });
      }

      // Periodic automatic ambient pulse from core
      if (!paused && !prefersReduced && tick % 160 === 0) {
        shockwavesRef.current.push({
          x: cx,
          y: cy,
          r: 36,
          maxR: Math.min(width, height) * 0.42,
          alpha: 0.45,
          color: summary.overdueCount > 0 ? '251, 191, 36' : '45, 212, 191',
        });
      }

      // Render & decay expanding shockwaves
      for (let i = shockwavesRef.current.length - 1; i >= 0; i--) {
        const sw = shockwavesRef.current[i];
        if (!paused && !prefersReduced) {
          sw.r += 2.2;
          sw.alpha *= 0.972;
        }
        ctx.beginPath();
        ctx.arc(sw.x, sw.y, sw.r, 0, Math.PI * 2);
        ctx.strokeStyle = `rgba(${sw.color}, ${sw.alpha})`;
        ctx.lineWidth = 1.6;
        ctx.stroke();
        if (sw.r >= sw.maxR || sw.alpha <= 0.02) {
          shockwavesRef.current.splice(i, 1);
        }
      }

      if (!paused && !prefersReduced) {
        tick += 1;
        animId = requestAnimationFrame(draw);
      }
    };

    draw();

    return () => {
      cancelAnimationFrame(animId);
      window.removeEventListener('resize', resize);
      canvas.removeEventListener('mousemove', handleMove);
      canvas.removeEventListener('mouseleave', handleLeave);
      canvas.removeEventListener('click', handleClick);
    };
  }, [mode, paused, stepIdx, summary.overdueCount]);

  // Populate 3 orbital planetary rings with real subscriptions from disk
  const orbitNodes = useMemo(() => {
    const urgent = enriched.filter((r) => r.status === 'Overdue' || r.status === 'Due Soon').slice(0, 5);
    const monthly = enriched.filter((r) => r.status === 'Active' && r.billingCycle === 'Monthly').slice(0, 5);
    const longCycle = enriched
      .filter((r) => r.status === 'Active' && (r.billingCycle === 'Annual' || r.billingCycle === 'Quarterly'))
      .slice(0, 5);

    return {
      inner: urgent.map((item, i) => ({
        item,
        angle: (i * 360) / Math.max(urgent.length, 1),
        radius: 78,
      })),
      middle: monthly.map((item, i) => ({
        item,
        angle: 18 + (i * 360) / Math.max(monthly.length, 1),
        radius: 122,
      })),
      outer: longCycle.map((item, i) => ({
        item,
        angle: 42 + (i * 360) / Math.max(longCycle.length, 1),
        radius: 164,
      })),
    };
  }, [enriched]);

  const activeItem = useMemo(() => {
    if (hoveredId) {
      return enriched.find((r) => r.id === hoveredId) ?? null;
    }
    return enriched[stepIdx % Math.max(enriched.length, 1)] ?? null;
  }, [enriched, hoveredId, stepIdx]);

  const activeStory = STORY_STEPS[stepIdx];
  const StoryIcon = activeStory.icon;

  return (
    <div
      className="relative w-full h-full min-h-[600px] rounded-2xl border border-slate-800/90 bg-[#050911] overflow-hidden select-none shadow-2xl"
      aria-label="Dedicated Project #16 Live Animation Stage"
    >
      {/* Layer 1: Interactive 60fps Canvas Physics, Packets & Waves */}
      <canvas
        ref={canvasRef}
        className="absolute inset-0 w-full h-full cursor-crosshair"
        aria-hidden="true"
      />

      {/* Top Floating Edge HUD (Minimal, Zero Heavy Blocks) */}
      <div className="relative z-20 px-5 pt-4 flex flex-wrap items-center justify-between gap-3 pointer-events-none">
        <div className="pointer-events-auto">
          <div className="flex items-center gap-2 text-xs font-semibold text-teal-400">
            <Sparkles className="w-3.5 h-3.5" />
            <span>Project #16 · Python for Good</span>
          </div>
          <h2 className="text-sm sm:text-base font-semibold text-slate-100 tracking-tight mt-0.5">
            Subscription Reminder Live Engine
          </h2>
        </div>

        {/* Interactive Stage Mode & Playback Controls */}
        <div className="flex items-center gap-1.5 pointer-events-auto bg-[#0B1220]/80 backdrop-blur-md border border-slate-800 rounded-lg p-1">
          {(
            [
              { id: 'solar', label: 'Solar Core' },
              { id: 'radar', label: 'Alert Radar' },
              { id: 'wave', label: 'Cashflow Wave' },
            ] as const
          ).map((tab) => (
            <button
              key={tab.id}
              type="button"
              onClick={() => setMode(tab.id)}
              className={`px-2.5 py-1 text-[11px] font-medium rounded-md transition-colors whitespace-nowrap ${
                mode === tab.id
                  ? 'bg-teal-500 text-slate-950 font-semibold'
                  : 'text-slate-400 hover:text-slate-100'
              }`}
            >
              {tab.label}
            </button>
          ))}

          <span className="w-px h-4 bg-slate-800 mx-0.5" aria-hidden="true" />

          <button
            type="button"
            onClick={() => setPaused((p) => !p)}
            title={paused ? 'Resume animation' : 'Pause animation'}
            className="p-1.5 rounded-md text-slate-300 hover:text-white hover:bg-slate-800 transition-colors"
            aria-label={paused ? 'Play animation' : 'Pause animation'}
          >
            {paused ? <Play className="w-3.5 h-3.5" /> : <Pause className="w-3.5 h-3.5" />}
          </button>

          {onToggleFullscreen && (
            <button
              type="button"
              onClick={onToggleFullscreen}
              title={isFullscreen ? 'Return to split workspace' : 'Expand animation full screen'}
              className="p-1.5 rounded-md text-slate-300 hover:text-teal-300 hover:bg-slate-800 transition-colors"
              aria-label={isFullscreen ? 'Exit full screen' : 'Expand full screen'}
            >
              {isFullscreen ? (
                <Minimize2 className="w-3.5 h-3.5" />
              ) : (
                <Maximize2 className="w-3.5 h-3.5" />
              )}
            </button>
          )}
        </div>
      </div>

      {/* Layer 2: Floating 4 Corner Architecture Nodes (Synchronized with Canvas Packets) */}
      <div className="hidden sm:block pointer-events-none">
        {STORY_STEPS.map((st, idx) => {
          const Icon = st.icon;
          const isCurrent = idx === stepIdx;
          const posClass =
            idx === 0
              ? 'top-[76px] left-5'
              : idx === 1
              ? 'top-[76px] right-5'
              : idx === 2
              ? 'bottom-[104px] right-5'
              : 'bottom-[104px] left-5';

          return (
            <button
              key={st.step}
              type="button"
              onClick={() => setStepIdx(idx)}
              className={`absolute ${posClass} z-20 pointer-events-auto flex items-center gap-2 px-2.5 py-1.5 rounded-lg border backdrop-blur-md transition-all text-left ${
                isCurrent
                  ? 'bg-[#0F1B2E]/90 border-teal-400/60 text-slate-100 scale-105 shadow-lg shadow-teal-500/10'
                  : 'bg-[#09101D]/65 border-slate-800/80 text-slate-400 hover:text-slate-200'
              }`}
            >
              <span
                className="w-6 h-6 rounded-md flex items-center justify-center shrink-0"
                style={{
                  backgroundColor: isCurrent ? st.color : 'rgba(30,41,59,0.8)',
                  color: isCurrent ? '#050911' : st.color,
                }}
              >
                <Icon className="w-3.5 h-3.5" />
              </span>
              <span className="leading-tight">
                <span className="block text-[10px] font-mono text-slate-500">NODE {st.step}</span>
                <span className="block text-xs font-medium whitespace-nowrap">{st.short}</span>
              </span>
            </button>
          );
        })}
      </div>

      {/* Layer 3: Centerpiece Interactive Orbital Solar-Radar Core */}
      <div className="absolute inset-0 z-10 flex items-center justify-center pointer-events-none pb-8">
        <div className="relative w-[360px] h-[360px] sm:w-[390px] sm:h-[390px] flex items-center justify-center">
          {mode !== 'wave' && (
            <svg
              viewBox="0 0 380 380"
              className="w-full h-full overflow-visible"
              aria-label="Interactive orbital subscription system"
            >
              {/* Concentric Orbit Rings */}
              <circle cx="190" cy="190" r="78" fill="none" stroke="rgba(45,212,191,0.18)" strokeDasharray="3 5" />
              <circle cx="190" cy="190" r="122" fill="none" stroke="rgba(56,189,248,0.16)" strokeDasharray="4 5" />
              <circle cx="190" cy="190" r="164" fill="none" stroke="rgba(148,163,184,0.14)" />

              {/* Precision Chronometer Vernier Dial Ticks */}
              <motion.g
                animate={paused ? undefined : { rotate: 360 }}
                transition={{ duration: 90, repeat: Infinity, ease: 'linear' }}
                style={{ transformOrigin: '190px 190px' }}
              >
                {Array.from({ length: 36 }).map((_, i) => {
                  const angle = (i * 10 * Math.PI) / 180;
                  const r1 = 56;
                  const r2 = i % 3 === 0 ? 63 : 59;
                  return (
                    <line
                      key={i}
                      x1={190 + Math.cos(angle) * r1}
                      y1={190 + Math.sin(angle) * r1}
                      x2={190 + Math.cos(angle) * r2}
                      y2={190 + Math.sin(angle) * r2}
                      stroke={i % 3 === 0 ? '#2DD4BF' : '#334155'}
                      strokeWidth={i % 3 === 0 ? 1.4 : 0.8}
                      opacity={0.75}
                    />
                  );
                })}
              </motion.g>

              {/* Inner Ring: Urgent Overdue / Due Soon */}
              <motion.g
                animate={paused ? undefined : { rotate: 360 }}
                transition={{ duration: 28, repeat: Infinity, ease: 'linear' }}
                style={{ transformOrigin: '190px 190px' }}
              >
                {orbitNodes.inner.map(({ item, angle, radius }) => {
                  const rad = (angle * Math.PI) / 180;
                  const px = 190 + Math.cos(rad) * radius;
                  const py = 190 + Math.sin(rad) * radius;
                  const fill = item.status === 'Overdue' ? '#FB7185' : '#FBBF24';
                  const isActive = activeItem?.id === item.id;
                  return (
                    <g
                      key={item.id}
                      className="pointer-events-auto cursor-pointer"
                      onMouseEnter={() => setHoveredId(item.id)}
                      onMouseLeave={() => setHoveredId(null)}
                      onClick={() => setHoveredId(item.id)}
                    >
                      {isActive && (
                        <>
                          <line
                            x1="190"
                            y1="190"
                            x2={px}
                            y2={py}
                            stroke={fill}
                            strokeWidth="1.2"
                            strokeDasharray="3 3"
                            opacity="0.7"
                          />
                          <circle cx={px} cy={py} r="13" fill={fill} opacity="0.22" />
                        </>
                      )}
                      <circle
                        cx={px}
                        cy={py}
                        r={isActive ? 8 : 6}
                        fill={fill}
                        stroke="#050911"
                        strokeWidth="2"
                      />
                    </g>
                  );
                })}
              </motion.g>

              {/* Middle Ring: Monthly Plans */}
              <motion.g
                animate={paused ? undefined : { rotate: -360 }}
                transition={{ duration: 42, repeat: Infinity, ease: 'linear' }}
                style={{ transformOrigin: '190px 190px' }}
              >
                {orbitNodes.middle.map(({ item, angle, radius }) => {
                  const rad = (angle * Math.PI) / 180;
                  const px = 190 + Math.cos(rad) * radius;
                  const py = 190 + Math.sin(rad) * radius;
                  const isActive = activeItem?.id === item.id;
                  return (
                    <g
                      key={item.id}
                      className="pointer-events-auto cursor-pointer"
                      onMouseEnter={() => setHoveredId(item.id)}
                      onMouseLeave={() => setHoveredId(null)}
                      onClick={() => setHoveredId(item.id)}
                    >
                      {isActive && (
                        <>
                          <line
                            x1="190"
                            y1="190"
                            x2={px}
                            y2={py}
                            stroke="#2DD4BF"
                            strokeWidth="1.2"
                            strokeDasharray="3 3"
                            opacity="0.7"
                          />
                          <circle cx={px} cy={py} r="13" fill="#2DD4BF" opacity="0.22" />
                        </>
                      )}
                      <circle
                        cx={px}
                        cy={py}
                        r={isActive ? 8 : 5.8}
                        fill="#2DD4BF"
                        stroke="#050911"
                        strokeWidth="2"
                      />
                    </g>
                  );
                })}
              </motion.g>

              {/* Outer Ring: Annual & Quarterly Plans */}
              <motion.g
                animate={paused ? undefined : { rotate: 360 }}
                transition={{ duration: 60, repeat: Infinity, ease: 'linear' }}
                style={{ transformOrigin: '190px 190px' }}
              >
                {orbitNodes.outer.map(({ item, angle, radius }) => {
                  const rad = (angle * Math.PI) / 180;
                  const px = 190 + Math.cos(rad) * radius;
                  const py = 190 + Math.sin(rad) * radius;
                  const isActive = activeItem?.id === item.id;
                  return (
                    <g
                      key={item.id}
                      className="pointer-events-auto cursor-pointer"
                      onMouseEnter={() => setHoveredId(item.id)}
                      onMouseLeave={() => setHoveredId(null)}
                      onClick={() => setHoveredId(item.id)}
                    >
                      {isActive && (
                        <>
                          <line
                            x1="190"
                            y1="190"
                            x2={px}
                            y2={py}
                            stroke="#38BDF8"
                            strokeWidth="1.2"
                            strokeDasharray="3 3"
                            opacity="0.7"
                          />
                          <circle cx={px} cy={py} r="13" fill="#38BDF8" opacity="0.22" />
                        </>
                      )}
                      <circle
                        cx={px}
                        cy={py}
                        r={isActive ? 8 : 5.5}
                        fill="#38BDF8"
                        stroke="#050911"
                        strokeWidth="2"
                      />
                    </g>
                  );
                })}
              </motion.g>
            </svg>
          )}

          {/* Central Chronometer Core Hub */}
          <motion.div
            animate={paused ? undefined : { scale: [1, 1.03, 1] }}
            transition={{ duration: 3.2, repeat: Infinity, ease: 'easeInOut' }}
            className="absolute w-28 h-28 rounded-full bg-[#091221]/95 border border-teal-400/50 shadow-[0_0_40px_rgba(20,184,166,0.22)] flex flex-col items-center justify-center text-center pointer-events-none"
          >
            <span className="text-[10px] font-medium text-teal-400 tracking-wide">
              MONTHLY FLOW
            </span>
            <span className="text-lg font-bold text-slate-50 font-mono tabular-nums mt-0.5">
              <AnimatedCounter
                value={summary.totalMonthlySpend}
                prefix={settings.currencySymbol}
                decimals={0}
              />
            </span>
            <span className="text-[10px] font-mono tabular-nums text-slate-400 mt-0.5">
              {summary.totalCount} plans · {summary.overdueCount} due
            </span>
          </motion.div>
        </div>
      </div>

      {/* Bottom Floating Glass HUD: Live Spotlight + Auto-Cycling Story Ribbon */}
      <div className="absolute bottom-4 left-4 right-4 z-20 space-y-2 pointer-events-none">
        {activeItem && (
          <div className="flex justify-center">
            <motion.div
              key={activeItem.id}
              initial={{ opacity: 0, y: 4 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ duration: 0.22 }}
              className="pointer-events-auto inline-flex items-center gap-2.5 px-3.5 py-1.5 rounded-lg bg-[#0A1322]/85 backdrop-blur-md border border-slate-800/90 text-xs shadow-lg"
            >
              <span className="font-semibold text-slate-100 truncate max-w-[160px]">
                {activeItem.name}
              </span>
              <span className="text-slate-600" aria-hidden="true">·</span>
              <span className="font-mono tabular-nums text-teal-400">
                {formatCurrency(activeItem.cost, settings.currencySymbol)}/{activeItem.billingCycle}
              </span>
              <span className="text-slate-600" aria-hidden="true">·</span>
              <span
                className={`font-mono ${
                  activeItem.status === 'Overdue'
                    ? 'text-rose-400'
                    : activeItem.status === 'Due Soon'
                    ? 'text-amber-400'
                    : 'text-emerald-400'
                }`}
              >
                {activeItem.status}
              </span>
            </motion.div>
          </div>
        )}

        <div className="pointer-events-auto rounded-xl bg-[#0A1322]/85 backdrop-blur-md border border-slate-800/90 px-4 py-3 shadow-xl">
          <div className="flex items-center justify-between gap-3">
            <div className="flex items-center gap-2.5 min-w-0">
              <div
                className="w-7 h-7 rounded-md flex items-center justify-center shrink-0 text-slate-950"
                style={{ backgroundColor: activeStory.color }}
              >
                <StoryIcon className="w-4 h-4" />
              </div>
              <div className="min-w-0">
                <div className="text-xs font-semibold text-slate-100 truncate">
                  {activeStory.step}. {activeStory.title}
                </div>
                <div className="text-[11px] text-slate-400 truncate">
                  {activeStory.caption}
                </div>
              </div>
            </div>

            <div className="flex items-center gap-1.5 shrink-0">
              {STORY_STEPS.map((st, idx) => (
                <button
                  key={st.step}
                  type="button"
                  onClick={() => setStepIdx(idx)}
                  className={`h-1.5 rounded-full transition-all ${
                    idx === stepIdx ? 'w-6 bg-teal-400' : 'w-2 bg-slate-700 hover:bg-slate-600'
                  }`}
                  aria-label={`Stage ${st.step}: ${st.title}`}
                />
              ))}
            </div>
          </div>
        </div>
      </div>
    </div>
  );
}
