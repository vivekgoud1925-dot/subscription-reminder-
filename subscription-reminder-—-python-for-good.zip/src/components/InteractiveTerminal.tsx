import { Play, RotateCcw, ShieldAlert, Terminal as TerminalIcon } from 'lucide-react';
import { useEffect, useRef, useState } from 'react';
import {
  BILLING_CYCLES,
  SUBSCRIPTION_CATEGORIES,
  type EnrichedSubscription,
  type ExecutiveSummary,
  type StorageRecoveryEvent,
  type SubscriptionInput,
  type ThresholdSettings,
} from '../types/subscription';
import { formatCurrency } from '../utils/analytics';
import {
  isValidCalendarDate,
  matchBillingCycle,
  matchCategory,
  parseCostInput,
  sanitizeText,
} from '../utils/validation';

interface TerminalLine {
  id: string;
  kind: 'system' | 'input' | 'output' | 'error' | 'success' | 'warning' | 'banner';
  text: string;
}

type PromptState =
  | { mode: 'menu' }
  | { mode: 'add_name' }
  | { mode: 'add_cost'; name: string }
  | { mode: 'add_date'; name: string; cost: number }
  | { mode: 'add_cycle'; name: string; cost: number; renewalDate: string }
  | { mode: 'add_category'; name: string; cost: number; renewalDate: string; billingCycle: string }
  | { mode: 'paginate'; page: number; pageSize: number }
  | { mode: 'search' };

interface InteractiveTerminalProps {
  enriched: EnrichedSubscription[];
  summary: ExecutiveSummary;
  settings: ThresholdSettings;
  onCreateRecord: (input: SubscriptionInput) => Promise<void>;
  onReloadFromDisk: () => Promise<StorageRecoveryEvent | null>;
  onSimulateCorruption: () => Promise<StorageRecoveryEvent | null>;
}

const WELCOME_LINES: Array<{ kind: TerminalLine['kind']; text: string }> = [
  { kind: 'banner', text: '+---------------------------------------------------------------------------+' },
  { kind: 'banner', text: '|  PYTHON FOR GOOD  |  PROJECT #16: SUBSCRIPTION REMINDER (CLI v1.0)        |' },
  { kind: 'banner', text: '|  Storage: data/subscriptions.json + data/subscriptions.csv                |' },
  { kind: 'banner', text: '+---------------------------------------------------------------------------+' },
  { kind: 'system', text: 'Loaded local persistence layer cleanly. Type a menu number (0–7) below:' },
  { kind: 'output', text: '  [1] Add Subscription (with Defensive Validation Loop)' },
  { kind: 'output', text: '  [2] View Subscription Table (Fixed-Width + Paginated)' },
  { kind: 'output', text: '  [3] Search & Filter Records by Keyword or Category' },
  { kind: 'output', text: '  [4] Generate Executive Summary & Threshold Warnings' },
  { kind: 'output', text: '  [5] Preview Plain-Text Audit Report' },
  { kind: 'output', text: '  [6] Relaunch Program & Verify Disk Persistence' },
  { kind: 'output', text: '  [7] Simulate Corrupted JSON & Auto-Recovery' },
  { kind: 'output', text: '  [0] Clear Terminal & Show Menu' },
];

export function InteractiveTerminal({
  enriched,
  summary,
  settings,
  onCreateRecord,
  onReloadFromDisk,
  onSimulateCorruption,
}: InteractiveTerminalProps) {
  const [lines, setLines] = useState<TerminalLine[]>(() =>
    WELCOME_LINES.map((l, idx) => ({ id: `init-${idx}`, ...l }))
  );
  const [promptState, setPromptState] = useState<PromptState>({ mode: 'menu' });
  const [inputValue, setInputValue] = useState('');
  const [busy, setBusy] = useState(false);
  const scrollRef = useRef<HTMLDivElement>(null);
  const inputRef = useRef<HTMLInputElement>(null);

  useEffect(() => {
    if (scrollRef.current) {
      scrollRef.current.scrollTop = scrollRef.current.scrollHeight;
    }
  }, [lines]);

  const appendLines = (items: Array<{ kind: TerminalLine['kind']; text: string }>) => {
    setLines((prev) => [
      ...prev,
      ...items.map((item, idx) => ({
        id: `${Date.now()}-${Math.random().toString(36).slice(2, 6)}-${idx}`,
        ...item,
      })),
    ]);
  };

  const showMenu = () => {
    appendLines([
      { kind: 'system', text: '' },
      { kind: 'output', text: '  [1] Add Subscription   [2] View Table   [3] Search   [4] Executive Summary' },
      { kind: 'output', text: '  [5] Audit Report       [6] Relaunch     [7] Corrupt Recovery Test   [0] Clear' },
    ]);
    setPromptState({ mode: 'menu' });
  };

  const renderAsciiTable = (rows: EnrichedSubscription[], page: number, pageSize: number) => {
    const start = page * pageSize;
    const slice = rows.slice(start, start + pageSize);
    const pad = (s: string, w: number, right = false) => {
      const cut = s.length > w ? `${s.slice(0, w - 1)}~` : s;
      return right ? cut.padStart(w, ' ') : cut.padEnd(w, ' ');
    };
    const sep = '+------------------------+-------------------+-----------+----------+------------+------------+';
    const out: Array<{ kind: TerminalLine['kind']; text: string }> = [
      { kind: 'system', text: `Showing rows ${start + 1}–${start + slice.length} of ${rows.length}:` },
      { kind: 'output', text: sep },
      {
        kind: 'banner',
        text: `| ${pad('Name', 22)} | ${pad('Category', 17)} | ${pad('Cycle', 9)} | ${pad('Cost', 8, true)} | ${pad('Renewal', 10)} | ${pad('Status', 10)} |`,
      },
      { kind: 'output', text: sep },
    ];

    for (const r of slice) {
      const statusText =
        r.daysUntilRenewal < 0
          ? `OVERDUE`
          : r.daysUntilRenewal <= settings.dueSoonDays
          ? `DUE ${r.daysUntilRenewal}d`
          : `IN ${r.daysUntilRenewal}d`;
      const kind: TerminalLine['kind'] =
        r.daysUntilRenewal < 0 ? 'error' : r.daysUntilRenewal <= settings.dueSoonDays ? 'warning' : 'output';
      out.push({
        kind,
        text: `| ${pad(r.name, 22)} | ${pad(r.category, 17)} | ${pad(r.billingCycle, 9)} | ${pad(
          formatCurrency(r.cost, settings.currencySymbol),
          8,
          true
        )} | ${pad(r.renewalDate, 10)} | ${pad(statusText, 10)} |`,
      });
    }
    out.push({ kind: 'output', text: sep });
    appendLines(out);

    if (start + pageSize < rows.length) {
      appendLines([{ kind: 'system', text: "Press Enter for next page, or type 'q' to return to menu:" }]);
      setPromptState({ mode: 'paginate', page: page + 1, pageSize });
    } else {
      showMenu();
    }
  };

  const executeCommand = async (rawCommand: string) => {
    if (busy) return;
    const raw = rawCommand;
    const trimmed = raw.trim();

    const promptLabel =
      promptState.mode === 'menu'
        ? 'menu>'
        : promptState.mode === 'add_name'
        ? 'name>'
        : promptState.mode === 'add_cost'
        ? 'cost>'
        : promptState.mode === 'add_date'
        ? 'date>'
        : promptState.mode === 'add_cycle'
        ? 'cycle>'
        : promptState.mode === 'add_category'
        ? 'category>'
        : promptState.mode === 'paginate'
        ? 'page>'
        : 'search>';

    appendLines([{ kind: 'input', text: `${promptLabel} ${raw}` }]);

    if (trimmed.toLowerCase() === 'cancel' && promptState.mode !== 'menu') {
      appendLines([{ kind: 'warning', text: 'Action cancelled. Returning to main menu.' }]);
      showMenu();
      return;
    }

    if (promptState.mode === 'paginate') {
      if (trimmed.toLowerCase() === 'q') {
        showMenu();
      } else {
        renderAsciiTable(enriched, promptState.page, promptState.pageSize);
      }
      return;
    }

    if (promptState.mode === 'search') {
      const q = trimmed.toLowerCase();
      const matches = enriched.filter(
        (r) =>
          r.name.toLowerCase().includes(q) ||
          r.category.toLowerCase().includes(q) ||
          (r.notes ?? '').toLowerCase().includes(q)
      );
      if (matches.length === 0) {
        appendLines([{ kind: 'warning', text: `No records matched '${trimmed}'.` }]);
        showMenu();
      } else {
        renderAsciiTable(matches, 0, 10);
      }
      return;
    }

    if (promptState.mode === 'add_name') {
      const clean = sanitizeText(raw);
      if (!clean || clean.length < 2 || clean.length > 60 || /^\d+$/.test(clean)) {
        appendLines([
          {
            kind: 'error',
            text: "[ValidationError] Name must be 2–60 non-numeric-only characters (cannot be blank). Try again (or type 'cancel'):",
          },
        ]);
        return;
      }
      appendLines([
        { kind: 'success', text: `[OK] Sanitized name: "${clean}"` },
        { kind: 'system', text: 'Step 2/5 — Enter Expected Cost in USD (e.g., 14.99):' },
      ]);
      setPromptState({ mode: 'add_cost', name: clean });
      return;
    }

    if (promptState.mode === 'add_cost') {
      const check = parseCostInput(raw);
      if (!check.valid || check.value === undefined) {
        appendLines([
          { kind: 'error', text: `[ValidationError] ${check.reason} Try again:` },
        ]);
        return;
      }
      appendLines([
        { kind: 'success', text: `[OK] Validated cost: $${check.value.toFixed(2)}` },
        { kind: 'system', text: 'Step 3/5 — Enter Renewal Date (YYYY-MM-DD, e.g., 2026-12-20):' },
      ]);
      setPromptState({ mode: 'add_date', name: promptState.name, cost: check.value });
      return;
    }

    if (promptState.mode === 'add_date') {
      const dateCheck = isValidCalendarDate(raw);
      if (!dateCheck.valid) {
        appendLines([
          { kind: 'error', text: `[ValidationError] ${dateCheck.reason} Try again:` },
        ]);
        return;
      }
      appendLines([
        { kind: 'success', text: `[OK] Verified calendar date: ${trimmed}` },
        {
          kind: 'system',
          text: `Step 4/5 — Enter Billing Cycle (${BILLING_CYCLES.join(' / ')}) [default: Monthly]:`,
        },
      ]);
      setPromptState({
        mode: 'add_cycle',
        name: promptState.name,
        cost: promptState.cost,
        renewalDate: trimmed,
      });
      return;
    }

    if (promptState.mode === 'add_cycle') {
      const chosen = trimmed ? matchBillingCycle(trimmed) : 'Monthly';
      if (!chosen) {
        appendLines([
          {
            kind: 'error',
            text: `[ValidationError] Unsupported cycle '${trimmed}'. Choose: ${BILLING_CYCLES.join(', ')}:`,
          },
        ]);
        return;
      }
      appendLines([
        { kind: 'success', text: `[OK] Cycle: ${chosen}` },
        {
          kind: 'system',
          text: `Step 5/5 — Enter Category (${SUBSCRIPTION_CATEGORIES.join(', ')}) [default: Utilities]:`,
        },
      ]);
      setPromptState({
        mode: 'add_category',
        name: promptState.name,
        cost: promptState.cost,
        renewalDate: promptState.renewalDate,
        billingCycle: chosen,
      });
      return;
    }

    if (promptState.mode === 'add_category') {
      const chosenCat = trimmed ? matchCategory(trimmed) : 'Utilities';
      if (!chosenCat) {
        appendLines([
          {
            kind: 'error',
            text: `[ValidationError] Unknown category '${trimmed}'. Choose one of: ${SUBSCRIPTION_CATEGORIES.join(', ')}:`,
          },
        ]);
        return;
      }
      setBusy(true);
      try {
        await onCreateRecord({
          name: promptState.name,
          cost: promptState.cost,
          renewalDate: promptState.renewalDate,
          billingCycle: promptState.billingCycle,
          category: chosenCat,
          autoRenew: true,
          notes: 'Added via Interactive Terminal CLI',
        });
        appendLines([
          {
            kind: 'success',
            text: `[PERSISTED] Saved '${promptState.name}' ($${promptState.cost.toFixed(
              2
            )}/${promptState.billingCycle}) to data/subscriptions.json & data/subscriptions.csv.`,
          },
        ]);
      } catch (err) {
        appendLines([
          {
            kind: 'error',
            text: `[DiskWriteError] ${err instanceof Error ? err.message : 'Unable to save record'}`,
          },
        ]);
      } finally {
        setBusy(false);
        showMenu();
      }
      return;
    }

    switch (trimmed) {
      case '1':
        appendLines([
          { kind: 'system', text: '--- Guided Add Subscription (type "cancel" anytime to abort) ---' },
          { kind: 'system', text: 'Step 1/5 — Enter Subscription Name (2–60 chars):' },
        ]);
        setPromptState({ mode: 'add_name' });
        break;
      case '2':
        if (enriched.length === 0) {
          appendLines([{ kind: 'warning', text: 'No records found in storage.' }]);
          showMenu();
        } else {
          renderAsciiTable(enriched, 0, 10);
        }
        break;
      case '3':
        appendLines([{ kind: 'system', text: 'Enter search keyword or category name:' }]);
        setPromptState({ mode: 'search' });
        break;
      case '4':
        appendLines([
          { kind: 'banner', text: '--- EXECUTIVE SUMMARY REPORT ---' },
          { kind: 'output', text: `  Total Records       : ${summary.totalCount}` },
          { kind: 'output', text: `  Normalized Monthly  : ${formatCurrency(summary.totalMonthlySpend, settings.currencySymbol)}` },
          { kind: 'output', text: `  Annual Projection   : ${formatCurrency(summary.totalAnnualSpend, settings.currencySymbol)}` },
          { kind: 'output', text: `  Mean / Median Cost  : ${formatCurrency(summary.averageMonthlyCost, settings.currencySymbol)} / ${formatCurrency(summary.medianMonthlyCost, settings.currencySymbol)}` },
          { kind: 'output', text: `  Budget Utilization  : ${summary.budgetUtilizationPercent.toFixed(1)}% of ${formatCurrency(settings.monthlyBudgetLimit, settings.currencySymbol)}` },
          ...(summary.warnings.length === 0
            ? [{ kind: 'success' as const, text: '  [OK] All threshold limits nominal.' }]
            : summary.warnings.map((w) => ({
                kind: (w.severity === 'critical' ? 'error' : 'warning') as TerminalLine['kind'],
                text: `  [${w.severity.toUpperCase()}] ${w.title} — ${w.detail}`,
              }))),
        ]);
        showMenu();
        break;
      case '5':
        appendLines([
          { kind: 'banner', text: '--- AUDIT LOG PREVIEW (TOP 5 URGENT) ---' },
          ...[...enriched]
            .sort((a, b) => a.daysUntilRenewal - b.daysUntilRenewal)
            .slice(0, 5)
            .map((r) => ({
              kind: (r.daysUntilRenewal < 0 ? 'error' : 'output') as TerminalLine['kind'],
              text: `  ${r.renewalDate} | ${r.name.padEnd(26, ' ')} | ${formatCurrency(r.cost, settings.currencySymbol).padStart(9, ' ')} | ${r.status}`,
            })),
        ]);
        showMenu();
        break;
      case '6':
        setBusy(true);
        appendLines([{ kind: 'system', text: 'Closing active session and reloading state from disk...' }]);
        try {
          const rec = await onReloadFromDisk();
          appendLines([
            {
              kind: 'success',
              text: `[RELAUNCHED] Deserialized ${enriched.length} records from data/subscriptions.json cleanly.${
                rec?.recovered ? ` (${rec.reason})` : ''
              }`,
            },
          ]);
        } finally {
          setBusy(false);
          showMenu();
        }
        break;
      case '7':
        setBusy(true);
        appendLines([
          { kind: 'warning', text: '[TEST] Injecting malformed JSON tokens into data/subscriptions.json...' },
        ]);
        try {
          const rec = await onSimulateCorruption();
          appendLines([
            {
              kind: 'success',
              text: `[RECOVERED] ${
                rec?.reason ?? 'Caught JSONDecodeError and rebuilt clean JSON & CSV storage files.'
              }`,
            },
          ]);
        } finally {
          setBusy(false);
          showMenu();
        }
        break;
      case '0':
        setLines(WELCOME_LINES.map((l, idx) => ({ id: `clr-${Date.now()}-${idx}`, ...l })));
        setPromptState({ mode: 'menu' });
        break;
      default:
        appendLines([
          { kind: 'error', text: `[InputError] Unrecognized option '${trimmed}'. Enter 0–7.` },
        ]);
        break;
    }
  };

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    const cmd = inputValue;
    setInputValue('');
    await executeCommand(cmd);
    inputRef.current?.focus();
  };

  const runScriptedValidationDemo = async () => {
    setLines(WELCOME_LINES.map((l, idx) => ({ id: `demo-${Date.now()}-${idx}`, ...l })));
    setPromptState({ mode: 'menu' });
    appendLines([
      { kind: 'system', text: '--- Running College Demo: Defensive Validation Rejection Sequence ---' },
      { kind: 'input', text: 'menu> 1' },
      { kind: 'system', text: 'Step 1/5 — Enter Subscription Name:' },
      { kind: 'input', text: 'name>    ' },
      { kind: 'error', text: '[ValidationError] Name must be 2–60 non-numeric-only characters (cannot be blank).' },
      { kind: 'input', text: 'name> GitHub Student Pack' },
      { kind: 'success', text: '[OK] Sanitized name: "GitHub Student Pack"' },
      { kind: 'system', text: 'Step 2/5 — Enter Expected Cost in USD:' },
      { kind: 'input', text: 'cost> abc' },
      { kind: 'error', text: '[ValidationError] Cost must be a valid numeric decimal (e.g., 14.99).' },
      { kind: 'input', text: 'cost> -25' },
      { kind: 'error', text: '[ValidationError] Cost must be strictly greater than $0.00.' },
      { kind: 'input', text: 'cost> $12.99' },
      { kind: 'success', text: '[OK] Validated cost: $12.99' },
      { kind: 'system', text: 'Step 3/5 — Enter Renewal Date (YYYY-MM-DD):' },
      { kind: 'input', text: 'date> 2026-02-30' },
      { kind: 'error', text: '[ValidationError] Calendar date 2026-02-30 does not exist (invalid day for month).' },
      { kind: 'system', text: 'Try typing a valid date below (e.g., 2026-12-15) to complete this live entry!' },
    ]);
    setPromptState({ mode: 'add_date', name: 'GitHub Student Pack', cost: 12.99 });
    inputRef.current?.focus();
  };

  return (
    <div className="space-y-4">
      <div className="bg-[#101827] border border-slate-800 rounded-xl p-4 flex flex-wrap items-center justify-between gap-3">
        <div>
          <h2 className="text-sm sm:text-base font-semibold text-slate-100">
            Interactive Menu-Driven Terminal Simulator
          </h2>
          <p className="text-xs text-slate-400 mt-0.5">
            Demonstrates guided numeric menus, regex validation loops, fixed-width ASCII tables, and disk recovery.
          </p>
        </div>

        <div className="flex flex-wrap items-center gap-2">
          <button
            type="button"
            onClick={runScriptedValidationDemo}
            className="inline-flex items-center gap-1.5 px-3 py-1.5 text-xs font-semibold rounded-lg bg-teal-500 text-slate-950 hover:bg-teal-400 transition-colors whitespace-nowrap"
          >
            <Play className="w-3.5 h-3.5" />
            Demo Validation Catch
          </button>
          <button
            type="button"
            onClick={() => executeCommand('4')}
            className="inline-flex items-center gap-1.5 px-3 py-1.5 text-xs font-medium rounded-lg border border-slate-700 bg-[#0B111C] text-slate-200 hover:bg-slate-800 transition-colors whitespace-nowrap"
          >
            Run Summary (4)
          </button>
          <button
            type="button"
            onClick={() => executeCommand('7')}
            className="inline-flex items-center gap-1.5 px-3 py-1.5 text-xs font-medium rounded-lg border border-amber-500/30 bg-amber-500/15 text-amber-300 hover:bg-amber-500/25 transition-colors whitespace-nowrap"
          >
            <ShieldAlert className="w-3.5 h-3.5" />
            Test Corrupt Recovery (7)
          </button>
          <button
            type="button"
            onClick={() => executeCommand('0')}
            className="inline-flex items-center gap-1.5 px-3 py-1.5 text-xs font-medium rounded-lg border border-slate-700 bg-[#0B111C] text-slate-300 hover:bg-slate-800 transition-colors whitespace-nowrap"
          >
            <RotateCcw className="w-3.5 h-3.5" />
            Reset
          </button>
        </div>
      </div>

      <div className="bg-[#060A12] border border-slate-800 rounded-xl overflow-hidden shadow-sm">
        <div className="px-4 py-2.5 bg-[#0D1320] border-b border-slate-800 flex items-center justify-between text-xs text-slate-400">
          <span className="inline-flex items-center gap-2 font-mono text-slate-300">
            <TerminalIcon className="w-3.5 h-3.5 text-teal-400" />
            python3 subscription_reminder.py
          </span>
          <span className="font-mono text-[11px] text-slate-500">
            Prompt: {promptState.mode}
          </span>
        </div>

        <div
          ref={scrollRef}
          onClick={() => inputRef.current?.focus()}
          className="p-5 h-[460px] overflow-y-auto font-mono text-xs sm:text-[13px] leading-relaxed space-y-0.5 cursor-text"
        >
          {lines.map((line) => {
            const colorClass =
              line.kind === 'error'
                ? 'text-rose-400'
                : line.kind === 'warning'
                ? 'text-amber-300'
                : line.kind === 'success'
                ? 'text-emerald-400'
                : line.kind === 'banner'
                ? 'text-teal-300 font-semibold'
                : line.kind === 'input'
                ? 'text-white font-semibold'
                : line.kind === 'system'
                ? 'text-slate-400'
                : 'text-slate-200';
            return (
              <div key={line.id} className={`whitespace-pre ${colorClass}`}>
                {line.text || '\u00A0'}
              </div>
            );
          })}
        </div>

        <form
          onSubmit={handleSubmit}
          className="px-5 py-3 bg-[#0D1320] border-t border-slate-800 flex items-center gap-2.5 font-mono text-sm"
        >
          <span className="text-teal-400 font-semibold select-none shrink-0">
            {promptState.mode === 'menu' ? 'option>' : `${promptState.mode.replace('add_', '')}>`}
          </span>
          <input
            ref={inputRef}
            type="text"
            value={inputValue}
            onChange={(e) => setInputValue(e.target.value)}
            placeholder={
              promptState.mode === 'menu'
                ? 'Type 1–7 or 0 and press Enter...'
                : 'Enter value and press Enter (or "cancel")...'
            }
            disabled={busy}
            className="flex-1 bg-transparent text-slate-100 placeholder-slate-500 focus:outline-none"
          />
          <button
            type="submit"
            disabled={busy}
            className="px-3 py-1 text-xs font-semibold rounded bg-teal-500 text-slate-950 hover:bg-teal-400 transition-colors"
          >
            Send
          </button>
        </form>
      </div>
    </div>
  );
}
