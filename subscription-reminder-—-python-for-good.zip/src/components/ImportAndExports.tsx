import {
  AlertCircle,
  Archive,
  Check,
  CheckCircle2,
  Copy,
  Download,
  FileUp,
  HardDrive,
  History,
  RotateCcw,
} from 'lucide-react';
import { useEffect, useMemo, useState } from 'react';
import { SAMPLE_LEGACY_CSV_WITH_ERRORS } from '../data/sampleSubscriptions';
import type {
  BackupSnapshot,
  BulkImportRowResult,
  EnrichedSubscription,
  ExecutiveSummary,
  StorageFilesSnapshot,
  SubscriptionRecord,
  ThresholdSettings,
} from '../types/subscription';
import {
  generateMarkdownReport,
  generatePlainTextAuditLog,
  serializeRecordsToCsv,
} from '../utils/analytics';

interface ImportAndExportsProps {
  records: SubscriptionRecord[];
  enriched: EnrichedSubscription[];
  summary: ExecutiveSummary;
  settings: ThresholdSettings;
  backups: BackupSnapshot[];
  onBulkImport: (csvText: string) => Promise<{
    results: BulkImportRowResult[];
    importedCount: number;
    rejectedCount: number;
  }>;
  onFetchDiskFiles: () => Promise<StorageFilesSnapshot>;
  onCreateSnapshot: () => Promise<void>;
  onRestoreSnapshot: (filename: string) => Promise<void>;
  onGenerateServerExports: () => Promise<string[]>;
}

type ExportTab = 'markdown' | 'audit' | 'csv' | 'json';

export function ImportAndExports({
  records,
  enriched,
  summary,
  settings,
  backups,
  onBulkImport,
  onFetchDiskFiles,
  onCreateSnapshot,
  onRestoreSnapshot,
  onGenerateServerExports,
}: ImportAndExportsProps) {
  const [csvDraft, setCsvDraft] = useState(SAMPLE_LEGACY_CSV_WITH_ERRORS);
  const [importLog, setImportLog] = useState<BulkImportRowResult[] | null>(null);
  const [importStats, setImportStats] = useState<{ imported: number; rejected: number } | null>(null);
  const [importing, setImporting] = useState(false);

  const [exportTab, setExportTab] = useState<ExportTab>('markdown');
  const [copied, setCopied] = useState(false);
  const [diskSnapshot, setDiskSnapshot] = useState<StorageFilesSnapshot | null>(null);
  const [serverExports, setServerExports] = useState<string[] | null>(null);
  const [busyAction, setBusyAction] = useState<string | null>(null);

  useEffect(() => {
    onFetchDiskFiles().then(setDiskSnapshot).catch(() => {});
  }, [records.length, onFetchDiskFiles]);

  const exportContent = useMemo(() => {
    switch (exportTab) {
      case 'markdown':
        return generateMarkdownReport(enriched, summary, settings);
      case 'audit':
        return generatePlainTextAuditLog(enriched, summary, settings);
      case 'csv':
        return diskSnapshot?.csvContent ?? serializeRecordsToCsv(records);
      case 'json':
        return diskSnapshot?.jsonContent ?? JSON.stringify(records, null, 2);
    }
  }, [exportTab, enriched, summary, settings, records, diskSnapshot]);

  const exportFilename =
    exportTab === 'markdown'
      ? 'subscription_summary.md'
      : exportTab === 'audit'
      ? 'subscription_audit_log.txt'
      : exportTab === 'csv'
      ? 'subscriptions.csv'
      : 'subscriptions.json';

  const handleRunImport = async () => {
    if (!csvDraft.trim()) return;
    setImporting(true);
    try {
      const res = await onBulkImport(csvDraft);
      setImportLog(res.results);
      setImportStats({ imported: res.importedCount, rejected: res.rejectedCount });
      const snap = await onFetchDiskFiles();
      setDiskSnapshot(snap);
    } finally {
      setImporting(false);
    }
  };

  const handleFileUpload = (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (!file) return;
    const reader = new FileReader();
    reader.onload = () => {
      if (typeof reader.result === 'string') {
        setCsvDraft(reader.result);
        setImportLog(null);
        setImportStats(null);
      }
    };
    reader.readAsText(file);
  };

  const handleCopy = async () => {
    await navigator.clipboard.writeText(exportContent);
    setCopied(true);
    setTimeout(() => setCopied(false), 1800);
  };

  const handleDownload = () => {
    const mime =
      exportTab === 'json'
        ? 'application/json'
        : exportTab === 'csv'
        ? 'text/csv'
        : exportTab === 'markdown'
        ? 'text/markdown'
        : 'text/plain';
    const blob = new Blob([exportContent], { type: `${mime};charset=utf-8` });
    const url = URL.createObjectURL(blob);
    const a = document.createElement('a');
    a.href = url;
    a.download = exportFilename;
    a.click();
    URL.revokeObjectURL(url);
  };

  const handleServerExportBundle = async () => {
    setBusyAction('export');
    try {
      const files = await onGenerateServerExports();
      setServerExports(files);
    } finally {
      setBusyAction(null);
    }
  };

  const handleCreateBackup = async () => {
    setBusyAction('backup');
    try {
      await onCreateSnapshot();
    } finally {
      setBusyAction(null);
    }
  };

  const handleRestore = async (filename: string) => {
    setBusyAction(filename);
    try {
      await onRestoreSnapshot(filename);
    } finally {
      setBusyAction(null);
    }
  };

  return (
    <div className="space-y-5">
      <div className="grid grid-cols-1 xl:grid-cols-12 gap-5">
        <section className="xl:col-span-6 bg-[#101827] border border-slate-800 rounded-xl p-5 space-y-4">
          <div className="flex items-center justify-between gap-2">
            <div>
              <h2 className="text-sm font-semibold text-slate-100 flex items-center gap-1.5">
                <History className="w-4 h-4 text-teal-400" />
                Disk Snapshot Backups &amp; Rollback (data/backups/)
              </h2>
              <p className="text-xs text-slate-400 mt-0.5">
                Create point-in-time JSON snapshots on the Express server and roll back anytime.
              </p>
            </div>
            <button
              type="button"
              disabled={busyAction === 'backup'}
              onClick={handleCreateBackup}
              className="px-3 py-1.5 text-xs font-semibold rounded-lg bg-teal-500 text-slate-950 hover:bg-teal-400 disabled:opacity-50 whitespace-nowrap"
            >
              {busyAction === 'backup' ? 'Creating...' : 'Create Snapshot'}
            </button>
          </div>

          <div className="border border-slate-800 bg-[#0B111C] rounded-lg divide-y divide-slate-800/80 max-h-56 overflow-y-auto">
            {backups.length === 0 ? (
              <div className="p-4 text-xs text-slate-500 text-center">
                No snapshots created yet. Click Create Snapshot to save a disk backup.
              </div>
            ) : (
              backups.map((b) => (
                <div
                  key={b.filename}
                  className="px-3.5 py-2.5 flex items-center justify-between gap-3 text-xs hover:bg-slate-800/40"
                >
                  <div className="min-w-0">
                    <div className="font-mono font-medium text-slate-200 truncate">{b.filename}</div>
                    <div className="text-slate-400 font-mono tabular-nums text-[11px]">
                      {b.recordCount} records · {(b.sizeBytes / 1024).toFixed(1)} KB
                    </div>
                  </div>
                  <button
                    type="button"
                    disabled={busyAction === b.filename}
                    onClick={() => handleRestore(b.filename)}
                    className="inline-flex items-center gap-1 px-2.5 py-1 text-xs font-medium rounded-md border border-slate-700 text-slate-200 hover:bg-slate-800 whitespace-nowrap shrink-0"
                  >
                    <RotateCcw className="w-3 h-3" />
                    {busyAction === b.filename ? 'Restoring...' : 'Restore'}
                  </button>
                </div>
              ))
            )}
          </div>
        </section>

        <section className="xl:col-span-6 bg-[#101827] border border-slate-800 rounded-xl p-5 space-y-4">
          <div className="flex items-center justify-between gap-2">
            <div>
              <h2 className="text-sm font-semibold text-slate-100 flex items-center gap-1.5">
                <Archive className="w-4 h-4 text-teal-400" />
                Server Report Generator (exports/)
              </h2>
              <p className="text-xs text-slate-400 mt-0.5">
                Compiles all 4 report formats directly on disk and serves downloadable artifacts.
              </p>
            </div>
            <button
              type="button"
              disabled={busyAction === 'export'}
              onClick={handleServerExportBundle}
              className="px-3 py-1.5 text-xs font-semibold rounded-lg bg-slate-100 text-slate-950 hover:bg-white disabled:opacity-50 whitespace-nowrap"
            >
              {busyAction === 'export' ? 'Generating...' : 'Generate Server Exports'}
            </button>
          </div>

          <div className="border border-slate-800 bg-[#0B111C] rounded-lg divide-y divide-slate-800/80">
            {(serverExports ?? [
              'executive_summary.md',
              'audit_log.txt',
              'subscriptions_export.csv',
              'report_bundle.json',
            ]).map((file) => (
              <div
                key={file}
                className="px-3.5 py-2.5 flex items-center justify-between gap-3 text-xs"
              >
                <span className="font-mono text-slate-200">exports/{file}</span>
                {serverExports ? (
                  <a
                    href={`/api/exports/download/${file}`}
                    download={file}
                    className="inline-flex items-center gap-1 text-teal-400 hover:text-teal-300 font-medium"
                  >
                    <Download className="w-3.5 h-3.5" />
                    Download
                  </a>
                ) : (
                  <span className="text-slate-500">Click Generate to write to disk</span>
                )}
              </div>
            ))}
          </div>
        </section>
      </div>

      {/* Bulk CSV Dataset Import */}
      <section className="bg-[#101827] border border-slate-800 rounded-xl p-5 space-y-4">
        <div className="flex flex-wrap items-center justify-between gap-3">
          <div>
            <h2 className="text-sm font-semibold text-slate-100">
              Bulk Legacy CSV Import &amp; Row-by-Row Validation Log
            </h2>
            <p className="text-xs text-slate-400 mt-0.5">
              Ingests CSV datasets, validates each row on the backend, logs malformed entries, and backs up before committing.
            </p>
          </div>
          <div className="flex items-center gap-2">
            <label className="inline-flex items-center gap-1.5 px-3 py-1.5 text-xs font-medium rounded-lg border border-slate-700 bg-[#0B111C] text-slate-200 hover:bg-slate-800 cursor-pointer whitespace-nowrap">
              <FileUp className="w-3.5 h-3.5" />
              Upload .CSV
              <input
                type="file"
                accept=".csv,text/csv"
                onChange={handleFileUpload}
                className="hidden"
              />
            </label>
            <button
              type="button"
              onClick={() => {
                setCsvDraft(SAMPLE_LEGACY_CSV_WITH_ERRORS);
                setImportLog(null);
                setImportStats(null);
              }}
              className="px-3 py-1.5 text-xs font-medium rounded-lg border border-slate-700 bg-[#0B111C] text-slate-200 hover:bg-slate-800 whitespace-nowrap"
            >
              Load Sample (With Errors)
            </button>
          </div>
        </div>

        <textarea
          value={csvDraft}
          onChange={(e) => setCsvDraft(e.target.value)}
          rows={6}
          aria-label="Bulk CSV input"
          className="w-full p-3.5 text-xs font-mono rounded-lg border border-slate-700 bg-[#0B111C] text-slate-100 focus:outline-none focus:ring-2 focus:ring-teal-500/30 focus:border-teal-500"
        />

        <div className="flex flex-wrap items-center justify-between gap-3">
          <div className="text-xs text-slate-400">
            Schema: <span className="font-mono text-slate-300">name,category,cost,billingCycle,renewalDate,autoRenew,notes</span>
          </div>
          <button
            type="button"
            disabled={importing || !csvDraft.trim()}
            onClick={handleRunImport}
            className="px-4 py-1.5 text-xs sm:text-sm font-semibold rounded-lg bg-teal-500 text-slate-950 hover:bg-teal-400 disabled:opacity-50 transition-colors whitespace-nowrap"
          >
            {importing ? 'Validating & Importing...' : 'Validate & Import CSV'}
          </button>
        </div>

        {importLog && importStats && (
          <div className="pt-3 border-t border-slate-800 space-y-3">
            <div className="flex items-center gap-4 text-xs font-medium">
              <span className="text-emerald-400 font-mono tabular-nums">
                Accepted: {importStats.imported} rows
              </span>
              <span className="text-slate-600">·</span>
              <span className="text-rose-400 font-mono tabular-nums">
                Rejected: {importStats.rejected} rows
              </span>
            </div>

            <div className="border border-slate-800 bg-[#0B111C] rounded-lg divide-y divide-slate-800/80 max-h-56 overflow-y-auto">
              {importLog.map((row) => (
                <div key={row.rowNumber} className="px-4 py-2 text-xs flex items-start gap-2.5">
                  {row.status === 'accepted' ? (
                    <CheckCircle2 className="w-4 h-4 text-emerald-400 shrink-0 mt-0.5" />
                  ) : (
                    <AlertCircle className="w-4 h-4 text-rose-400 shrink-0 mt-0.5" />
                  )}
                  <div className="min-w-0 flex-1">
                    <div className="flex items-center gap-2 font-mono">
                      <span className="text-slate-400">Row {row.rowNumber}</span>
                      <span className="font-semibold text-slate-100">
                        {row.sanitizedName || '(unparsed)'}
                      </span>
                      <span
                        className={
                          row.status === 'accepted' ? 'text-emerald-400' : 'text-rose-400'
                        }
                      >
                        [{row.status.toUpperCase()}]
                      </span>
                    </div>
                    {row.errors.length > 0 ? (
                      <div className="text-rose-400 mt-0.5">{row.errors.join(' ')}</div>
                    ) : (
                      <div className="text-slate-400 mt-0.5">
                        Validated and appended to disk storage.
                      </div>
                    )}
                  </div>
                </div>
              ))}
            </div>
          </div>
        )}
      </section>

      {/* Live Disk File Inspector */}
      <section className="bg-[#101827] border border-slate-800 rounded-xl overflow-hidden">
        <div className="px-5 py-3.5 border-b border-slate-800 flex flex-wrap items-center justify-between gap-3">
          <div>
            <h2 className="text-sm font-semibold text-slate-100">
              Live Disk Storage &amp; Report Preview
            </h2>
            <p className="text-xs text-slate-400 mt-0.5 flex items-center gap-1.5">
              <HardDrive className="w-3.5 h-3.5 text-teal-400" />
              <span>
                {diskSnapshot?.recordCount ?? records.length} records persisted in data/subscriptions.json &amp; .csv
              </span>
            </p>
          </div>

          <div className="flex flex-wrap items-center gap-2">
            <div className="flex items-center gap-1 p-1 bg-[#0B111C] border border-slate-800 rounded-lg">
              {(
                [
                  { id: 'markdown', label: 'Markdown (.md)' },
                  { id: 'audit', label: 'Audit Log (.txt)' },
                  { id: 'csv', label: 'CSV (.csv)' },
                  { id: 'json', label: 'JSON (.json)' },
                ] as const
              ).map((tab) => (
                <button
                  key={tab.id}
                  type="button"
                  onClick={() => setExportTab(tab.id)}
                  className={`px-2.5 py-1 text-xs font-medium rounded-md transition-colors whitespace-nowrap ${
                    exportTab === tab.id
                      ? 'bg-teal-500 text-slate-950 font-semibold'
                      : 'text-slate-400 hover:text-slate-100'
                  }`}
                >
                  {tab.label}
                </button>
              ))}
            </div>

            <button
              type="button"
              onClick={handleCopy}
              className="inline-flex items-center gap-1.5 px-3 py-1.5 text-xs font-medium rounded-lg border border-slate-700 bg-[#0B111C] text-slate-200 hover:bg-slate-800 whitespace-nowrap"
            >
              {copied ? <Check className="w-3.5 h-3.5 text-emerald-400" /> : <Copy className="w-3.5 h-3.5" />}
              {copied ? 'Copied' : 'Copy'}
            </button>
            <button
              type="button"
              onClick={handleDownload}
              className="inline-flex items-center gap-1.5 px-3 py-1.5 text-xs font-semibold rounded-lg bg-teal-500 text-slate-950 hover:bg-teal-400 whitespace-nowrap"
            >
              <Download className="w-3.5 h-3.5" />
              Download {exportFilename}
            </button>
          </div>
        </div>

        <pre className="p-5 bg-[#060A12] text-slate-200 text-xs font-mono leading-relaxed overflow-x-auto max-h-[360px]">
          {exportContent}
        </pre>
      </section>
    </div>
  );
}
