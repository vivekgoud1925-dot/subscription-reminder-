import {
  AlertTriangle,
  ArrowRight,
  CalendarClock,
  CheckCircle2,
  Plus,
  RefreshCw,
  RotateCcw,
  SlidersHorizontal,
  Sparkles,
} from 'lucide-react';
import { motion } from 'motion/react';
import { useMemo, useState } from 'react';
import {
  BILLING_CYCLES,
  SUBSCRIPTION_CATEGORIES,
  type EnrichedSubscription,
  type ExecutiveSummary,
  type NavView,
  type SubscriptionInput,
  type ThresholdSettings,
} from '../types/subscription';
import { formatCurrency } from '../utils/analytics';
import { AnimatedCounter } from './AnimatedCounter';

interface OverviewDashboardProps {
  enriched: EnrichedSubscription[];
  summary: ExecutiveSummary;
  settings: ThresholdSettings;
  onUpdateSettings: (next: ThresholdSettings) => Promise<void>;
  onNavigate: (view: NavView) => void;
  onMarkRenewed: (record: EnrichedSubscription) => Promise<void>;
  onBatchRenewOverdue: () => Promise<void>;
  onQuickCreate: (input: SubscriptionInput) => Promise<void>;
  onOpenAddModal: () => void;
}

export function OverviewDashboard({
  enriched,
  summary,
  settings,
  onUpdateSettings,
  onNavigate,
  onMarkRenewed,
  onBatchRenewOverdue,
  onQuickCreate,
  onOpenAddModal,
}: OverviewDashboardProps) {
  const [editingThresholds, setEditingThresholds] = useState(false);
  const [budgetDraft, setBudgetDraft] = useState(String(settings.monthlyBudgetLimit));
  const [dueDaysDraft, setDueDaysDraft] = useState(String(settings.dueSoonDays));
  const [multiplierDraft, setMultiplierDraft] = useState(String(settings.anomalyMultiplier));
  const [savingSettings, setSavingSettings] = useState(false);
  const [batchBusy, setBatchBusy] = useState(false);

  // Quick-Entry Inline App Bar State
  const [quickName, setQuickName] = useState('');
  const [quickCost, setQuickCost] = useState('');
  const [quickDate, setQuickDate] = useState(() =>
    new Date(Date.now() + 14 * 86400000).toISOString().slice(0, 10)
  );
  const [quickCycle, setQuickCycle] = useState('Monthly');
  const [quickCategory, setQuickCategory] = useState('Cloud & Dev');
  const [quickError, setQuickError] = useState<string | null>(null);
  const [quickSaving, setQuickSaving] = useState(false);

  // Interactive 45-day Renewal Radar selection
  const radarItems = useMemo(
    () =>
      [...enriched]
        .filter((r) => r.daysUntilRenewal >= -15 && r.daysUntilRenewal <= 30)
        .sort((a, b) => a.daysUntilRenewal - b.daysUntilRenewal),
    [enriched]
  );
  const [selectedRadarId, setSelectedRadarId] = useState<string | null>(null);
  const activeRadarItem = useMemo(
    () => radarItems.find((r) => r.id === selectedRadarId) ?? radarItems[0] ?? null,
    [radarItems, selectedRadarId]
  );

  // Interactive What-If Cancellation / Savings Simulator
  const [pausedSimIds, setPausedSimIds] = useState<string[]>([]);
  const topCostCandidates = useMemo(
    () => [...enriched].sort((a, b) => b.monthlyEquivalent - a.monthlyEquivalent).slice(0, 6),
    [enriched]
  );

  const simMonthlySaved = useMemo(
    () =>
      enriched
        .filter((r) => pausedSimIds.includes(r.id))
        .reduce((sum, r) => sum + r.monthlyEquivalent, 0),
    [enriched, pausedSimIds]
  );
  const simNewMonthly = Math.max(0, summary.totalMonthlySpend - simMonthlySaved);
  const simAnnualSaved = simMonthlySaved * 12;
  const simBudgetPct =
    settings.monthlyBudgetLimit > 0 ? (simNewMonthly / settings.monthlyBudgetLimit) * 100 : 0;

  const toggleSimPause = (id: string) => {
    setPausedSimIds((prev) =>
      prev.includes(id) ? prev.filter((item) => item !== id) : [...prev, id]
    );
  };

  const urgentQueue = [...enriched]
    .filter((r) => r.status === 'Overdue' || r.status === 'Due Soon')
    .sort((a, b) => a.daysUntilRenewal - b.daysUntilRenewal);

  const handleQuickAdd = async (e: React.FormEvent) => {
    e.preventDefault();
    setQuickError(null);
    setQuickSaving(true);
    try {
      await onQuickCreate({
        name: quickName,
        cost: quickCost,
        renewalDate: quickDate,
        billingCycle: quickCycle,
        category: quickCategory,
        autoRenew: true,
        notes: 'Logged via Workspace Quick-Entry Bar',
      });
      setQuickName('');
      setQuickCost('');
    } catch (err) {
      setQuickError(err instanceof Error ? err.message : 'Validation failed');
    } finally {
      setQuickSaving(false);
    }
  };

  const handleBatchRenew = async () => {
    setBatchBusy(true);
    try {
      await onBatchRenewOverdue();
    } finally {
      setBatchBusy(false);
    }
  };

  const handleSaveSettings = async (e: React.FormEvent) => {
    e.preventDefault();
    const limit = Number(budgetDraft);
    const days = Number(dueDaysDraft);
    const mult = Number(multiplierDraft);
    if (!Number.isFinite(limit) || limit < 10) return;
    if (!Number.isFinite(days) || days < 1) return;
    if (!Number.isFinite(mult) || mult < 1.2) return;

    setSavingSettings(true);
    try {
      await onUpdateSettings({
        ...settings,
        monthlyBudgetLimit: limit,
        dueSoonDays: Math.round(days),
        anomalyMultiplier: Math.round(mult * 10) / 10,
      });
      setEditingThresholds(false);
    } finally {
      setSavingSettings(false);
    }
  };

  if (enriched.length === 0) {
    return (
      <div className="bg-[#101827] border border-slate-800 rounded-xl p-12 text-center max-w-xl mx-auto mt-8">
        <CalendarClock className="w-10 h-10 text-teal-400 mx-auto mb-3" />
        <h2 className="text-lg font-semibold text-slate-100">No Subscriptions Recorded Yet</h2>
        <p className="text-sm text-slate-400 mt-2">
          Add your first subscription record or load the 36-entry sample dataset from Demo &amp; Python to inspect executive metrics.
        </p>
        <div className="flex items-center justify-center gap-3 mt-6">
          <button
            type="button"
            onClick={onOpenAddModal}
            className="px-4 py-2 text-sm font-semibold rounded-lg bg-teal-500 text-slate-950 hover:bg-teal-400 transition-colors"
          >
            Log First Subscription
          </button>
        </div>
      </div>
    );
  }

  const budgetOver = summary.totalMonthlySpend > settings.monthlyBudgetLimit;
  const gaugeRadius = 25;
  const gaugeCirc = 2 * Math.PI * gaugeRadius;
  const gaugeFill = Math.min(summary.budgetUtilizationPercent / 100, 1) * gaugeCirc;

  return (
    <div className="space-y-4">
      {/* Clean Workspace Top Summary Strip (No competing animation in this column) */}
      <div className="bg-[#101827] border border-slate-800 rounded-xl px-4 py-3 flex flex-wrap items-center justify-between gap-3">
        <div className="min-w-0">
          <div className="text-xs font-medium text-teal-400">
            Subscription Portfolio Control
          </div>
          <div className="text-xs text-slate-400 font-mono tabular-nums mt-0.5">
            {summary.totalCount} active plans · Monthly{' '}
            <span className="text-slate-100 font-semibold">
              {formatCurrency(summary.totalMonthlySpend, settings.currencySymbol)}
            </span>{' '}
            · Annual{' '}
            <span className="text-slate-100 font-semibold">
              {formatCurrency(summary.totalAnnualSpend, settings.currencySymbol)}
            </span>
          </div>
        </div>

        <div className="flex items-center gap-2 shrink-0">
          <button
            type="button"
            onClick={() => onNavigate('animation')}
            className="inline-flex items-center gap-1.5 px-3 py-1.5 text-xs font-medium rounded-lg border border-teal-500/35 bg-teal-500/10 text-teal-300 hover:bg-teal-500/20 transition-colors whitespace-nowrap"
          >
            <Sparkles className="w-3.5 h-3.5" />
            Full Animation
          </button>
          <button
            type="button"
            onClick={() => onNavigate('analytics')}
            className="inline-flex items-center gap-1.5 px-3 py-1.5 text-xs font-medium rounded-lg border border-slate-700 bg-[#0B111C] text-slate-200 hover:bg-slate-800 transition-colors whitespace-nowrap"
          >
            Analytics
            <ArrowRight className="w-3.5 h-3.5" />
          </button>
        </div>
      </div>

      {/* Native App Quick-Entry Bar (Server-Validated) */}
      <form
        onSubmit={handleQuickAdd}
        className="bg-[#101827] border border-slate-800 rounded-xl p-3.5 space-y-2.5"
      >
        <div className="flex flex-wrap items-center gap-2">
          <input
            type="text"
            value={quickName}
            onChange={(e) => {
              setQuickName(e.target.value);
              if (quickError) setQuickError(null);
            }}
            placeholder="Quick log subscription (e.g., Figma Pro)"
            aria-label="Quick subscription name"
            className="flex-1 min-w-[180px] px-3 py-1.5 text-xs sm:text-sm rounded-lg border border-slate-700 bg-[#0B111C] text-slate-100 placeholder-slate-500 focus:outline-none focus:ring-2 focus:ring-teal-500/30 focus:border-teal-500"
          />
          <input
            type="text"
            value={quickCost}
            onChange={(e) => {
              setQuickCost(e.target.value);
              if (quickError) setQuickError(null);
            }}
            placeholder="Cost ($)"
            aria-label="Quick cost"
            className="w-24 px-3 py-1.5 text-xs sm:text-sm font-mono tabular-nums rounded-lg border border-slate-700 bg-[#0B111C] text-slate-100 placeholder-slate-500 focus:outline-none focus:ring-2 focus:ring-teal-500/30 focus:border-teal-500"
          />
          <input
            type="text"
            value={quickDate}
            onChange={(e) => {
              setQuickDate(e.target.value);
              if (quickError) setQuickError(null);
            }}
            placeholder="YYYY-MM-DD"
            aria-label="Quick renewal date"
            className="w-32 px-3 py-1.5 text-xs sm:text-sm font-mono tabular-nums rounded-lg border border-slate-700 bg-[#0B111C] text-slate-100 placeholder-slate-500 focus:outline-none focus:ring-2 focus:ring-teal-500/30 focus:border-teal-500"
          />
          <select
            value={quickCycle}
            onChange={(e) => setQuickCycle(e.target.value)}
            aria-label="Quick billing cycle"
            className="px-2.5 py-1.5 text-xs sm:text-sm rounded-lg border border-slate-700 bg-[#0B111C] text-slate-200"
          >
            {BILLING_CYCLES.map((c) => (
              <option key={c} value={c}>
                {c}
              </option>
            ))}
          </select>
          <select
            value={quickCategory}
            onChange={(e) => setQuickCategory(e.target.value)}
            aria-label="Quick category"
            className="px-2.5 py-1.5 text-xs sm:text-sm rounded-lg border border-slate-700 bg-[#0B111C] text-slate-200"
          >
            {SUBSCRIPTION_CATEGORIES.map((c) => (
              <option key={c} value={c}>
                {c}
              </option>
            ))}
          </select>
          <button
            type="submit"
            disabled={quickSaving}
            className="inline-flex items-center gap-1.5 px-3.5 py-1.5 text-xs sm:text-sm font-semibold rounded-lg bg-teal-500 text-slate-950 hover:bg-teal-400 disabled:opacity-50 transition-colors whitespace-nowrap"
          >
            <Plus className="w-3.5 h-3.5" />
            {quickSaving ? 'Saving...' : 'Save to Disk'}
          </button>
        </div>
        {quickError && (
          <div className="text-xs text-rose-400 flex items-center gap-1.5 px-1">
            <AlertTriangle className="w-3.5 h-3.5 shrink-0" />
            <span>Server rejected input: {quickError}</span>
          </div>
        )}
      </form>

      {/* 4-Column Executive KPI Strip */}
      <section aria-label="Executive Summary Metrics" className="grid grid-cols-1 @md:grid-cols-2 @4xl:grid-cols-4 gap-3.5">
        <div className="bg-[#101827] border border-slate-800 rounded-xl p-4 flex items-center justify-between gap-3">
          <div>
            <div className="text-xs font-medium text-slate-400">Monthly Run Rate</div>
            <div className="mt-1 text-xl font-semibold text-slate-50">
              <AnimatedCounter value={summary.totalMonthlySpend} prefix={settings.currencySymbol} />
            </div>
            <div className="mt-1 text-xs text-slate-400 font-mono tabular-nums">
              Avg {formatCurrency(summary.averageMonthlyCost, settings.currencySymbol)} · {summary.totalCount} active
            </div>
          </div>
          <svg width="52" height="36" viewBox="0 0 52 36" className="shrink-0" aria-hidden="true">
            {[12, 20, 16, 26, 22, 32].map((h, i) => (
              <motion.rect
                key={i}
                x={i * 8 + 2}
                width="5.5"
                rx="1.5"
                initial={{ y: 34, height: 0 }}
                animate={{ y: 34 - h, height: h }}
                transition={{ duration: 0.4, delay: i * 0.05 }}
                fill={i === 5 ? '#14B8A6' : '#334155'}
              />
            ))}
          </svg>
        </div>

        <div className="bg-[#101827] border border-slate-800 rounded-xl p-4 flex items-center justify-between gap-3">
          <div>
            <div className="text-xs font-medium text-slate-400">Annual Projection</div>
            <div className="mt-1 text-xl font-semibold text-slate-50">
              <AnimatedCounter value={summary.totalAnnualSpend} prefix={settings.currencySymbol} />
            </div>
            <div className="mt-1 text-xs text-slate-400 font-mono tabular-nums">
              Med {formatCurrency(summary.medianMonthlyCost, settings.currencySymbol)} · Max {formatCurrency(summary.maxMonthlyCost, settings.currencySymbol)}
            </div>
          </div>
          <svg width="52" height="36" viewBox="0 0 52 36" className="shrink-0" aria-hidden="true">
            <motion.polyline
              fill="none"
              stroke="#38BDF8"
              strokeWidth="2"
              strokeLinecap="round"
              strokeLinejoin="round"
              points="2,30 12,24 22,26 32,16 42,18 50,7"
              initial={{ pathLength: 0 }}
              animate={{ pathLength: 1 }}
              transition={{ duration: 0.7 }}
            />
            <circle cx="50" cy="7" r="2.8" fill="#38BDF8" />
          </svg>
        </div>

        <div className="bg-[#101827] border border-slate-800 rounded-xl p-4 flex items-center justify-between gap-2">
          <div>
            <div className="text-xs font-medium text-slate-400">Renewal Queue</div>
            <div className="mt-1 flex items-baseline gap-2.5">
              <span className={`text-xl font-semibold font-mono tabular-nums ${summary.overdueCount > 0 ? 'text-rose-400' : 'text-slate-50'}`}>
                {summary.overdueCount}
              </span>
              <span className="text-xs text-slate-400">Overdue</span>
              <span className="text-slate-600" aria-hidden="true">·</span>
              <span className={`text-xl font-semibold font-mono tabular-nums ${summary.dueSoonCount > 0 ? 'text-amber-400' : 'text-slate-50'}`}>
                {summary.dueSoonCount}
              </span>
              <span className="text-xs text-slate-400">≤{settings.dueSoonDays}d</span>
            </div>
            <div className="mt-1 text-xs text-slate-400 font-mono tabular-nums">
              {formatCurrency(summary.overdueTotalCost + summary.dueSoonTotalCost, settings.currencySymbol)} immediate
            </div>
          </div>
          {summary.overdueCount > 0 && (
            <button
              type="button"
              disabled={batchBusy}
              onClick={handleBatchRenew}
              title="Advance all overdue subscriptions by 1 cycle on the server"
              className="inline-flex items-center gap-1 px-2.5 py-1.5 text-[11px] font-medium rounded-lg border border-rose-500/30 bg-rose-500/15 text-rose-300 hover:bg-rose-500/25 transition-colors shrink-0 whitespace-nowrap"
            >
              <RefreshCw className={`w-3 h-3 ${batchBusy ? 'animate-spin' : ''}`} />
              Renew All
            </button>
          )}
        </div>

        <div className="bg-[#101827] border border-slate-800 rounded-xl p-4 flex items-center justify-between gap-3">
          <div className="min-w-0">
            <div className="flex items-center gap-2">
              <span className="text-xs font-medium text-slate-400">Budget Cap</span>
              <button
                type="button"
                onClick={() => {
                  setBudgetDraft(String(settings.monthlyBudgetLimit));
                  setDueDaysDraft(String(settings.dueSoonDays));
                  setMultiplierDraft(String(settings.anomalyMultiplier));
                  setEditingThresholds((v) => !v);
                }}
                className="text-xs font-medium text-teal-400 hover:text-teal-300 inline-flex items-center gap-1"
              >
                <SlidersHorizontal className="w-3 h-3" />
                Edit
              </button>
            </div>
            <div className={`mt-1 text-xl font-semibold ${budgetOver ? 'text-rose-400' : 'text-slate-50'}`}>
              <AnimatedCounter value={summary.budgetUtilizationPercent} decimals={1} suffix="%" />
            </div>
            <div className="mt-1 text-xs text-slate-400 font-mono tabular-nums">
              Limit {formatCurrency(settings.monthlyBudgetLimit, settings.currencySymbol)}/mo
            </div>
          </div>

          <svg width="60" height="60" viewBox="0 0 60 60" className="shrink-0" aria-hidden="true">
            <circle cx="30" cy="30" r={gaugeRadius} fill="none" stroke="#1E293B" strokeWidth="6" />
            <motion.circle
              cx="30"
              cy="30"
              r={gaugeRadius}
              fill="none"
              stroke={budgetOver ? '#F43F5E' : summary.budgetUtilizationPercent >= 85 ? '#F59E0B' : '#14B8A6'}
              strokeWidth="6"
              strokeLinecap="round"
              initial={{ strokeDasharray: `0 ${gaugeCirc}` }}
              animate={{ strokeDasharray: `${gaugeFill} ${gaugeCirc - gaugeFill}` }}
              transition={{ duration: 0.65, ease: [0.16, 1, 0.3, 1] }}
              transform="rotate(-90 30 30)"
            />
          </svg>
        </div>
      </section>

      {editingThresholds && (
        <form
          onSubmit={handleSaveSettings}
          className="bg-[#101827] border border-slate-800 rounded-xl p-4 flex flex-wrap items-end gap-4"
        >
          <div>
            <label htmlFor="cfg-budget" className="block text-xs font-medium text-slate-300 mb-1">
              Monthly Budget Limit ($)
            </label>
            <input
              id="cfg-budget"
              type="number"
              min={10}
              step="10"
              value={budgetDraft}
              onChange={(e) => setBudgetDraft(e.target.value)}
              className="w-36 px-3 py-1.5 text-sm font-mono tabular-nums rounded-lg border border-slate-700 bg-[#0B111C] text-slate-100"
            />
          </div>
          <div>
            <label htmlFor="cfg-days" className="block text-xs font-medium text-slate-300 mb-1">
              Due Soon Window (Days)
            </label>
            <input
              id="cfg-days"
              type="number"
              min={1}
              max={60}
              value={dueDaysDraft}
              onChange={(e) => setDueDaysDraft(e.target.value)}
              className="w-32 px-3 py-1.5 text-sm font-mono tabular-nums rounded-lg border border-slate-700 bg-[#0B111C] text-slate-100"
            />
          </div>
          <div>
            <label htmlFor="cfg-mult" className="block text-xs font-medium text-slate-300 mb-1">
              Anomaly Multiplier (x Avg)
            </label>
            <input
              id="cfg-mult"
              type="number"
              min={1.2}
              max={10}
              step="0.1"
              value={multiplierDraft}
              onChange={(e) => setMultiplierDraft(e.target.value)}
              className="w-32 px-3 py-1.5 text-sm font-mono tabular-nums rounded-lg border border-slate-700 bg-[#0B111C] text-slate-100"
            />
          </div>
          <div className="flex items-center gap-2 ml-auto">
            <button
              type="button"
              onClick={() => setEditingThresholds(false)}
              className="px-3 py-1.5 text-xs font-medium rounded-lg border border-slate-700 text-slate-300 hover:bg-slate-800"
            >
              Cancel
            </button>
            <button
              type="submit"
              disabled={savingSettings}
              className="px-4 py-1.5 text-xs font-semibold rounded-lg bg-teal-500 text-slate-950 hover:bg-teal-400"
            >
              {savingSettings ? 'Saving...' : 'Save to Disk'}
            </button>
          </div>
        </form>
      )}

      {/* Interactive 45-Day Renewal Radar Timeline Graphic */}
      <section className="bg-[#101827] border border-slate-800 rounded-xl p-5 space-y-4">
        <div className="flex flex-wrap items-center justify-between gap-2">
          <div>
            <h2 className="text-sm font-semibold text-slate-100">
              Renewal Horizon Radar (-15d Overdue to +30d Upcoming)
            </h2>
            <p className="text-xs text-slate-400 mt-0.5">
              Select any node on the timeline track to inspect or renew immediately.
            </p>
          </div>
          <span className="text-xs font-mono tabular-nums text-slate-400">
            {radarItems.length} scheduled events
          </span>
        </div>

        <div className="relative pt-7 pb-6 px-4 bg-[#0B111C] border border-slate-800 rounded-lg overflow-x-auto">
          <div className="min-w-[620px] relative">
            <div className="h-2 rounded-full bg-slate-800 relative overflow-hidden">
              <div
                className="absolute left-0 top-0 bottom-0 bg-rose-500/35"
                style={{ width: '33.33%' }}
              />
              <div
                className="absolute top-0 bottom-0 bg-amber-500/35"
                style={{ left: '33.33%', width: `${(settings.dueSoonDays / 45) * 100}%` }}
              />
            </div>

            <div
              className="absolute -top-5 flex flex-col items-center pointer-events-none"
              style={{ left: '33.33%', transform: 'translateX(-50%)' }}
            >
              <span className="text-[10px] font-mono font-semibold text-teal-400">TODAY</span>
              <div className="w-px h-7 bg-teal-400" />
            </div>

            {radarItems.map((item, idx) => {
              const clamped = Math.max(-15, Math.min(30, item.daysUntilRenewal));
              const pct = ((clamped + 15) / 45) * 100;
              const isSelected = activeRadarItem?.id === item.id;
              const isOverdue = item.daysUntilRenewal < 0;
              const isDueSoon = !isOverdue && item.daysUntilRenewal <= settings.dueSoonDays;
              const rowOffset = idx % 2 === 0 ? '-top-1.5' : 'top-1';

              return (
                <motion.button
                  key={item.id}
                  type="button"
                  initial={{ scale: 0, opacity: 0 }}
                  animate={{ scale: isSelected ? 1.3 : 1, opacity: 1 }}
                  transition={{ duration: 0.22, delay: Math.min(idx * 0.02, 0.3) }}
                  onClick={() => setSelectedRadarId(item.id)}
                  title={`${item.name} (${formatCurrency(item.cost, settings.currencySymbol)})`}
                  style={{ left: `${pct}%`, transform: 'translateX(-50%)' }}
                  className={`absolute ${rowOffset} w-4 h-4 rounded-full border-2 border-[#0B111C] shadow-sm transition-transform ${
                    isSelected ? 'ring-2 ring-teal-400 z-20' : 'hover:scale-125 z-10'
                  } ${
                    isOverdue
                      ? 'bg-rose-500'
                      : isDueSoon
                      ? 'bg-amber-400'
                      : 'bg-teal-400'
                  }`}
                  aria-label={`Inspect ${item.name}`}
                />
              );
            })}

            <div className="flex items-center justify-between text-[11px] font-mono text-slate-500 mt-5">
              <span>-15 days (Overdue)</span>
              <span>Due Soon (+{settings.dueSoonDays}d)</span>
              <span>+30 days</span>
            </div>
          </div>
        </div>

        {activeRadarItem && (
          <motion.div
            key={activeRadarItem.id}
            initial={{ opacity: 0, y: 4 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.16 }}
            className="flex flex-wrap items-center justify-between gap-4 p-3.5 rounded-lg border border-slate-800 bg-[#0B111C]"
          >
            <div className="space-y-0.5">
              <div className="flex items-center gap-2 text-sm font-semibold text-slate-100">
                <span>{activeRadarItem.name}</span>
                <span className="text-slate-600" aria-hidden="true">·</span>
                <span className="font-mono tabular-nums text-teal-400">
                  {formatCurrency(activeRadarItem.cost, settings.currencySymbol)} / {activeRadarItem.billingCycle}
                </span>
              </div>
              <div className="text-xs text-slate-400">
                {activeRadarItem.category} · Renewal {activeRadarItem.renewalDate} (
                {activeRadarItem.daysUntilRenewal < 0
                  ? `${Math.abs(activeRadarItem.daysUntilRenewal)}d overdue`
                  : activeRadarItem.daysUntilRenewal === 0
                  ? 'Due today'
                  : `In ${activeRadarItem.daysUntilRenewal}d`}
                ){activeRadarItem.notes ? ` · ${activeRadarItem.notes}` : ''}
              </div>
            </div>

            <button
              type="button"
              onClick={() => onMarkRenewed(activeRadarItem)}
              className="px-3.5 py-1.5 text-xs font-semibold rounded-lg bg-teal-500 text-slate-950 hover:bg-teal-400 transition-colors whitespace-nowrap"
            >
              Mark Renewed (+1 Cycle)
            </button>
          </motion.div>
        )}
      </section>

      {/* Dense App Workspace Split: What-If Simulator + Threshold Warnings */}
      <div className="grid grid-cols-1 @4xl:grid-cols-12 gap-4 items-start">
        <section className="@4xl:col-span-6 bg-[#101827] border border-slate-800 rounded-xl p-5 space-y-3.5">
          <div className="flex items-center justify-between gap-2">
            <div>
              <h2 className="text-sm font-semibold text-slate-100 flex items-center gap-1.5">
                <Sparkles className="w-4 h-4 text-teal-400" />
                What-If Savings &amp; Budget Simulator
              </h2>
              <p className="text-xs text-slate-400 mt-0.5">
                Simulate cancelling high-cost plans to preview annual savings.
              </p>
            </div>
            {pausedSimIds.length > 0 && (
              <button
                type="button"
                onClick={() => setPausedSimIds([])}
                className="inline-flex items-center gap-1 text-xs font-medium text-slate-400 hover:text-slate-100 whitespace-nowrap"
              >
                <RotateCcw className="w-3 h-3" />
                Reset
              </button>
            )}
          </div>

          <div className="p-3 rounded-lg bg-[#0B111C] border border-slate-800 grid grid-cols-3 gap-2 text-center">
            <div>
              <div className="text-[11px] text-slate-400">Sim Monthly</div>
              <div className="text-base font-semibold text-slate-100 mt-0.5">
                <AnimatedCounter value={simNewMonthly} prefix={settings.currencySymbol} />
              </div>
            </div>
            <div>
              <div className="text-[11px] text-slate-400">Annual Saved</div>
              <div className="text-base font-semibold text-emerald-400 mt-0.5">
                +<AnimatedCounter value={simAnnualSaved} prefix={settings.currencySymbol} />
              </div>
            </div>
            <div>
              <div className="text-[11px] text-slate-400">Budget Load</div>
              <div
                className={`text-base font-semibold mt-0.5 ${
                  simBudgetPct > 100 ? 'text-rose-400' : 'text-emerald-400'
                }`}
              >
                <AnimatedCounter value={simBudgetPct} decimals={1} suffix="%" />
              </div>
            </div>
          </div>

          <div className="divide-y divide-slate-800/80">
            {topCostCandidates.map((sub) => {
              const isPaused = pausedSimIds.includes(sub.id);
              return (
                <label
                  key={sub.id}
                  className="py-2 flex items-center justify-between gap-3 cursor-pointer hover:bg-slate-800/40 px-2 rounded-md transition-colors"
                >
                  <span className="flex items-center gap-2.5 min-w-0">
                    <input
                      type="checkbox"
                      checked={isPaused}
                      onChange={() => toggleSimPause(sub.id)}
                      className="h-4 w-4 rounded border-slate-600 bg-slate-900 text-teal-500 focus:ring-teal-500"
                    />
                    <span
                      className={`text-xs sm:text-sm truncate ${
                        isPaused ? 'line-through text-slate-500' : 'font-medium text-slate-200'
                      }`}
                    >
                      {sub.name}
                    </span>
                  </span>
                  <span className="font-mono tabular-nums text-xs text-slate-400 shrink-0">
                    {formatCurrency(sub.monthlyEquivalent, settings.currencySymbol)}/mo
                  </span>
                </label>
              );
            })}
          </div>
        </section>

        <section className="@4xl:col-span-6 bg-[#101827] border border-slate-800 rounded-xl p-5 space-y-3.5">
          <div className="flex items-center justify-between">
            <div>
              <h2 className="text-sm font-semibold text-slate-100">
                Server Threshold Warnings
              </h2>
              <p className="text-xs text-slate-400 mt-0.5">
                Computed on backend from active records and budget limits.
              </p>
            </div>
            <button
              type="button"
              onClick={() => onNavigate('ledger')}
              className="text-xs font-medium text-teal-400 hover:text-teal-300 inline-flex items-center gap-1 whitespace-nowrap"
            >
              Open Grid
              <ArrowRight className="w-3.5 h-3.5" />
            </button>
          </div>

          {summary.warnings.length === 0 ? (
            <div className="flex items-center gap-2.5 text-sm text-emerald-400 py-4">
              <CheckCircle2 className="w-4 h-4 shrink-0" />
              <span>All monitored subscriptions are within budget and renewal thresholds.</span>
            </div>
          ) : (
            <div className="divide-y divide-slate-800/80">
              {summary.warnings.map((w) => (
                <div key={w.id} className="py-2.5 first:pt-0 last:pb-0 flex items-start gap-2.5">
                  <AlertTriangle
                    className={`w-4 h-4 shrink-0 mt-0.5 ${
                      w.severity === 'critical' ? 'text-rose-400' : 'text-amber-400'
                    }`}
                  />
                  <div className="min-w-0 flex-1">
                    <div className="flex items-center gap-2 text-xs sm:text-sm font-medium text-slate-100">
                      <span>{w.title}</span>
                      <span aria-hidden="true" className="text-slate-600">·</span>
                      <span
                        className={`text-xs font-semibold ${
                          w.severity === 'critical' ? 'text-rose-400' : 'text-amber-400'
                        }`}
                      >
                        {w.severity === 'critical' ? 'Critical' : 'Warning'}
                      </span>
                    </div>
                    <p className="text-xs text-slate-400 mt-0.5 leading-relaxed">{w.detail}</p>
                  </div>
                </div>
              ))}
            </div>
          )}

          <div className="pt-2.5 border-t border-slate-800 flex items-center justify-between text-xs text-slate-400">
            <span>Immediate Queue: {urgentQueue.length} plans requiring review</span>
            <button
              type="button"
              onClick={() => onNavigate('analytics')}
              className="font-medium text-teal-400 hover:text-teal-300"
            >
              Inspect Charts
            </button>
          </div>
        </section>
      </div>
    </div>
  );
}
