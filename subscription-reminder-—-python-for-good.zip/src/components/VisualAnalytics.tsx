import { Download } from 'lucide-react';
import { motion } from 'motion/react';
import { useMemo, useRef, useState } from 'react';
import type {
  EnrichedSubscription,
  ExecutiveSummary,
  ThresholdSettings,
} from '../types/subscription';
import { formatCurrency } from '../utils/analytics';

interface VisualAnalyticsProps {
  enriched: EnrichedSubscription[];
  summary: ExecutiveSummary;
  settings: ThresholdSettings;
}

const CATEGORY_COLORS = [
  '#14B8A6',
  '#38BDF8',
  '#8B5CF6',
  '#F59E0B',
  '#F43F5E',
  '#10B981',
  '#94A3B8',
  '#EC4899',
];

export function VisualAnalytics({ enriched, summary, settings }: VisualAnalyticsProps) {
  const forecastSvgRef = useRef<SVGSVGElement>(null);
  const quadrantSvgRef = useRef<SVGSVGElement>(null);
  const categorySvgRef = useRef<SVGSVGElement>(null);

  const [hoveredMonth, setHoveredMonth] = useState<number | null>(null);
  const [selectedScatterId, setSelectedScatterId] = useState<string | null>(null);

  const exportSvgAsFile = (svgEl: SVGSVGElement | null, filename: string) => {
    if (!svgEl) return;
    const serializer = new XMLSerializer();
    const source = serializer.serializeToString(svgEl);
    const blob = new Blob([source], { type: 'image/svg+xml;charset=utf-8' });
    const url = URL.createObjectURL(blob);
    const a = document.createElement('a');
    a.href = url;
    a.download = filename;
    a.click();
    URL.revokeObjectURL(url);
  };

  const cumulativePoints = useMemo(() => {
    let running = 0;
    return summary.monthlyProjections.map((m) => {
      running += m.projectedSpend;
      return { ...m, cumulative: running };
    });
  }, [summary.monthlyProjections]);

  const scatterItems = useMemo(
    () =>
      enriched.map((item) => ({
        ...item,
        clampedDays: Math.max(-15, Math.min(120, item.daysUntilRenewal)),
      })),
    [enriched]
  );

  const selectedScatterItem = useMemo(
    () => scatterItems.find((s) => s.id === selectedScatterId) ?? null,
    [scatterItems, selectedScatterId]
  );

  if (enriched.length === 0) {
    return (
      <div className="bg-[#101827] border border-slate-800 rounded-xl p-12 text-center text-sm text-slate-400">
        Add subscription records to render visual spend distributions and 12-month renewal projections.
      </div>
    );
  }

  const maxProjected = Math.max(
    settings.monthlyBudgetLimit * 1.15,
    ...summary.monthlyProjections.map((m) => m.projectedSpend),
    50
  );
  const maxCumulative = Math.max(...cumulativePoints.map((c) => c.cumulative), 100);

  const donutSize = 216;
  const donutRadius = 74;
  const donutCircumference = 2 * Math.PI * donutRadius;
  let cumulativeShare = 0;

  const scatterMaxCost = Math.max(
    summary.anomalyThreshold * 1.2,
    ...scatterItems.map((i) => i.monthlyEquivalent),
    30
  );

  return (
    <div className="space-y-5">
      {/* Dual-Layer 12-Month Projected Cashflow + Cumulative Curve */}
      <section className="bg-[#101827] border border-slate-800 rounded-xl p-5">
        <div className="flex flex-wrap items-center justify-between gap-3 mb-4">
          <div>
            <h2 className="text-sm sm:text-base font-semibold text-slate-100">
              12-Month Cashflow Bars &amp; Cumulative Spend Trajectory
            </h2>
            <p className="text-xs text-slate-400 mt-0.5">
              Hover any month to inspect exact renewal outflow, billing event count, and cumulative annual trajectory.
            </p>
          </div>
          <button
            type="button"
            onClick={() => exportSvgAsFile(forecastSvgRef.current, 'subscription_12m_forecast.svg')}
            className="inline-flex items-center gap-1.5 px-3 py-1.5 text-xs font-medium rounded-lg border border-slate-700 bg-[#0B111C] text-slate-200 hover:bg-slate-800 transition-colors whitespace-nowrap"
          >
            <Download className="w-3.5 h-3.5" />
            Export Chart SVG
          </button>
        </div>

        {hoveredMonth !== null && cumulativePoints[hoveredMonth] && (
          <div className="mb-3 px-4 py-2 rounded-lg bg-[#0B111C] border border-slate-800 flex flex-wrap items-center gap-4 text-xs">
            <span className="font-semibold text-slate-100">
              {cumulativePoints[hoveredMonth].monthLabel}
            </span>
            <span className="font-mono tabular-nums text-teal-400">
              Month Outflow: {formatCurrency(cumulativePoints[hoveredMonth].projectedSpend, settings.currencySymbol)}
            </span>
            <span className="font-mono tabular-nums text-sky-400">
              Cumulative Total: {formatCurrency(cumulativePoints[hoveredMonth].cumulative, settings.currencySymbol)}
            </span>
            <span className="font-mono tabular-nums text-slate-400">
              {cumulativePoints[hoveredMonth].renewalCount} billing events
            </span>
          </div>
        )}

        <div className="w-full overflow-x-auto">
          <svg
            ref={forecastSvgRef}
            viewBox="0 0 880 290"
            className="w-full min-w-[640px] h-auto"
            role="img"
            aria-label="12-month projected renewal spend bar and cumulative trend chart"
          >
            <rect width="880" height="290" fill="#0B111C" rx="8" />

            {[0, 0.25, 0.5, 0.75, 1].map((ratio) => {
              const y = 235 - ratio * 190;
              const val = maxProjected * ratio;
              return (
                <g key={ratio}>
                  <line x1="64" y1={y} x2="820" y2={y} stroke="#1E293B" strokeDasharray="3 3" />
                  <text
                    x="56"
                    y={y + 4}
                    textAnchor="end"
                    fontSize="11"
                    fill="#94A3B8"
                    fontFamily="JetBrains Mono, monospace"
                  >
                    ${Math.round(val)}
                  </text>
                </g>
              );
            })}

            {(() => {
              const budgetY = 235 - (settings.monthlyBudgetLimit / maxProjected) * 190;
              return (
                <g>
                  <line
                    x1="64"
                    y1={budgetY}
                    x2="820"
                    y2={budgetY}
                    stroke="#FB7185"
                    strokeWidth="1.5"
                    strokeDasharray="6 4"
                  />
                  <text
                    x="816"
                    y={budgetY - 6}
                    textAnchor="end"
                    fontSize="11"
                    fontWeight="600"
                    fill="#FB7185"
                    fontFamily="JetBrains Mono, monospace"
                  >
                    Budget Cap ({formatCurrency(settings.monthlyBudgetLimit, settings.currencySymbol)})
                  </text>
                </g>
              );
            })()}

            {cumulativePoints.map((m, idx) => {
              const slotWidth = 740 / 12;
              const barWidth = 34;
              const x = 74 + idx * slotWidth + (slotWidth - barWidth) / 2;
              const barHeight = Math.max((m.projectedSpend / maxProjected) * 190, 2);
              const y = 235 - barHeight;
              const overBudget = m.projectedSpend > settings.monthlyBudgetLimit;
              const isHovered = hoveredMonth === idx;

              return (
                <g
                  key={m.monthKey}
                  onMouseEnter={() => setHoveredMonth(idx)}
                  onMouseLeave={() => setHoveredMonth(null)}
                  className="cursor-pointer"
                >
                  <motion.rect
                    x={x}
                    width={barWidth}
                    rx="4"
                    initial={{ y: 235, height: 0 }}
                    animate={{ y, height: barHeight }}
                    transition={{ duration: 0.45, delay: idx * 0.03 }}
                    fill={overBudget ? '#F43F5E' : isHovered ? '#2DD4BF' : '#14B8A6'}
                    opacity={hoveredMonth !== null && !isHovered ? 0.5 : 0.9}
                  />
                  <text
                    x={x + barWidth / 2}
                    y={y - 6}
                    textAnchor="middle"
                    fontSize="10"
                    fontWeight="600"
                    fill={overBudget ? '#FB7185' : '#E2E8F0'}
                    fontFamily="JetBrains Mono, monospace"
                  >
                    ${Math.round(m.projectedSpend)}
                  </text>
                  <text
                    x={x + barWidth / 2}
                    y={256}
                    textAnchor="middle"
                    fontSize="11"
                    fill="#94A3B8"
                    fontFamily="DM Sans, sans-serif"
                  >
                    {m.monthLabel}
                  </text>
                  <text
                    x={x + barWidth / 2}
                    y={272}
                    textAnchor="middle"
                    fontSize="10"
                    fill="#64748B"
                    fontFamily="JetBrains Mono, monospace"
                  >
                    {m.renewalCount}x
                  </text>
                </g>
              );
            })}

            <motion.polyline
              fill="none"
              stroke="#38BDF8"
              strokeWidth="2.5"
              strokeLinecap="round"
              strokeLinejoin="round"
              initial={{ pathLength: 0 }}
              animate={{ pathLength: 1 }}
              transition={{ duration: 0.8 }}
              points={cumulativePoints
                .map((m, idx) => {
                  const slotWidth = 740 / 12;
                  const cx = 74 + idx * slotWidth + slotWidth / 2;
                  const cy = 235 - (m.cumulative / maxCumulative) * 190;
                  return `${cx},${cy}`;
                })
                .join(' ')}
            />
            {cumulativePoints.map((m, idx) => {
              const slotWidth = 740 / 12;
              const cx = 74 + idx * slotWidth + slotWidth / 2;
              const cy = 235 - (m.cumulative / maxCumulative) * 190;
              return (
                <circle
                  key={`dot-${m.monthKey}`}
                  cx={cx}
                  cy={cy}
                  r={hoveredMonth === idx ? 5 : 3.5}
                  fill="#38BDF8"
                  stroke="#0B111C"
                  strokeWidth="1.5"
                />
              );
            })}
          </svg>
        </div>
      </section>

      {/* Two-Column Split: 4-Quadrant Scatter + Category Donut */}
      <div className="grid grid-cols-1 lg:grid-cols-12 gap-5">
        <section className="lg:col-span-7 bg-[#101827] border border-slate-800 rounded-xl p-5 space-y-4">
          <div className="flex flex-wrap items-center justify-between gap-2">
            <div>
              <h2 className="text-sm sm:text-base font-semibold text-slate-100">
                Urgency vs. Monthly Cost Quadrant Plot
              </h2>
              <p className="text-xs text-slate-400 mt-0.5">
                Click any data point to inspect its category, renewal window, and outlier status.
              </p>
            </div>
            <button
              type="button"
              onClick={() => exportSvgAsFile(quadrantSvgRef.current, 'subscription_quadrant.svg')}
              className="inline-flex items-center gap-1.5 px-3 py-1.5 text-xs font-medium rounded-lg border border-slate-700 bg-[#0B111C] text-slate-200 hover:bg-slate-800 whitespace-nowrap"
            >
              <Download className="w-3.5 h-3.5" />
              Export SVG
            </button>
          </div>

          <div className="w-full overflow-x-auto">
            <svg
              ref={quadrantSvgRef}
              viewBox="0 0 600 300"
              className="w-full min-w-[480px] h-auto"
              role="img"
              aria-label="Subscription urgency versus monthly cost scatter plot"
            >
              <rect width="600" height="300" fill="#0B111C" rx="8" />

              <rect x="60" y="20" width="160" height="115" fill="#F43F5E" opacity="0.09" />
              <rect x="220" y="20" width="355" height="115" fill="#F59E0B" opacity="0.07" />
              <rect x="60" y="135" width="160" height="125" fill="#1E293B" opacity="0.35" />
              <rect x="220" y="135" width="355" height="125" fill="#0F172A" opacity="0.4" />

              <text x="68" y="36" fontSize="10" fontWeight="600" fill="#FB7185">
                HIGH PRIORITY (URGENT + HIGH COST)
              </text>
              <text x="567" y="36" textAnchor="end" fontSize="10" fontWeight="600" fill="#FBBF24">
                HIGH-COST WATCHLIST
              </text>

              <line x1="60" y1="260" x2="575" y2="260" stroke="#334155" />
              <line x1="60" y1="20" x2="60" y2="260" stroke="#334155" />

              {(() => {
                const dueX = 60 + ((settings.dueSoonDays + 15) / 135) * 515;
                return (
                  <line
                    x1={dueX}
                    y1="20"
                    x2={dueX}
                    y2="260"
                    stroke="#64748B"
                    strokeDasharray="4 4"
                  />
                );
              })()}

              {(() => {
                const avgY = 260 - (summary.averageMonthlyCost / scatterMaxCost) * 235;
                return (
                  <g>
                    <line
                      x1="60"
                      y1={avgY}
                      x2="575"
                      y2={avgY}
                      stroke="#64748B"
                      strokeDasharray="4 4"
                    />
                    <text
                      x="570"
                      y={avgY - 5}
                      textAnchor="end"
                      fontSize="10"
                      fill="#94A3B8"
                      fontFamily="JetBrains Mono, monospace"
                    >
                      Avg {formatCurrency(summary.averageMonthlyCost, settings.currencySymbol)}
                    </text>
                  </g>
                );
              })()}

              {scatterItems.map((item) => {
                const cx = 60 + ((item.clampedDays + 15) / 135) * 515;
                const cy = 260 - (item.monthlyEquivalent / scatterMaxCost) * 235;
                const isSelected = selectedScatterId === item.id;
                const fill =
                  item.status === 'Overdue'
                    ? '#F43F5E'
                    : item.status === 'Due Soon'
                    ? '#FBBF24'
                    : item.isAnomaly
                    ? '#A78BFA'
                    : '#14B8A6';

                return (
                  <circle
                    key={item.id}
                    cx={cx}
                    cy={cy}
                    r={isSelected ? 8 : 5.5}
                    fill={fill}
                    stroke="#0B111C"
                    strokeWidth="1.5"
                    opacity={selectedScatterId && !isSelected ? 0.5 : 0.95}
                    className="cursor-pointer transition-all"
                    onClick={() => setSelectedScatterId(item.id)}
                  >
                    <title>
                      {item.name} — {formatCurrency(item.monthlyEquivalent, settings.currencySymbol)}/mo ({item.daysUntilRenewal}d)
                    </title>
                  </circle>
                );
              })}

              <text x="60" y="280" fontSize="10" fill="#94A3B8" fontFamily="JetBrains Mono, monospace">
                -15d (Overdue)
              </text>
              <text x="315" y="280" textAnchor="middle" fontSize="10" fill="#94A3B8">
                Days Until Renewal
              </text>
              <text x="575" y="280" textAnchor="end" fontSize="10" fill="#94A3B8" fontFamily="JetBrains Mono, monospace">
                +120d
              </text>
            </svg>
          </div>

          {selectedScatterItem && (
            <div className="p-3.5 rounded-lg bg-[#0B111C] border border-slate-800 flex items-center justify-between gap-3 text-xs">
              <div>
                <span className="font-semibold text-slate-100">{selectedScatterItem.name}</span>
                <span className="text-slate-600"> · </span>
                <span className="text-slate-300">{selectedScatterItem.category}</span>
                <span className="text-slate-600"> · </span>
                <span className="text-slate-400">{selectedScatterItem.renewalDate}</span>
              </div>
              <div className="font-mono tabular-nums font-semibold text-teal-400">
                {formatCurrency(selectedScatterItem.monthlyEquivalent, settings.currencySymbol)}/mo
              </div>
            </div>
          )}
        </section>

        <section className="lg:col-span-5 bg-[#101827] border border-slate-800 rounded-xl p-5 space-y-5">
          <div className="flex items-center justify-between">
            <div>
              <h2 className="text-sm sm:text-base font-semibold text-slate-100">
                Category Spend Distribution
              </h2>
              <p className="text-xs text-slate-400 mt-0.5">
                Share of normalized monthly run rate.
              </p>
            </div>
            <button
              type="button"
              onClick={() => exportSvgAsFile(categorySvgRef.current, 'subscription_categories.svg')}
              className="inline-flex items-center gap-1.5 px-3 py-1.5 text-xs font-medium rounded-lg border border-slate-700 bg-[#0B111C] text-slate-200 hover:bg-slate-800 whitespace-nowrap"
            >
              <Download className="w-3.5 h-3.5" />
              Export SVG
            </button>
          </div>

          <div className="flex justify-center">
            <svg
              ref={categorySvgRef}
              width={donutSize}
              height={donutSize}
              viewBox={`0 0 ${donutSize} ${donutSize}`}
              role="img"
              aria-label="Category spend distribution donut chart"
            >
              <circle
                cx={donutSize / 2}
                cy={donutSize / 2}
                r={donutRadius}
                fill="none"
                stroke="#1E293B"
                strokeWidth="26"
              />
              {summary.categoryBreakdown.map((cat, idx) => {
                const dashLen = (cat.sharePercent / 100) * donutCircumference;
                const dashOffset = -(cumulativeShare / 100) * donutCircumference;
                cumulativeShare += cat.sharePercent;
                return (
                  <motion.circle
                    key={cat.category}
                    cx={donutSize / 2}
                    cy={donutSize / 2}
                    r={donutRadius}
                    fill="none"
                    stroke={CATEGORY_COLORS[idx % CATEGORY_COLORS.length]}
                    strokeWidth="26"
                    strokeDasharray={`${dashLen} ${donutCircumference - dashLen}`}
                    initial={{ strokeDashoffset: donutCircumference }}
                    animate={{ strokeDashoffset: dashOffset }}
                    transition={{ duration: 0.65, delay: idx * 0.05 }}
                    transform={`rotate(-90 ${donutSize / 2} ${donutSize / 2})`}
                  />
                );
              })}
              <text
                x={donutSize / 2}
                y={donutSize / 2 - 4}
                textAnchor="middle"
                fontSize="16"
                fontWeight="700"
                fill="#F8FAFC"
                fontFamily="JetBrains Mono, monospace"
              >
                {formatCurrency(summary.totalMonthlySpend, settings.currencySymbol)}
              </text>
              <text
                x={donutSize / 2}
                y={donutSize / 2 + 14}
                textAnchor="middle"
                fontSize="11"
                fill="#94A3B8"
              >
                per month
              </text>
            </svg>
          </div>

          <div className="space-y-2.5">
            {summary.categoryBreakdown.map((cat, idx) => (
              <div key={cat.category} className="flex items-center justify-between text-xs gap-2">
                <span className="flex items-center gap-2 min-w-0">
                  <span
                    className="w-2.5 h-2.5 rounded-xs shrink-0"
                    style={{ backgroundColor: CATEGORY_COLORS[idx % CATEGORY_COLORS.length] }}
                  />
                  <span className="text-slate-200 font-medium truncate">{cat.category}</span>
                </span>
                <span className="font-mono tabular-nums text-slate-400 whitespace-nowrap">
                  {formatCurrency(cat.monthlyTotal, settings.currencySymbol)} ({cat.sharePercent.toFixed(1)}%)
                </span>
              </div>
            ))}
          </div>
        </section>
      </div>
    </div>
  );
}
