import { ArrowRight, Database, FileText, LineChart, ShieldCheck } from 'lucide-react';
import { motion } from 'motion/react';
import { useEffect, useState } from 'react';
import type { NavView } from '../types/subscription';

interface ProjectFlowAnimationProps {
  onNavigate: (view: NavView) => void;
  totalCount: number;
}

const STAGES: Array<{
  id: string;
  step: string;
  title: string;
  subtitle: string;
  detail: string;
  target: NavView;
  icon: typeof ShieldCheck;
}> = [
  {
    id: 'validate',
    step: '01',
    title: 'Defensive Validation',
    subtitle: 'Regex & Calendar Guards',
    detail: 'Rejects blank names, negative costs, and invalid dates like 2026-02-30 before storage.',
    target: 'terminal',
    icon: ShieldCheck,
  },
  {
    id: 'persist',
    step: '02',
    title: 'Dual Disk Persistence',
    subtitle: 'JSON + CSV + Auto-Recovery',
    detail: 'Atomically writes data/subscriptions.json & .csv and recovers from corrupted files.',
    target: 'exports',
    icon: Database,
  },
  {
    id: 'analyze',
    step: '03',
    title: 'Forecast & Anomaly Engine',
    subtitle: 'Monthly Eq. & Outlier Alerts',
    detail: 'Normalizes weekly/annual plans, detects budget breaches, and plots 12-month cashflow.',
    target: 'analytics',
    icon: LineChart,
  },
  {
    id: 'report',
    step: '04',
    title: 'Multi-Format Reporting',
    subtitle: 'Markdown, Audit Log & CLI',
    detail: 'Compiles formatted executive reports, ASCII terminal tables, and bulk CSV error logs.',
    target: 'presentation',
    icon: FileText,
  },
];

export function ProjectFlowAnimation({ onNavigate, totalCount }: ProjectFlowAnimationProps) {
  const [activeIdx, setActiveIdx] = useState(0);
  const [paused, setPaused] = useState(false);

  useEffect(() => {
    const prefersReduced =
      typeof window !== 'undefined' &&
      window.matchMedia('(prefers-reduced-motion: reduce)').matches;
    if (prefersReduced || paused) return;

    const timer = setInterval(() => {
      setActiveIdx((prev) => (prev + 1) % STAGES.length);
    }, 2800);
    return () => clearInterval(timer);
  }, [paused]);

  const activeStage = STAGES[activeIdx];

  return (
    <section
      onMouseEnter={() => setPaused(true)}
      onMouseLeave={() => setPaused(false)}
      className="bg-[#101827] border border-slate-800 rounded-xl p-4 space-y-3.5 overflow-hidden"
      aria-label="Project overview animation"
    >
      <div className="flex flex-wrap items-center justify-between gap-2">
        <div className="flex items-center gap-2.5 min-w-0">
          <span className="text-xs font-semibold text-teal-400 whitespace-nowrap">
            Project #16 · Python for Good
          </span>
          <span className="text-slate-700" aria-hidden="true">·</span>
          <span className="text-xs text-slate-300 truncate">
            Subscription Reminder End-to-End Architecture ({totalCount} active records)
          </span>
        </div>

        <button
          type="button"
          onClick={() => onNavigate(activeStage.target)}
          className="inline-flex items-center gap-1 text-xs font-medium text-teal-400 hover:text-teal-300 whitespace-nowrap"
        >
          Open {activeStage.title}
          <ArrowRight className="w-3.5 h-3.5" />
        </button>
      </div>

      {/* Animated Pipeline Nodes + Traveling Pulse Line */}
      <div className="relative">
        {/* Background Connecting Track on Desktop */}
        <div className="hidden md:block absolute top-7 left-10 right-10 h-0.5 bg-slate-800 overflow-hidden rounded-full">
          <motion.div
            className="h-full w-1/4 bg-gradient-to-r from-transparent via-teal-400 to-transparent"
            animate={{ x: ['-100%', '400%'] }}
            transition={{ duration: 2.6, repeat: Infinity, ease: 'linear' }}
          />
        </div>

        <div className="grid grid-cols-1 sm:grid-cols-2 md:grid-cols-4 gap-3 relative z-10">
          {STAGES.map((stage, idx) => {
            const Icon = stage.icon;
            const isActive = idx === activeIdx;
            return (
              <motion.button
                key={stage.id}
                type="button"
                onClick={() => setActiveIdx(idx)}
                animate={{
                  y: isActive ? -2 : 0,
                  borderColor: isActive ? 'rgba(20, 184, 166, 0.55)' : 'rgba(30, 41, 59, 1)',
                }}
                transition={{ duration: 0.22 }}
                className={`text-left p-3 rounded-lg border transition-colors ${
                  isActive ? 'bg-[#0D1A29]' : 'bg-[#0B111C] hover:bg-slate-900'
                }`}
              >
                <div className="flex items-center justify-between mb-2">
                  <div
                    className={`w-7 h-7 rounded-md flex items-center justify-center transition-colors ${
                      isActive ? 'bg-teal-500 text-slate-950' : 'bg-slate-800 text-slate-400'
                    }`}
                  >
                    <Icon className="w-4 h-4" />
                  </div>
                  <span
                    className={`font-mono text-[11px] font-semibold ${
                      isActive ? 'text-teal-400' : 'text-slate-500'
                    }`}
                  >
                    {stage.step}
                  </span>
                </div>
                <div className="text-xs font-semibold text-slate-100">{stage.title}</div>
                <div className="text-[11px] text-slate-400 mt-0.5">{stage.subtitle}</div>
              </motion.button>
            );
          })}
        </div>
      </div>

      {/* Animated Active Stage Explainer Caption */}
      <motion.div
        key={activeStage.id}
        initial={{ opacity: 0, x: 6 }}
        animate={{ opacity: 1, x: 0 }}
        transition={{ duration: 0.2 }}
        className="px-3.5 py-2 rounded-lg bg-[#0B111C] border border-slate-800/90 flex flex-wrap items-center justify-between gap-2 text-xs"
      >
        <span className="text-slate-300">
          <span className="font-mono font-semibold text-teal-400 mr-2">
            [{activeStage.step}]
          </span>
          {activeStage.detail}
        </span>
        <span className="text-[11px] text-slate-500 font-mono">
          {paused ? 'Paused on hover' : 'Auto-cycling pipeline'}
        </span>
      </motion.div>
    </section>
  );
}
