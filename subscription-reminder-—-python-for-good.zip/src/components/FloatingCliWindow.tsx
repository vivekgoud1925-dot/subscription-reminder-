import { Maximize2, Minus, Terminal as TerminalIcon, X } from 'lucide-react';
import { motion } from 'motion/react';
import { useState } from 'react';
import type {
  EnrichedSubscription,
  ExecutiveSummary,
  ThresholdSettings,
} from '../types/subscription';
import { formatCurrency } from '../utils/analytics';

interface FloatingCliWindowProps {
  open: boolean;
  minimized: boolean;
  onMinimize: () => void;
  onClose: () => void;
  onExpandToTab: () => void;
  enriched: EnrichedSubscription[];
  summary: ExecutiveSummary;
  settings: ThresholdSettings;
  onQuickRefresh: () => Promise<unknown>;
}

export function FloatingCliWindow({
  open,
  minimized,
  onMinimize,
  onClose,
  onExpandToTab,
  enriched,
  summary,
  settings,
  onQuickRefresh,
}: FloatingCliWindowProps) {
  const [cmd, setCmd] = useState('');
  const [logs, setLogs] = useState<string[]>([
    'SubReminder Mini-Shell ready. Commands: "summary", "overdue", "sync", "help"',
  ]);

  if (!open || minimized) return null;

  const runMiniCommand = async (e: React.FormEvent) => {
    e.preventDefault();
    const trimmed = cmd.trim().toLowerCase();
    if (!trimmed) return;
    setCmd('');

    if (trimmed === 'summary') {
      setLogs((prev) => [
        ...prev,
        `> ${trimmed}`,
        `Records: ${summary.totalCount} | Monthly: ${formatCurrency(
          summary.totalMonthlySpend,
          settings.currencySymbol
        )} | Annual: ${formatCurrency(summary.totalAnnualSpend, settings.currencySymbol)}`,
      ]);
    } else if (trimmed === 'overdue') {
      const overdue = enriched.filter((r) => r.status === 'Overdue');
      setLogs((prev) => [
        ...prev,
        `> ${trimmed}`,
        overdue.length === 0
          ? 'No overdue subscriptions.'
          : overdue.map((o) => `[OVERDUE] ${o.name} (${o.renewalDate})`).join(' | '),
      ]);
    } else if (trimmed === 'sync') {
      await onQuickRefresh();
      setLogs((prev) => [...prev, `> ${trimmed}`, '[OK] Reloaded state from data/subscriptions.json']);
    } else if (trimmed === 'clear') {
      setLogs(['Mini-Shell cleared. Commands: "summary", "overdue", "sync", "clear"']);
    } else {
      setLogs((prev) => [
        ...prev,
        `> ${trimmed}`,
        'Available commands: summary, overdue, sync, clear',
      ]);
    }
  };

  return (
    <motion.div
      drag
      dragMomentum={false}
      initial={{ opacity: 0, scale: 0.94, y: 16 }}
      animate={{ opacity: 1, scale: 1, y: 0 }}
      exit={{ opacity: 0, scale: 0.94, y: 16 }}
      transition={{ duration: 0.18, ease: [0.16, 1, 0.3, 1] }}
      className="fixed bottom-14 right-5 z-40 w-[360px] max-w-[92vw] bg-[#070B13] border border-teal-500/40 rounded-xl shadow-2xl overflow-hidden"
      role="dialog"
      aria-label="Floating Multitask CLI Window"
    >
      {/* Draggable Window Titlebar */}
      <div className="px-3.5 py-2 bg-[#0E1624] border-b border-slate-800 flex items-center justify-between cursor-grab active:cursor-grabbing select-none">
        <span className="inline-flex items-center gap-2 text-xs font-mono text-slate-200">
          <TerminalIcon className="w-3.5 h-3.5 text-teal-400" />
          Floating CLI (Drag me)
        </span>
        <div className="flex items-center gap-1">
          <button
            type="button"
            onClick={onMinimize}
            title="Minimize to taskbar"
            className="p-1 rounded text-slate-400 hover:text-white hover:bg-slate-800"
            aria-label="Minimize floating CLI"
          >
            <Minus className="w-3.5 h-3.5" />
          </button>
          <button
            type="button"
            onClick={onExpandToTab}
            title="Expand to full terminal view"
            className="p-1 rounded text-slate-400 hover:text-white hover:bg-slate-800"
            aria-label="Maximize CLI view"
          >
            <Maximize2 className="w-3.5 h-3.5" />
          </button>
          <button
            type="button"
            onClick={onClose}
            title="Close floating CLI"
            className="p-1 rounded text-slate-400 hover:text-rose-400 hover:bg-slate-800"
            aria-label="Close floating CLI"
          >
            <X className="w-3.5 h-3.5" />
          </button>
        </div>
      </div>

      <div className="p-3 h-44 overflow-y-auto font-mono text-[11px] leading-relaxed space-y-1 text-slate-300">
        {logs.map((line, i) => (
          <div
            key={i}
            className={
              line.startsWith('>')
                ? 'text-teal-400 font-semibold'
                : line.includes('[OVERDUE]')
                ? 'text-rose-400'
                : 'text-slate-300'
            }
          >
            {line}
          </div>
        ))}
      </div>

      <form
        onSubmit={runMiniCommand}
        className="px-3 py-2 bg-[#0D1320] border-t border-slate-800 flex items-center gap-2 font-mono text-xs"
      >
        <span className="text-teal-400 font-semibold">cli&gt;</span>
        <input
          type="text"
          value={cmd}
          onChange={(e) => setCmd(e.target.value)}
          placeholder="summary | overdue | sync"
          className="flex-1 bg-transparent text-slate-100 placeholder-slate-500 focus:outline-none"
        />
        <button
          type="submit"
          className="px-2 py-0.5 rounded bg-teal-500 text-slate-950 font-semibold text-[11px] hover:bg-teal-400"
        >
          Run
        </button>
      </form>
    </motion.div>
  );
}
