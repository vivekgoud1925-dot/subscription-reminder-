import {
  Activity,
  AlertTriangle,
  Archive,
  Columns2,
  Menu,
  Plus,
  Terminal,
  X,
} from 'lucide-react';
import { motion, MotionConfig } from 'motion/react';
import { useCallback, useEffect, useState } from 'react';
import { FloatingCliWindow } from './components/FloatingCliWindow';
import { ImportAndExports } from './components/ImportAndExports';
import { InteractiveTerminal } from './components/InteractiveTerminal';
import { LiveAnimationStage } from './components/LiveAnimationStage';
import { OverviewDashboard } from './components/OverviewDashboard';
import { PresentationGuide } from './components/PresentationGuide';
import { Sidebar } from './components/Sidebar';
import { SubscriptionFormModal } from './components/SubscriptionFormModal';
import { SubscriptionLedger } from './components/SubscriptionLedger';
import { VisualAnalytics } from './components/VisualAnalytics';
import type {
  BackendAuditEntry,
  BackupSnapshot,
  BulkImportRowResult,
  DiskStats,
  EnrichedSubscription,
  ExecutiveSummary,
  NavView,
  StorageFilesSnapshot,
  StorageRecoveryEvent,
  SubscriptionInput,
  SubscriptionRecord,
  ThresholdSettings,
  WorkspacePayload,
} from './types/subscription';
import { DEFAULT_THRESHOLD_SETTINGS } from './utils/analytics';

const VIEW_TITLES: Record<NavView, string> = {
  overview: 'Workspace',
  animation: 'Live Animation',
  ledger: 'Records Grid',
  terminal: 'CLI Terminal',
  analytics: 'Visual Analytics',
  exports: 'Backups & Export',
  presentation: 'Demo & Python Source',
};

const ALL_VIEWS: NavView[] = [
  'overview',
  'animation',
  'ledger',
  'terminal',
  'analytics',
  'exports',
  'presentation',
];

const EMPTY_DISK_STATS: DiskStats = {
  jsonBytes: 0,
  csvBytes: 0,
  auditLogBytes: 0,
  backupCount: 0,
  exportFileCount: 0,
  lastSavedAt: '',
};

const EMPTY_SUMMARY: ExecutiveSummary = {
  totalCount: 0,
  totalMonthlySpend: 0,
  totalAnnualSpend: 0,
  averageMonthlyCost: 0,
  medianMonthlyCost: 0,
  minMonthlyCost: 0,
  maxMonthlyCost: 0,
  overdueCount: 0,
  overdueTotalCost: 0,
  dueSoonCount: 0,
  dueSoonTotalCost: 0,
  activeCount: 0,
  budgetUtilizationPercent: 0,
  anomalyThreshold: 0,
  categoryBreakdown: [],
  monthlyProjections: [],
  warnings: [],
};

export default function App() {
  const [activeView, setActiveView] = useState<NavView>('overview');
  const [splitView, setSplitView] = useState(true);
  const [secondaryView, setSecondaryView] = useState<NavView>('animation');
  const [openTasks, setOpenTasks] = useState<NavView[]>(['overview']);

  const [floatingCliOpen, setFloatingCliOpen] = useState(false);
  const [floatingCliMinimized, setFloatingCliMinimized] = useState(false);

  const [mobileMenuOpen, setMobileMenuOpen] = useState(false);
  const [inspectorOpen, setInspectorOpen] = useState(false);

  const [records, setRecords] = useState<SubscriptionRecord[]>([]);
  const [enriched, setEnriched] = useState<EnrichedSubscription[]>([]);
  const [summary, setSummary] = useState<ExecutiveSummary>(EMPTY_SUMMARY);
  const [settings, setSettings] = useState<ThresholdSettings>(DEFAULT_THRESHOLD_SETTINGS);
  const [diskStats, setDiskStats] = useState<DiskStats>(EMPTY_DISK_STATS);
  const [backups, setBackups] = useState<BackupSnapshot[]>([]);
  const [auditLog, setAuditLog] = useState<BackendAuditEntry[]>([]);

  const [loading, setLoading] = useState(true);
  const [errorBanner, setErrorBanner] = useState<string | null>(null);
  const [recoveryNotice, setRecoveryNotice] = useState<StorageRecoveryEvent | null>(null);
  const [snapshotToast, setSnapshotToast] = useState<string | null>(null);

  const [modalOpen, setModalOpen] = useState(false);
  const [editingRecord, setEditingRecord] = useState<SubscriptionRecord | null>(null);

  const selectPrimaryView = useCallback((view: NavView) => {
    setActiveView(view);
    if (view === 'animation') {
      setSplitView(false);
    }
    setOpenTasks((prev) => (prev.includes(view) ? prev : [...prev, view]));
  }, []);

  const closeTaskTab = (view: NavView, e: React.MouseEvent) => {
    e.stopPropagation();
    setOpenTasks((prev) => {
      const next = prev.filter((v) => v !== view);
      if (next.length === 0) return ['overview'];
      if (activeView === view) setActiveView(next[next.length - 1]);
      return next;
    });
  };

  const applyWorkspace = useCallback((ws: WorkspacePayload) => {
    setRecords(ws.records);
    setEnriched(ws.enriched);
    setSummary(ws.summary);
    setSettings(ws.settings);
    setDiskStats(ws.diskStats);
    setBackups(ws.backups);
    setAuditLog(ws.auditLog);
    if (ws.recovery?.recovered) {
      setRecoveryNotice(ws.recovery);
    }
  }, []);

  const loadWorkspaceData = useCallback(async (): Promise<StorageRecoveryEvent | null> => {
    try {
      setErrorBanner(null);
      const res = await fetch('/api/workspace');
      if (!res.ok) throw new Error('Failed to load backend workspace state.');
      const ws = (await res.json()) as WorkspacePayload;
      applyWorkspace(ws);
      return ws.recovery;
    } catch (err) {
      setErrorBanner(err instanceof Error ? err.message : 'Unable to reach persistence server.');
      return null;
    } finally {
      setLoading(false);
    }
  }, [applyWorkspace]);

  useEffect(() => {
    loadWorkspaceData();
  }, [loadWorkspaceData]);

  const handleCreateOrUpdate = async (input: SubscriptionInput, editingId?: string) => {
    const url = editingId ? `/api/subscriptions/${editingId}` : '/api/subscriptions';
    const method = editingId ? 'PUT' : 'POST';
    const res = await fetch(url, {
      method,
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify(input),
    });
    const data = await res.json();
    if (!res.ok) {
      await loadWorkspaceData();
      const firstErr =
        data?.errors && typeof data.errors === 'object'
          ? Object.values(data.errors)[0]
          : data?.error;
      throw new Error(typeof firstErr === 'string' ? firstErr : 'Validation failed');
    }
    applyWorkspace(data.workspace);
  };

  const handleDelete = async (id: string) => {
    const res = await fetch(`/api/subscriptions/${id}`, { method: 'DELETE' });
    if (!res.ok) throw new Error('Failed to delete record');
    const data = (await res.json()) as { workspace: WorkspacePayload };
    applyWorkspace(data.workspace);
  };

  const handleMarkRenewed = async (item: EnrichedSubscription) => {
    const res = await fetch(`/api/subscriptions/${item.id}/renew`, { method: 'POST' });
    if (!res.ok) throw new Error('Failed to renew subscription');
    const data = (await res.json()) as { workspace: WorkspacePayload };
    applyWorkspace(data.workspace);
  };

  const handleBatchRenewOverdue = async () => {
    const res = await fetch('/api/subscriptions/renew-overdue', { method: 'POST' });
    if (!res.ok) throw new Error('Failed to batch renew overdue subscriptions');
    const data = (await res.json()) as { renewedCount: number; workspace: WorkspacePayload };
    applyWorkspace(data.workspace);
    setSnapshotToast(`Renewed ${data.renewedCount} overdue plans & saved pre-batch disk snapshot.`);
    setTimeout(() => setSnapshotToast(null), 3200);
  };

  const handleUpdateSettings = async (next: ThresholdSettings) => {
    const res = await fetch('/api/settings', {
      method: 'PUT',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify(next),
    });
    if (res.ok) {
      const data = (await res.json()) as { workspace: WorkspacePayload };
      applyWorkspace(data.workspace);
    }
  };

  const handleBulkImport = async (
    csvText: string
  ): Promise<{
    results: BulkImportRowResult[];
    importedCount: number;
    rejectedCount: number;
  }> => {
    const res = await fetch('/api/subscriptions/bulk', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ csvText }),
    });
    const data = await res.json();
    if (!res.ok) {
      throw new Error(data?.error ?? 'Bulk import failed');
    }
    applyWorkspace(data.workspace);
    return {
      results: data.results,
      importedCount: data.importedCount,
      rejectedCount: data.rejectedCount,
    };
  };

  const handleCreateSnapshot = async () => {
    const res = await fetch('/api/storage/backups', { method: 'POST' });
    if (res.ok) {
      const data = (await res.json()) as { snapshot: BackupSnapshot; workspace: WorkspacePayload };
      applyWorkspace(data.workspace);
      setSnapshotToast(`Snapshot saved: ${data.snapshot.filename}`);
      setTimeout(() => setSnapshotToast(null), 3000);
    }
  };

  const handleRestoreSnapshot = async (filename: string) => {
    const res = await fetch(`/api/storage/restore/${encodeURIComponent(filename)}`, {
      method: 'POST',
    });
    if (res.ok) {
      const data = (await res.json()) as { workspace: WorkspacePayload };
      applyWorkspace(data.workspace);
      setSnapshotToast(`Restored disk state from ${filename}`);
      setTimeout(() => setSnapshotToast(null), 3000);
    }
  };

  const handleGenerateServerExports = async (): Promise<string[]> => {
    const res = await fetch('/api/exports/generate', { method: 'POST' });
    if (!res.ok) throw new Error('Failed to generate server exports');
    const data = (await res.json()) as { files: string[]; workspace: WorkspacePayload };
    applyWorkspace(data.workspace);
    return data.files;
  };

  const handleSeedSampleData = async () => {
    const res = await fetch('/api/storage/seed', { method: 'POST' });
    if (res.ok) {
      const data = (await res.json()) as { workspace: WorkspacePayload };
      applyWorkspace(data.workspace);
      setRecoveryNotice(null);
    }
  };

  const handleSimulateCorruption = async (): Promise<StorageRecoveryEvent | null> => {
    const res = await fetch('/api/storage/corrupt-test', { method: 'POST' });
    if (!res.ok) return null;
    const data = (await res.json()) as { workspace: WorkspacePayload };
    applyWorkspace(data.workspace);
    return data.workspace.recovery;
  };

  const handleFetchDiskFiles = useCallback(async (): Promise<StorageFilesSnapshot> => {
    const res = await fetch('/api/storage/files');
    if (!res.ok) throw new Error('Failed to read disk storage files');
    return (await res.json()) as StorageFilesSnapshot;
  }, []);

  const renderViewModule = (view: NavView) => {
    switch (view) {
      case 'overview':
        return (
          <OverviewDashboard
            enriched={enriched}
            summary={summary}
            settings={settings}
            onUpdateSettings={handleUpdateSettings}
            onNavigate={selectPrimaryView}
            onMarkRenewed={handleMarkRenewed}
            onBatchRenewOverdue={handleBatchRenewOverdue}
            onQuickCreate={(input) => handleCreateOrUpdate(input)}
            onOpenAddModal={() => {
              setEditingRecord(null);
              setModalOpen(true);
            }}
          />
        );
      case 'animation':
        return (
          <LiveAnimationStage
            enriched={enriched}
            summary={summary}
            settings={settings}
            isFullscreen={!splitView && activeView === 'animation'}
            onToggleFullscreen={() => {
              if (!splitView && activeView === 'animation') {
                setActiveView('overview');
                setSplitView(true);
                setSecondaryView('animation');
              } else {
                setSplitView(false);
                selectPrimaryView('animation');
              }
            }}
          />
        );
      case 'ledger':
        return (
          <SubscriptionLedger
            enriched={enriched}
            settings={settings}
            onAdd={() => {
              setEditingRecord(null);
              setModalOpen(true);
            }}
            onEdit={(record) => {
              setEditingRecord(record);
              setModalOpen(true);
            }}
            onDelete={handleDelete}
            onMarkRenewed={handleMarkRenewed}
          />
        );
      case 'terminal':
        return (
          <InteractiveTerminal
            enriched={enriched}
            summary={summary}
            settings={settings}
            onCreateRecord={(input) => handleCreateOrUpdate(input)}
            onReloadFromDisk={loadWorkspaceData}
            onSimulateCorruption={handleSimulateCorruption}
          />
        );
      case 'analytics':
        return <VisualAnalytics enriched={enriched} summary={summary} settings={settings} />;
      case 'exports':
        return (
          <ImportAndExports
            records={records}
            enriched={enriched}
            summary={summary}
            settings={settings}
            backups={backups}
            onBulkImport={handleBulkImport}
            onFetchDiskFiles={handleFetchDiskFiles}
            onCreateSnapshot={handleCreateSnapshot}
            onRestoreSnapshot={handleRestoreSnapshot}
            onGenerateServerExports={handleGenerateServerExports}
          />
        );
      case 'presentation':
        return (
          <PresentationGuide
            records={records}
            onNavigate={selectPrimaryView}
            onSeedSampleData={handleSeedSampleData}
            onSimulateCorruption={handleSimulateCorruption}
            onOpenAddModal={() => {
              setEditingRecord(null);
              setModalOpen(true);
            }}
          />
        );
    }
  };

  return (
    <MotionConfig reducedMotion="user">
      <div className="min-h-screen lg:h-screen lg:overflow-hidden flex bg-[#090E17] text-slate-100">
        <Sidebar
          activeView={activeView}
          onSelectView={selectPrimaryView}
          totalCount={summary.totalCount}
          overdueCount={summary.overdueCount}
          diskStats={diskStats}
          mobileOpen={mobileMenuOpen}
          onCloseMobile={() => setMobileMenuOpen(false)}
        />

        <div className="flex-1 min-w-0 flex flex-col lg:h-full">
          {/* Native App Window Titlebar + Multitasking Controls */}
          <header className="shrink-0 h-[52px] bg-[#0B111C] border-b border-slate-800/90 px-4 flex items-center justify-between gap-3">
            <div className="flex items-center gap-2.5 min-w-0">
              <button
                type="button"
                onClick={() => setMobileMenuOpen(true)}
                className="lg:hidden p-1.5 rounded-lg text-slate-400 hover:text-white hover:bg-slate-800"
                aria-label="Open navigation menu"
              >
                <Menu className="w-5 h-5" />
              </button>
              <div className="flex items-center gap-2 text-sm min-w-0 truncate">
                <span className="text-slate-500 hidden sm:inline">Subscription Reminder</span>
                <span className="text-slate-700 hidden sm:inline" aria-hidden="true">/</span>
                <h1 className="font-semibold text-slate-100 truncate">
                  {VIEW_TITLES[activeView]}
                  {splitView ? ` + ${VIEW_TITLES[secondaryView]}` : ''}
                </h1>
              </div>
            </div>

            <div className="flex items-center gap-2 shrink-0">
              <button
                type="button"
                onClick={() => {
                  if (!splitView && activeView === 'animation') {
                    setActiveView('overview');
                    setSecondaryView('animation');
                    setSplitView(true);
                  } else {
                    setSplitView((v) => !v);
                  }
                }}
                title="Run workspace alongside dedicated Live Animation block"
                className={`hidden md:inline-flex items-center gap-1.5 px-2.5 py-1.5 text-xs font-medium rounded-lg border transition-colors whitespace-nowrap ${
                  splitView
                    ? 'border-teal-500/40 bg-teal-500/15 text-teal-300'
                    : 'border-slate-700 bg-[#101827] text-slate-200 hover:bg-slate-800'
                }`}
              >
                <Columns2 className="w-3.5 h-3.5" />
                Split View
              </button>

              <button
                type="button"
                onClick={() => {
                  setFloatingCliOpen(true);
                  setFloatingCliMinimized(false);
                }}
                title="Open floating draggable CLI window"
                className={`hidden sm:inline-flex items-center gap-1.5 px-2.5 py-1.5 text-xs font-medium rounded-lg border transition-colors whitespace-nowrap ${
                  floatingCliOpen && !floatingCliMinimized
                    ? 'border-teal-500/40 bg-teal-500/15 text-teal-300'
                    : 'border-slate-700 bg-[#101827] text-slate-200 hover:bg-slate-800'
                }`}
              >
                <Terminal className="w-3.5 h-3.5" />
                Mini CLI
              </button>

              <button
                type="button"
                onClick={handleCreateSnapshot}
                title="Write a timestamped JSON snapshot to data/backups/"
                className="hidden lg:inline-flex items-center gap-1.5 px-2.5 py-1.5 text-xs font-medium rounded-lg border border-slate-700 bg-[#101827] text-slate-200 hover:bg-slate-800 transition-colors whitespace-nowrap"
              >
                <Archive className="w-3.5 h-3.5 text-slate-400" />
                Snapshot
              </button>

              <button
                type="button"
                onClick={() => setInspectorOpen((v) => !v)}
                className={`hidden xl:inline-flex items-center gap-1.5 px-2.5 py-1.5 text-xs font-medium rounded-lg border transition-colors whitespace-nowrap ${
                  inspectorOpen
                    ? 'border-teal-500/40 bg-teal-500/15 text-teal-300'
                    : 'border-slate-700 bg-[#101827] text-slate-300 hover:bg-slate-800'
                }`}
              >
                <Activity className="w-3.5 h-3.5" />
                Log ({auditLog.length})
              </button>

              <button
                type="button"
                onClick={() => {
                  setEditingRecord(null);
                  setModalOpen(true);
                }}
                className="inline-flex items-center gap-1.5 px-3 py-1.5 text-xs font-semibold rounded-lg bg-teal-500 text-slate-950 hover:bg-teal-400 transition-colors whitespace-nowrap"
              >
                <Plus className="w-3.5 h-3.5" />
                New Entry
              </button>
            </div>
          </header>

          {/* Multitasking Open Windows Tab Strip */}
          <div className="shrink-0 h-9 bg-[#090E17] border-b border-slate-800/80 px-4 flex items-center gap-1.5 overflow-x-auto">
            {openTasks.map((task) => {
              const isFocused = activeView === task;
              return (
                <div
                  key={task}
                  onClick={() => selectPrimaryView(task)}
                  role="button"
                  tabIndex={0}
                  onKeyDown={(e) => {
                    if (e.key === 'Enter' || e.key === ' ') selectPrimaryView(task);
                  }}
                  className={`inline-flex items-center gap-2 px-2.5 py-1 rounded-md text-xs cursor-pointer transition-colors whitespace-nowrap ${
                    isFocused
                      ? 'bg-[#101827] text-teal-300 border border-slate-700'
                      : 'text-slate-400 hover:text-slate-200 hover:bg-slate-800/50 border border-transparent'
                  }`}
                >
                  <span>{VIEW_TITLES[task]}</span>
                  {openTasks.length > 1 && (
                    <button
                      type="button"
                      onClick={(e) => closeTaskTab(task, e)}
                      className="text-slate-500 hover:text-slate-200"
                      aria-label={`Close ${VIEW_TITLES[task]} tab`}
                    >
                      <X className="w-3 h-3" />
                    </button>
                  )}
                </div>
              );
            })}

            {floatingCliOpen && floatingCliMinimized && (
              <button
                type="button"
                onClick={() => setFloatingCliMinimized(false)}
                className="ml-auto inline-flex items-center gap-1.5 px-2.5 py-1 rounded-md text-xs bg-teal-500/15 border border-teal-500/30 text-teal-300 hover:bg-teal-500/25 whitespace-nowrap"
              >
                <Terminal className="w-3 h-3" />
                Restore Mini CLI
              </button>
            )}
          </div>

          {/* Split App Body: Primary Pane + Optional Split Secondary Pane + Right Audit Inspector */}
          <div className="flex-1 min-h-0 flex">
            <div className={`flex-1 min-w-0 flex ${splitView ? 'flex-col lg:flex-row' : ''}`}>
              {/* Primary Workspace Pane */}
              <main
                className={`@container ${
                  splitView ? 'lg:w-[46%] lg:border-r lg:border-slate-800' : 'flex-1'
                } min-w-0 lg:overflow-y-auto p-4 sm:p-5 ${
                  activeView === 'animation' && !splitView ? 'flex flex-col' : 'space-y-4'
                }`}
              >
                {snapshotToast && (
                  <div className="bg-teal-500/15 border border-teal-500/30 text-teal-200 rounded-lg px-4 py-2.5 text-xs flex items-center justify-between">
                    <span className="font-mono">{snapshotToast}</span>
                    <button
                      type="button"
                      onClick={() => setSnapshotToast(null)}
                      className="text-teal-300 hover:text-white"
                    >
                      <X className="w-3.5 h-3.5" />
                    </button>
                  </div>
                )}

                {recoveryNotice && (
                  <div className="bg-amber-500/15 border border-amber-500/30 rounded-xl px-4 py-3 flex items-start justify-between gap-3 text-xs text-amber-200">
                    <div className="flex items-start gap-2.5">
                      <AlertTriangle className="w-4 h-4 text-amber-400 shrink-0 mt-0.5" />
                      <div>
                        <span className="font-semibold">Fault-Tolerant Storage Recovery Executed: </span>
                        <span>{recoveryNotice.reason}</span>
                      </div>
                    </div>
                    <button
                      type="button"
                      onClick={() => setRecoveryNotice(null)}
                      className="p-1 text-amber-300 hover:text-white"
                      aria-label="Dismiss recovery notification"
                    >
                      <X className="w-3.5 h-3.5" />
                    </button>
                  </div>
                )}

                {errorBanner && (
                  <div className="bg-rose-500/15 border border-rose-500/30 rounded-xl px-4 py-3 text-xs text-rose-300 flex items-center justify-between">
                    <span>{errorBanner}</span>
                    <button
                      type="button"
                      onClick={() => loadWorkspaceData()}
                      className="font-semibold underline"
                    >
                      Retry
                    </button>
                  </div>
                )}

                {loading ? (
                  <div className="grid grid-cols-1 sm:grid-cols-2 xl:grid-cols-4 gap-3.5">
                    {[1, 2, 3, 4].map((n) => (
                      <div
                        key={n}
                        className="bg-[#101827] border border-slate-800 rounded-xl p-4 h-24 animate-pulse"
                      >
                        <div className="h-3 w-24 bg-slate-800 rounded" />
                        <div className="h-6 w-20 bg-slate-800 rounded mt-3" />
                        <div className="h-3 w-32 bg-slate-800/60 rounded mt-2" />
                      </div>
                    ))}
                  </div>
                ) : (
                  <motion.div
                    key={activeView}
                    initial={{ opacity: 0, y: 5 }}
                    animate={{ opacity: 1, y: 0 }}
                    transition={{ duration: 0.16, ease: [0.16, 1, 0.3, 1] }}
                    className={activeView === 'animation' && !splitView ? 'flex-1 min-h-0 flex flex-col' : ''}
                  >
                    {renderViewModule(activeView)}
                  </motion.div>
                )}
              </main>

              {/* Separate Dedicated Animation / Multitask Block */}
              {splitView && !loading && (
                <section
                  aria-label="Dedicated Animation Showcase Block"
                  className="@container lg:w-[54%] min-w-0 lg:overflow-y-auto p-3 sm:p-4 flex flex-col gap-3 bg-[#04070D] border-t lg:border-t-0 border-slate-800"
                >
                  {secondaryView !== 'animation' && (
                    <div className="shrink-0 bg-[#101827] border border-slate-800 rounded-xl px-3.5 py-2 flex items-center justify-between gap-3">
                      <span className="text-xs font-medium text-teal-400">
                        Split Pane Module
                      </span>
                      <div className="flex items-center gap-2">
                        <select
                          value={secondaryView}
                          onChange={(e) => setSecondaryView(e.target.value as NavView)}
                          aria-label="Choose secondary multitask module"
                          className="px-2.5 py-1 text-xs rounded-md border border-slate-700 bg-[#0B111C] text-slate-200"
                        >
                          {ALL_VIEWS.map((v) => (
                            <option key={v} value={v}>
                              {VIEW_TITLES[v]}
                            </option>
                          ))}
                        </select>
                        <button
                          type="button"
                          onClick={() => setSplitView(false)}
                          className="p-1 text-slate-400 hover:text-white"
                          aria-label="Close split view"
                        >
                          <X className="w-3.5 h-3.5" />
                        </button>
                      </div>
                    </div>
                  )}

                  <motion.div
                    key={`split-${secondaryView}`}
                    initial={{ opacity: 0, y: 5 }}
                    animate={{ opacity: 1, y: 0 }}
                    transition={{ duration: 0.16 }}
                    className="flex-1 min-h-0 flex flex-col"
                  >
                    {renderViewModule(secondaryView)}
                  </motion.div>
                </section>
              )}
            </div>

            {/* Right Docked Backend Event & Audit Inspector Panel */}
            {inspectorOpen && (
              <aside
                aria-label="Backend Audit Log Inspector"
                className="hidden xl:flex w-[300px] shrink-0 bg-[#0B111C] border-l border-slate-800/90 flex-col h-full"
              >
                <div className="px-4 py-3 border-b border-slate-800/90 flex items-center justify-between">
                  <div>
                    <div className="text-xs font-semibold text-slate-100">
                      Backend Audit Trail
                    </div>
                    <div className="text-[11px] font-mono text-slate-400">
                      data/audit.log ({auditLog.length} events)
                    </div>
                  </div>
                  <button
                    type="button"
                    onClick={() => setInspectorOpen(false)}
                    className="p-1 rounded text-slate-400 hover:text-slate-100"
                    aria-label="Hide backend inspector"
                  >
                    <X className="w-3.5 h-3.5" />
                  </button>
                </div>

                <div className="flex-1 overflow-y-auto divide-y divide-slate-800/70">
                  {auditLog.length === 0 ? (
                    <div className="p-5 text-xs text-slate-500 text-center">
                      Perform any action (add, renew, import, snapshot, or corrupt test) to record live backend disk events.
                    </div>
                  ) : (
                    auditLog.map((evt) => {
                      const isErr = evt.statusCode >= 400;
                      const isWarn = evt.action === 'CORRUPT_RECOVERY';
                      return (
                        <div key={evt.id} className="p-3.5 text-xs space-y-1">
                          <div className="flex items-center justify-between gap-2 font-mono">
                            <span
                              className={`font-semibold text-[11px] ${
                                isErr
                                  ? 'text-rose-400'
                                  : isWarn
                                  ? 'text-amber-400'
                                  : 'text-teal-400'
                              }`}
                            >
                              {evt.action}
                            </span>
                            <span className="text-[10px] text-slate-500 tabular-nums">
                              {evt.method} · {evt.statusCode}
                            </span>
                          </div>
                          <p className="text-slate-300 leading-snug">{evt.detail}</p>
                          <div className="text-[10px] font-mono text-slate-500 tabular-nums">
                            {new Date(evt.timestamp).toLocaleTimeString()} · {evt.endpoint}
                          </div>
                        </div>
                      );
                    })
                  )}
                </div>
              </aside>
            )}
          </div>
        </div>

        <FloatingCliWindow
          open={floatingCliOpen}
          minimized={floatingCliMinimized}
          onMinimize={() => setFloatingCliMinimized(true)}
          onClose={() => setFloatingCliOpen(false)}
          onExpandToTab={() => {
            setFloatingCliOpen(false);
            selectPrimaryView('terminal');
          }}
          enriched={enriched}
          summary={summary}
          settings={settings}
          onQuickRefresh={loadWorkspaceData}
        />

        <SubscriptionFormModal
          open={modalOpen}
          editingRecord={editingRecord}
          onClose={() => {
            setModalOpen(false);
            setEditingRecord(null);
          }}
          onSubmit={handleCreateOrUpdate}
        />
      </div>
    </MotionConfig>
  );
}
