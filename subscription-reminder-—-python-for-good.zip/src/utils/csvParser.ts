import type { BulkImportRowResult, SubscriptionRecord } from '../types/subscription.ts';
import { validateSubscriptionInput } from './validation.ts';

function splitCsvLine(line: string): string[] {
  const fields: string[] = [];
  let current = '';
  let inQuotes = false;

  for (let i = 0; i < line.length; i++) {
    const ch = line[i];
    if (ch === '"') {
      if (inQuotes && line[i + 1] === '"') {
        current += '"';
        i++;
      } else {
        inQuotes = !inQuotes;
      }
    } else if (ch === ',' && !inQuotes) {
      fields.push(current);
      current = '';
    } else {
      current += ch;
    }
  }
  fields.push(current);
  return fields;
}

export function parseAndValidateBulkCsv(csvText: string): {
  results: BulkImportRowResult[];
  acceptedRecords: SubscriptionRecord[];
} {
  const rawLines = csvText
    .replace(/\r\n/g, '\n')
    .replace(/\r/g, '\n')
    .split('\n')
    .filter((l) => l.trim().length > 0);

  if (rawLines.length === 0) {
    return { results: [], acceptedRecords: [] };
  }

  const headerFields = splitCsvLine(rawLines[0]).map((h) => h.trim().toLowerCase());
  const hasHeader =
    headerFields.includes('name') &&
    (headerFields.includes('cost') || headerFields.includes('renewaldate') || headerFields.includes('renewal_date'));

  const dataStartIndex = hasHeader ? 1 : 0;

  // Map column indexes dynamically if header exists, else default order:
  // name,category,cost,billingCycle,renewalDate,autoRenew,notes
  const colIndex = {
    name: hasHeader ? headerFields.indexOf('name') : 0,
    category: hasHeader ? headerFields.indexOf('category') : 1,
    cost: hasHeader ? headerFields.indexOf('cost') : 2,
    billingCycle: hasHeader
      ? headerFields.findIndex((h) => h === 'billingcycle' || h === 'billing_cycle' || h === 'cycle')
      : 3,
    renewalDate: hasHeader
      ? headerFields.findIndex((h) => h === 'renewaldate' || h === 'renewal_date' || h === 'date')
      : 4,
    autoRenew: hasHeader
      ? headerFields.findIndex((h) => h === 'autorenew' || h === 'auto_renew')
      : 5,
    notes: hasHeader ? headerFields.indexOf('notes') : 6,
  };

  const results: BulkImportRowResult[] = [];
  const acceptedRecords: SubscriptionRecord[] = [];
  const nowIso = new Date().toISOString();

  for (let i = dataStartIndex; i < rawLines.length; i++) {
    const line = rawLines[i];
    const rowNum = i + 1;
    const cells = splitCsvLine(line);

    if (cells.length < 5) {
      results.push({
        rowNumber: rowNum,
        rawLine: line,
        status: 'rejected',
        errors: [
          `Expected at least 5 CSV columns (name, category, cost, billingCycle, renewalDate), found ${cells.length}.`,
        ],
      });
      continue;
    }

    const getCell = (idx: number, fallback = '') => (idx >= 0 && idx < cells.length ? cells[idx] : fallback);
    const autoRaw = getCell(colIndex.autoRenew, 'true').trim().toLowerCase();
    const autoRenew = autoRaw !== 'false' && autoRaw !== '0' && autoRaw !== 'no';

    const validation = validateSubscriptionInput({
      name: getCell(colIndex.name),
      category: getCell(colIndex.category),
      cost: getCell(colIndex.cost),
      billingCycle: getCell(colIndex.billingCycle),
      renewalDate: getCell(colIndex.renewalDate),
      autoRenew,
      notes: getCell(colIndex.notes),
    });

    if (!validation.valid || !validation.sanitized) {
      results.push({
        rowNumber: rowNum,
        rawLine: line,
        status: 'rejected',
        errors: Object.values(validation.errors).filter((e): e is string => Boolean(e)),
        sanitizedName: getCell(colIndex.name).trim() || '(blank)',
      });
      continue;
    }

    const record: SubscriptionRecord = {
      id: `sub-${Date.now().toString(36)}-${i}`,
      ...validation.sanitized,
      createdAt: nowIso,
      updatedAt: nowIso,
    };

    acceptedRecords.push(record);
    results.push({
      rowNumber: rowNum,
      rawLine: line,
      status: 'accepted',
      errors: [],
      sanitizedName: record.name,
      record,
    });
  }

  return { results, acceptedRecords };
}
