import {
  SUBSCRIPTION_CATEGORIES,
  type BillingCycle,
  type CategorySummary,
  type EnrichedSubscription,
  type ExecutiveSummary,
  type MonthlyProjection,
  type RenewalStatus,
  type SubscriptionRecord,
  type ThresholdSettings,
  type ThresholdWarning,
} from '../types/subscription.ts';

export const DEFAULT_THRESHOLD_SETTINGS: ThresholdSettings = {
  monthlyBudgetLimit: 450,
  dueSoonDays: 7,
  anomalyMultiplier: 2.5,
  currencySymbol: '$',
};

export function toMonthlyEquivalent(cost: number, cycle: BillingCycle): number {
  switch (cycle) {
    case 'Weekly':
      return (cost * 52) / 12;
    case 'Monthly':
      return cost;
    case 'Quarterly':
      return cost / 3;
    case 'Annual':
      return cost / 12;
  }
}

export function toAnnualEquivalent(cost: number, cycle: BillingCycle): number {
  switch (cycle) {
    case 'Weekly':
      return cost * 52;
    case 'Monthly':
      return cost * 12;
    case 'Quarterly':
      return cost * 4;
    case 'Annual':
      return cost;
  }
}

export function computeDaysUntil(renewalDate: string, referenceDate: Date = new Date()): number {
  const [y, m, d] = renewalDate.split('-').map(Number);
  const targetUtc = Date.UTC(y, m - 1, d);
  const todayUtc = Date.UTC(
    referenceDate.getUTCFullYear(),
    referenceDate.getUTCMonth(),
    referenceDate.getUTCDate()
  );
  return Math.round((targetUtc - todayUtc) / (1000 * 60 * 60 * 24));
}

export function advanceRenewalDate(renewalDate: string, cycle: BillingCycle): string {
  const [y, m, d] = renewalDate.split('-').map(Number);
  const dt = new Date(Date.UTC(y, m - 1, d));
  switch (cycle) {
    case 'Weekly':
      dt.setUTCDate(dt.getUTCDate() + 7);
      break;
    case 'Monthly':
      dt.setUTCMonth(dt.getUTCMonth() + 1);
      break;
    case 'Quarterly':
      dt.setUTCMonth(dt.getUTCMonth() + 3);
      break;
    case 'Annual':
      dt.setUTCFullYear(dt.getUTCFullYear() + 1);
      break;
  }
  return dt.toISOString().slice(0, 10);
}

export function formatCurrency(amount: number, symbol: string = '$'): string {
  return `${symbol}${amount.toLocaleString('en-US', {
    minimumFractionDigits: 2,
    maximumFractionDigits: 2,
  })}`;
}

export function analyzeSubscriptions(
  records: SubscriptionRecord[],
  settings: ThresholdSettings = DEFAULT_THRESHOLD_SETTINGS,
  referenceDate: Date = new Date()
): { enriched: EnrichedSubscription[]; summary: ExecutiveSummary } {
  if (records.length === 0) {
    return {
      enriched: [],
      summary: {
        totalCount: 0,
        totalMonthlySpend: 0,
        totalAnnualSpend: 0,
        averageMonthlyCost: 0,
        medianMonthlyCost: 0,
        minMonthlyCost: 0,
        maxMonthlyCost: 0,
        overdueCount: 0,
        overdueTotalCost: 0,
        dueSoonCount: 0,
        dueSoonTotalCost: 0,
        activeCount: 0,
        budgetUtilizationPercent: 0,
        anomalyThreshold: 0,
        categoryBreakdown: [],
        monthlyProjections: buildEmptyProjections(referenceDate),
        warnings: [],
      },
    };
  }

  const monthlyValues = records.map((r) => toMonthlyEquivalent(r.cost, r.billingCycle));
  const totalMonthlySpend = monthlyValues.reduce((sum, v) => sum + v, 0);
  const totalAnnualSpend = records.reduce(
    (sum, r) => sum + toAnnualEquivalent(r.cost, r.billingCycle),
    0
  );
  const averageMonthlyCost = totalMonthlySpend / records.length;
  const sortedMonthly = [...monthlyValues].sort((a, b) => a - b);
  const mid = Math.floor(sortedMonthly.length / 2);
  const medianMonthlyCost =
    sortedMonthly.length % 2 === 0
      ? (sortedMonthly[mid - 1] + sortedMonthly[mid]) / 2
      : sortedMonthly[mid];
  const minMonthlyCost = sortedMonthly[0];
  const maxMonthlyCost = sortedMonthly[sortedMonthly.length - 1];
  const anomalyThreshold = Math.max(averageMonthlyCost * settings.anomalyMultiplier, 40);

  const enriched: EnrichedSubscription[] = records.map((r) => {
    const monthlyEquivalent = toMonthlyEquivalent(r.cost, r.billingCycle);
    const annualEquivalent = toAnnualEquivalent(r.cost, r.billingCycle);
    const daysUntilRenewal = computeDaysUntil(r.renewalDate, referenceDate);
    let status: RenewalStatus = 'Active';
    if (daysUntilRenewal < 0) {
      status = 'Overdue';
    } else if (daysUntilRenewal <= settings.dueSoonDays) {
      status = 'Due Soon';
    }
    const isAnomaly = monthlyEquivalent >= anomalyThreshold;
    return {
      ...r,
      monthlyEquivalent,
      annualEquivalent,
      daysUntilRenewal,
      status,
      isAnomaly,
    };
  });

  const overdueItems = enriched.filter((r) => r.status === 'Overdue');
  const dueSoonItems = enriched.filter((r) => r.status === 'Due Soon');
  const activeItems = enriched.filter((r) => r.status === 'Active');

  // Category Breakdown
  const categoryBreakdown: CategorySummary[] = SUBSCRIPTION_CATEGORIES.map((category) => {
    const items = enriched.filter((r) => r.category === category);
    const monthlyTotal = items.reduce((sum, i) => sum + i.monthlyEquivalent, 0);
    const annualTotal = items.reduce((sum, i) => sum + i.annualEquivalent, 0);
    return {
      category,
      count: items.length,
      monthlyTotal,
      annualTotal,
      sharePercent: totalMonthlySpend > 0 ? (monthlyTotal / totalMonthlySpend) * 100 : 0,
    };
  })
    .filter((c) => c.count > 0)
    .sort((a, b) => b.monthlyTotal - a.monthlyTotal);

  // 12-Month Projected Cashflow
  const monthlyProjections = buildMonthlyProjections(enriched, referenceDate);

  // Threshold Warning Indicators
  const warnings: ThresholdWarning[] = [];
  const budgetUtilizationPercent =
    settings.monthlyBudgetLimit > 0
      ? (totalMonthlySpend / settings.monthlyBudgetLimit) * 100
      : 0;

  if (settings.monthlyBudgetLimit > 0 && totalMonthlySpend > settings.monthlyBudgetLimit) {
    const overBy = totalMonthlySpend - settings.monthlyBudgetLimit;
    warnings.push({
      id: 'warn-budget-breach',
      severity: 'critical',
      kind: 'budget',
      title: 'Monthly Budget Limit Breached',
      detail: `Normalized monthly spend (${formatCurrency(totalMonthlySpend, settings.currencySymbol)}) exceeds your ${formatCurrency(settings.monthlyBudgetLimit, settings.currencySymbol)} ceiling by ${formatCurrency(overBy, settings.currencySymbol)}.`,
      relatedIds: [],
    });
  } else if (budgetUtilizationPercent >= 85) {
    warnings.push({
      id: 'warn-budget-near',
      severity: 'warning',
      kind: 'budget',
      title: 'Approaching Monthly Budget Ceiling',
      detail: `At ${budgetUtilizationPercent.toFixed(1)}% of your ${formatCurrency(settings.monthlyBudgetLimit, settings.currencySymbol)} monthly budget cap.`,
      relatedIds: [],
    });
  }

  if (overdueItems.length > 0) {
    const overdueSum = overdueItems.reduce((s, i) => s + i.cost, 0);
    warnings.push({
      id: 'warn-overdue',
      severity: 'critical',
      kind: 'overdue',
      title: `${overdueItems.length} Overdue Renewal${overdueItems.length > 1 ? 's' : ''} Detected`,
      detail: `Unresolved renewals totaling ${formatCurrency(overdueSum, settings.currencySymbol)} (${overdueItems.map((i) => i.name).join(', ')}).`,
      relatedIds: overdueItems.map((i) => i.id),
    });
  }

  const anomalies = enriched.filter((r) => r.isAnomaly);
  if (anomalies.length > 0) {
    warnings.push({
      id: 'warn-anomaly',
      severity: 'warning',
      kind: 'anomaly',
      title: `${anomalies.length} High-Cost Outlier${anomalies.length > 1 ? 's' : ''} Flagged`,
      detail: `Exceeds ${settings.anomalyMultiplier}x average monthly cost (${formatCurrency(anomalyThreshold, settings.currencySymbol)}): ${anomalies.map((a) => `${a.name} (${formatCurrency(a.monthlyEquivalent, settings.currencySymbol)}/mo)`).join(', ')}.`,
      relatedIds: anomalies.map((i) => i.id),
    });
  }

  if (dueSoonItems.length > 0) {
    const dueSum = dueSoonItems.reduce((s, i) => s + i.cost, 0);
    warnings.push({
      id: 'warn-due-soon',
      severity: 'warning',
      kind: 'due_soon',
      title: `${dueSoonItems.length} Renewal${dueSoonItems.length > 1 ? 's' : ''} Due Within ${settings.dueSoonDays} Days`,
      detail: `Upcoming charges totaling ${formatCurrency(dueSum, settings.currencySymbol)} requiring review.`,
      relatedIds: dueSoonItems.map((i) => i.id),
    });
  }

  return {
    enriched,
    summary: {
      totalCount: records.length,
      totalMonthlySpend,
      totalAnnualSpend,
      averageMonthlyCost,
      medianMonthlyCost,
      minMonthlyCost,
      maxMonthlyCost,
      overdueCount: overdueItems.length,
      overdueTotalCost: overdueItems.reduce((s, i) => s + i.cost, 0),
      dueSoonCount: dueSoonItems.length,
      dueSoonTotalCost: dueSoonItems.reduce((s, i) => s + i.cost, 0),
      activeCount: activeItems.length,
      budgetUtilizationPercent,
      anomalyThreshold,
      categoryBreakdown,
      monthlyProjections,
      warnings,
    },
  };
}

function buildEmptyProjections(referenceDate: Date): MonthlyProjection[] {
  const result: MonthlyProjection[] = [];
  for (let i = 0; i < 12; i++) {
    const dt = new Date(Date.UTC(referenceDate.getUTCFullYear(), referenceDate.getUTCMonth() + i, 1));
    const monthKey = dt.toISOString().slice(0, 7);
    const monthLabel = dt.toLocaleDateString('en-US', { month: 'short', year: '2-digit', timeZone: 'UTC' });
    result.push({ monthKey, monthLabel, projectedSpend: 0, renewalCount: 0 });
  }
  return result;
}

function buildMonthlyProjections(
  records: EnrichedSubscription[],
  referenceDate: Date
): MonthlyProjection[] {
  const projections = buildEmptyProjections(referenceDate);
  const startMonthIndex = referenceDate.getUTCFullYear() * 12 + referenceDate.getUTCMonth();

  for (const record of records) {
    const [ry, rm] = record.renewalDate.split('-').map(Number);
    const anchorMonthIndex = ry * 12 + (rm - 1);

    for (let i = 0; i < 12; i++) {
      const targetIndex = startMonthIndex + i;
      const diff = targetIndex - anchorMonthIndex;
      let hitsMonth = false;
      let multiplier = 1;

      if (record.billingCycle === 'Monthly') {
        hitsMonth = true;
      } else if (record.billingCycle === 'Weekly') {
        hitsMonth = true;
        multiplier = 52 / 12;
      } else if (record.billingCycle === 'Quarterly') {
        hitsMonth = ((diff % 3) + 3) % 3 === 0;
      } else if (record.billingCycle === 'Annual') {
        hitsMonth = ((diff % 12) + 12) % 12 === 0;
      }

      if (hitsMonth) {
        projections[i].projectedSpend += record.cost * multiplier;
        projections[i].renewalCount += 1;
      }
    }
  }

  return projections;
}

export function generateMarkdownReport(
  enriched: EnrichedSubscription[],
  summary: ExecutiveSummary,
  settings: ThresholdSettings
): string {
  const today = new Date().toISOString().slice(0, 10);
  const lines: string[] = [
    `# Subscription Reminder — Executive Summary Report`,
    ``,
    `- **Generated:** ${today}`,
    `- **Total Active Records:** ${summary.totalCount}`,
    `- **Normalized Monthly Spend:** ${formatCurrency(summary.totalMonthlySpend, settings.currencySymbol)}`,
    `- **Annualized Projection:** ${formatCurrency(summary.totalAnnualSpend, settings.currencySymbol)}`,
    `- **Budget Limit (${formatCurrency(settings.monthlyBudgetLimit, settings.currencySymbol)}/mo):** ${summary.budgetUtilizationPercent.toFixed(1)}% utilized`,
    `- **Average / Median Monthly Cost:** ${formatCurrency(summary.averageMonthlyCost, settings.currencySymbol)} / ${formatCurrency(summary.medianMonthlyCost, settings.currencySymbol)}`,
    ``,
    `## Threshold Warning Indicators`,
    ``,
  ];

  if (summary.warnings.length === 0) {
    lines.push(`- All subscriptions nominal. No threshold breaches detected.`);
  } else {
    for (const w of summary.warnings) {
      lines.push(`- **[${w.severity.toUpperCase()}] ${w.title}**: ${w.detail}`);
    }
  }

  lines.push(``, `## Category Spend Breakdown`, ``, `| Category | Count | Monthly Equivalent | Annual Projection | Share |`, `| --- | ---: | ---: | ---: | ---: |`);
  for (const cat of summary.categoryBreakdown) {
    lines.push(
      `| ${cat.category} | ${cat.count} | ${formatCurrency(cat.monthlyTotal, settings.currencySymbol)} | ${formatCurrency(cat.annualTotal, settings.currencySymbol)} | ${cat.sharePercent.toFixed(1)}% |`
    );
  }

  lines.push(``, `## Subscription Ledger`, ``, `| Name | Category | Cycle | Cost | Renewal Date | Status |`, `| --- | --- | --- | ---: | --- | --- |`);
  const sorted = [...enriched].sort((a, b) => a.daysUntilRenewal - b.daysUntilRenewal);
  for (const r of sorted) {
    const statusLabel =
      r.daysUntilRenewal < 0
        ? `Overdue (${Math.abs(r.daysUntilRenewal)}d)`
        : r.daysUntilRenewal === 0
        ? 'Due Today'
        : `${r.status} (${r.daysUntilRenewal}d)`;
    lines.push(
      `| ${r.name} | ${r.category} | ${r.billingCycle} | ${formatCurrency(r.cost, settings.currencySymbol)} | ${r.renewalDate} | ${statusLabel} |`
    );
  }

  return lines.join('\n');
}

export function generatePlainTextAuditLog(
  enriched: EnrichedSubscription[],
  summary: ExecutiveSummary,
  settings: ThresholdSettings
): string {
  const pad = (str: string, width: number, alignRight = false) => {
    const s = str.length > width ? `${str.slice(0, width - 1)}~` : str;
    return alignRight ? s.padStart(width, ' ') : s.padEnd(width, ' ');
  };

  const sep = '+--------------------------+-------------------+-----------+------------+------------+-------------+';
  const lines: string[] = [
    '====================================================================================================',
    '  SUBSCRIPTION REMINDER (PROJECT #16: PYTHON FOR GOOD) — PLAIN-TEXT AUDIT LOG',
    `  Timestamp: ${new Date().toISOString()}`,
    '====================================================================================================',
    '',
    `  Total Records       : ${summary.totalCount}`,
    `  Monthly Run Rate    : ${formatCurrency(summary.totalMonthlySpend, settings.currencySymbol)}`,
    `  Annual Projection   : ${formatCurrency(summary.totalAnnualSpend, settings.currencySymbol)}`,
    `  Budget Utilization  : ${summary.budgetUtilizationPercent.toFixed(1)}% of ${formatCurrency(settings.monthlyBudgetLimit, settings.currencySymbol)}`,
    `  Overdue / Due Soon  : ${summary.overdueCount} Overdue / ${summary.dueSoonCount} Due Soon`,
    '',
    '  THRESHOLD WARNINGS:',
  ];

  if (summary.warnings.length === 0) {
    lines.push('    [OK] No threshold violations recorded.');
  } else {
    for (const w of summary.warnings) {
      lines.push(`    [${w.severity.toUpperCase()}] ${w.title} -> ${w.detail}`);
    }
  }

  lines.push(
    '',
    sep,
    `| ${pad('Subscription Name', 24)} | ${pad('Category', 17)} | ${pad('Cycle', 9)} | ${pad('Cost', 10, true)} | ${pad('Renewal', 10)} | ${pad('Status', 11)} |`,
    sep
  );

  const sorted = [...enriched].sort((a, b) => a.daysUntilRenewal - b.daysUntilRenewal);
  for (const r of sorted) {
    const statusText =
      r.daysUntilRenewal < 0
        ? `OVERDUE ${Math.abs(r.daysUntilRenewal)}d`
        : r.daysUntilRenewal === 0
        ? 'DUE TODAY'
        : r.daysUntilRenewal <= settings.dueSoonDays
        ? `DUE IN ${r.daysUntilRenewal}d`
        : `IN ${r.daysUntilRenewal}d`;
    lines.push(
      `| ${pad(r.name, 24)} | ${pad(r.category, 17)} | ${pad(r.billingCycle, 9)} | ${pad(formatCurrency(r.cost, settings.currencySymbol), 10, true)} | ${pad(r.renewalDate, 10)} | ${pad(statusText, 11)} |`
    );
  }
  lines.push(sep);
  return lines.join('\n');
}

export function serializeRecordsToCsv(records: SubscriptionRecord[]): string {
  const escapeField = (val: string | number | boolean) => {
    const str = String(val ?? '');
    if (str.includes(',') || str.includes('"') || str.includes('\n')) {
      return `"${str.replace(/"/g, '""')}"`;
    }
    return str;
  };
  const header = 'id,name,category,cost,billingCycle,renewalDate,autoRenew,notes';
  const rows = records.map((r) =>
    [
      escapeField(r.id),
      escapeField(r.name),
      escapeField(r.category),
      r.cost.toFixed(2),
      escapeField(r.billingCycle),
      escapeField(r.renewalDate),
      String(r.autoRenew),
      escapeField(r.notes ?? ''),
    ].join(',')
  );
  return [header, ...rows].join('\n');
}
