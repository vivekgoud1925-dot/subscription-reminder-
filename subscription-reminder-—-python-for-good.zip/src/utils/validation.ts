import {
  BILLING_CYCLES,
  SUBSCRIPTION_CATEGORIES,
  type BillingCycle,
  type SubscriptionCategory,
  type SubscriptionInput,
  type ValidationResult,
  type ValidationRuleCheck,
} from '../types/subscription.ts';

const DATE_REGEX = /^\d{4}-\d{2}-\d{2}$/;
const NAME_ALLOWED_REGEX = /^[a-zA-Z0-9\s\-_&+./()']+$/;
const NUMERIC_ONLY_REGEX = /^\d+$/;

export function sanitizeText(value: string): string {
  return value.replace(/\s+/g, ' ').trim();
}

export function sanitizeCsvCell(value: string): string {
  const cleaned = sanitizeText(value);
  if (/^[=+\-@]/.test(cleaned)) {
    return `'${cleaned}`;
  }
  return cleaned;
}

export function isValidCalendarDate(dateStr: string): { valid: boolean; reason?: string } {
  const trimmed = dateStr.trim();
  if (!DATE_REGEX.test(trimmed)) {
    return { valid: false, reason: 'Must follow ISO format YYYY-MM-DD (e.g., 2026-12-15).' };
  }

  const [yearStr, monthStr, dayStr] = trimmed.split('-');
  const year = Number(yearStr);
  const month = Number(monthStr);
  const day = Number(dayStr);

  if (year < 2000 || year > 2035) {
    return { valid: false, reason: 'Year must fall within valid range 2000–2035.' };
  }
  if (month < 1 || month > 12) {
    return { valid: false, reason: 'Month must be between 01 and 12.' };
  }

  const dateObj = new Date(Date.UTC(year, month - 1, day));
  if (
    dateObj.getUTCFullYear() !== year ||
    dateObj.getUTCMonth() !== month - 1 ||
    dateObj.getUTCDate() !== day
  ) {
    return { valid: false, reason: `Calendar date ${trimmed} does not exist (invalid day for month).` };
  }

  return { valid: true };
}

export function parseCostInput(raw: string | number): { valid: boolean; value?: number; reason?: string } {
  if (typeof raw === 'number') {
    if (!Number.isFinite(raw)) {
      return { valid: false, reason: 'Cost must be a finite number.' };
    }
    if (raw <= 0 || raw > 10000) {
      return { valid: false, reason: 'Cost must be greater than $0.00 and at most $10,000.00.' };
    }
    return { valid: true, value: Math.round(raw * 100) / 100 };
  }

  const stripped = raw.trim().replace(/[$,]/g, '');
  if (!stripped) {
    return { valid: false, reason: 'Cost cannot be blank.' };
  }
  if (!/^-?\d+(\.\d+)?$/.test(stripped)) {
    return { valid: false, reason: 'Cost must be a valid numeric decimal (e.g., 14.99).' };
  }

  const parsed = Number(stripped);
  if (!Number.isFinite(parsed) || parsed <= 0) {
    return { valid: false, reason: 'Cost must be strictly greater than $0.00.' };
  }
  if (parsed > 10000) {
    return { valid: false, reason: 'Cost exceeds single-entry safety ceiling ($10,000.00).' };
  }

  const decimalParts = stripped.split('.');
  if (decimalParts[1] && decimalParts[1].length > 2) {
    return { valid: false, reason: 'Cost supports at most 2 decimal places (cents).' };
  }

  return { valid: true, value: Math.round(parsed * 100) / 100 };
}

export function matchBillingCycle(raw: string): BillingCycle | null {
  const normalized = sanitizeText(raw).toLowerCase();
  const found = BILLING_CYCLES.find((c) => c.toLowerCase() === normalized);
  return found ?? null;
}

export function matchCategory(raw: string): SubscriptionCategory | null {
  const normalized = sanitizeText(raw).toLowerCase();
  const found = SUBSCRIPTION_CATEGORIES.find((c) => c.toLowerCase() === normalized);
  return found ?? null;
}

export function validateSubscriptionInput(input: SubscriptionInput): ValidationResult {
  const errors: ValidationResult['errors'] = {};
  const checks: ValidationRuleCheck[] = [];

  // 1. Name
  const cleanName = sanitizeText(input.name ?? '');
  let nameValid = true;
  let nameMsg = 'Valid subscription name (trimmed, 2–60 chars).';
  if (!cleanName) {
    nameValid = false;
    nameMsg = 'Subscription name cannot be empty or whitespace.';
  } else if (cleanName.length < 2 || cleanName.length > 60) {
    nameValid = false;
    nameMsg = 'Name length must be between 2 and 60 characters.';
  } else if (NUMERIC_ONLY_REGEX.test(cleanName)) {
    nameValid = false;
    nameMsg = 'Name cannot consist solely of digits.';
  } else if (!NAME_ALLOWED_REGEX.test(cleanName)) {
    nameValid = false;
    nameMsg = 'Name contains unsupported special characters.';
  }
  if (!nameValid) errors.name = nameMsg;
  checks.push({ field: 'name', label: 'Name Sanitization & Regex', passed: nameValid, message: nameMsg });

  // 2. Cost
  const costCheck = parseCostInput(input.cost);
  const costMsg = costCheck.valid
    ? `Valid positive currency amount ($${costCheck.value!.toFixed(2)} <= $10,000).`
    : costCheck.reason!;
  if (!costCheck.valid) errors.cost = costMsg;
  checks.push({ field: 'cost', label: 'Numeric Range ($0.01–$10,000)', passed: costCheck.valid, message: costMsg });

  // 3. Renewal Date
  const cleanDate = (input.renewalDate ?? '').trim();
  const dateCheck = isValidCalendarDate(cleanDate);
  const dateMsg = dateCheck.valid
    ? `Valid ISO calendar date (${cleanDate}).`
    : dateCheck.reason!;
  if (!dateCheck.valid) errors.renewalDate = dateMsg;
  checks.push({ field: 'renewalDate', label: 'ISO Date & Calendar Check', passed: dateCheck.valid, message: dateMsg });

  // 4. Billing Cycle
  const matchedCycle = matchBillingCycle(input.billingCycle ?? '');
  const cycleValid = matchedCycle !== null;
  const cycleMsg = cycleValid
    ? `Recognized cadence (${matchedCycle}).`
    : `Must be one of: ${BILLING_CYCLES.join(', ')}.`;
  if (!cycleValid) errors.billingCycle = cycleMsg;
  checks.push({ field: 'billingCycle', label: 'Billing Cycle Enum', passed: cycleValid, message: cycleMsg });

  // 5. Category
  const matchedCat = matchCategory(input.category ?? '');
  const catValid = matchedCat !== null;
  const catMsg = catValid
    ? `Valid category (${matchedCat}).`
    : `Must be one of: ${SUBSCRIPTION_CATEGORIES.join(', ')}.`;
  if (!catValid) errors.category = catMsg;
  checks.push({ field: 'category', label: 'Category Classification', passed: catValid, message: catMsg });

  // 6. Notes
  const cleanNotes = sanitizeText(input.notes ?? '');
  if (cleanNotes.length > 180) {
    errors.notes = 'Notes cannot exceed 180 characters.';
  }

  const valid = Object.keys(errors).length === 0;
  return {
    valid,
    errors,
    checks,
    ...(valid && matchedCat && matchedCycle && costCheck.value !== undefined
      ? {
          sanitized: {
            name: cleanName,
            category: matchedCat,
            cost: costCheck.value,
            billingCycle: matchedCycle,
            renewalDate: cleanDate,
            autoRenew: input.autoRenew ?? true,
            notes: cleanNotes,
          },
        }
      : {}),
  };
}
