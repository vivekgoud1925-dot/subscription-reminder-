export const BILLING_CYCLES = ['Monthly', 'Annual', 'Quarterly', 'Weekly'] as const;
export type BillingCycle = (typeof BILLING_CYCLES)[number];

export const SUBSCRIPTION_CATEGORIES = [
  'Cloud & Dev',
  'Streaming & Media',
  'Productivity',
  'Education',
  'Fitness & Health',
  'News & Reading',
  'Security & VPN',
  'Utilities',
] as const;
export type SubscriptionCategory = (typeof SUBSCRIPTION_CATEGORIES)[number];

export type RenewalStatus = 'Overdue' | 'Due Soon' | 'Active';

export type NavView =
  | 'overview'
  | 'animation'
  | 'ledger'
  | 'terminal'
  | 'analytics'
  | 'exports'
  | 'presentation';

export interface SubscriptionRecord {
  id: string;
  name: string;
  category: SubscriptionCategory;
  cost: number;
  billingCycle: BillingCycle;
  renewalDate: string; // YYYY-MM-DD
  autoRenew: boolean;
  notes?: string;
  createdAt: string;
  updatedAt: string;
}

export interface SubscriptionInput {
  name: string;
  category: string;
  cost: string | number;
  billingCycle: string;
  renewalDate: string;
  autoRenew?: boolean;
  notes?: string;
}

export interface ValidationRuleCheck {
  field: 'name' | 'cost' | 'renewalDate' | 'billingCycle' | 'category';
  label: string;
  passed: boolean;
  message: string;
}

export interface ValidationResult {
  valid: boolean;
  errors: Partial<Record<'name' | 'cost' | 'renewalDate' | 'billingCycle' | 'category' | 'notes', string>>;
  checks: ValidationRuleCheck[];
  sanitized?: {
    name: string;
    category: SubscriptionCategory;
    cost: number;
    billingCycle: BillingCycle;
    renewalDate: string;
    autoRenew: boolean;
    notes: string;
  };
}

export interface ThresholdSettings {
  monthlyBudgetLimit: number;
  dueSoonDays: number;
  anomalyMultiplier: number;
  currencySymbol: string;
}

export interface EnrichedSubscription extends SubscriptionRecord {
  monthlyEquivalent: number;
  annualEquivalent: number;
  daysUntilRenewal: number;
  status: RenewalStatus;
  isAnomaly: boolean;
}

export interface CategorySummary {
  category: SubscriptionCategory;
  count: number;
  monthlyTotal: number;
  annualTotal: number;
  sharePercent: number;
}

export interface MonthlyProjection {
  monthKey: string;
  monthLabel: string;
  projectedSpend: number;
  renewalCount: number;
}

export interface ThresholdWarning {
  id: string;
  severity: 'critical' | 'warning';
  kind: 'budget' | 'overdue' | 'anomaly' | 'due_soon';
  title: string;
  detail: string;
  relatedIds: string[];
}

export interface ExecutiveSummary {
  totalCount: number;
  totalMonthlySpend: number;
  totalAnnualSpend: number;
  averageMonthlyCost: number;
  medianMonthlyCost: number;
  minMonthlyCost: number;
  maxMonthlyCost: number;
  overdueCount: number;
  overdueTotalCost: number;
  dueSoonCount: number;
  dueSoonTotalCost: number;
  activeCount: number;
  budgetUtilizationPercent: number;
  anomalyThreshold: number;
  categoryBreakdown: CategorySummary[];
  monthlyProjections: MonthlyProjection[];
  warnings: ThresholdWarning[];
}

export interface BulkImportRowResult {
  rowNumber: number;
  rawLine: string;
  status: 'accepted' | 'rejected';
  errors: string[];
  sanitizedName?: string;
  record?: SubscriptionRecord;
}

export interface StorageRecoveryEvent {
  recovered: boolean;
  reason?: string;
  timestamp: string;
  recordCount: number;
}

export interface StorageFilesSnapshot {
  jsonPath: string;
  csvPath: string;
  jsonContent: string;
  csvContent: string;
  recordCount: number;
  lastModified: string;
}

export interface DiskStats {
  jsonBytes: number;
  csvBytes: number;
  auditLogBytes: number;
  backupCount: number;
  exportFileCount: number;
  lastSavedAt: string;
}

export interface BackupSnapshot {
  filename: string;
  createdAt: string;
  sizeBytes: number;
  recordCount: number;
}

export interface BackendAuditEntry {
  id: string;
  timestamp: string;
  action: string;
  method: string;
  endpoint: string;
  statusCode: number;
  detail: string;
}

export interface WorkspacePayload {
  records: SubscriptionRecord[];
  enriched: EnrichedSubscription[];
  summary: ExecutiveSummary;
  settings: ThresholdSettings;
  diskStats: DiskStats;
  backups: BackupSnapshot[];
  auditLog: BackendAuditEntry[];
  recovery: StorageRecoveryEvent | null;
}
