export const PYTHON_MAIN_SOURCE = `#!/usr/bin/env python3
"""
Subscription Reminder — Project #16: Python for Good
Domain: Finance & Personal Management
Features:
  - Interactive ANSI terminal menu with guided workflows
  - Defensive input validation (regex, range bounds, calendar checks)
  - Local JSON & CSV persistence with FileNotFoundError / JSONDecodeError recovery
  - Paginated fixed-width ASCII tabular output
  - Executive summary metrics & threshold warning indicators
  - Matplotlib visual chart generation (category share & 12-month forecast)
  - Multi-format exports (Markdown, Plain-Text Audit Log, CSV)
  - Bulk legacy CSV import with row-by-row error log
"""

from __future__ import annotations

import csv
import json
import math
import os
import re
import statistics
from dataclasses import asdict, dataclass
from datetime import date, datetime, timedelta
from pathlib import Path
from typing import Dict, List, Optional, Tuple

try:
    import matplotlib.pyplot as plt
    HAS_MATPLOTLIB = True
except ImportError:
    HAS_MATPLOTLIB = False

DATA_DIR = Path("data")
JSON_PATH = DATA_DIR / "subscriptions.json"
CSV_PATH = DATA_DIR / "subscriptions.csv"
EXPORT_DIR = Path("exports")

BILLING_CYCLES = ("Monthly", "Annual", "Quarterly", "Weekly")
CATEGORIES = (
    "Cloud & Dev",
    "Streaming & Media",
    "Productivity",
    "Education",
    "Fitness & Health",
    "News & Reading",
    "Security & VPN",
    "Utilities",
)

NAME_PATTERN = re.compile(r"^[a-zA-Z0-9\\s\\-_&+./()']{2,60}$")
DATE_PATTERN = re.compile(r"^\\d{4}-\\d{2}-\\d{2}$")

ANSI_RESET = "\\033[0m"
ANSI_BOLD = "\\033[1m"
ANSI_CYAN = "\\033[96m"
ANSI_GREEN = "\\033[92m"
ANSI_YELLOW = "\\033[93m"
ANSI_RED = "\\033[91m"


@dataclass
class Subscription:
    id: str
    name: str
    category: str
    cost: float
    billing_cycle: str
    renewal_date: str
    auto_renew: bool = True
    notes: str = ""

    def monthly_equivalent(self) -> float:
        if self.billing_cycle == "Weekly":
            return (self.cost * 52.0) / 12.0
        if self.billing_cycle == "Quarterly":
            return self.cost / 3.0
        if self.billing_cycle == "Annual":
            return self.cost / 12.0
        return self.cost

    def days_until_renewal(self, ref: Optional[date] = None) -> int:
        ref_date = ref or date.today()
        target = datetime.strptime(self.renewal_date, "%Y-%m-%d").date()
        return (target - ref_date).days


# ---------------------------------------------------------------------------
# Defensive Input Validation Wrappers
# ---------------------------------------------------------------------------

def sanitize_text(raw: str) -> str:
    return re.sub(r"\\s+", " ", raw).strip()


def validate_name(raw: str) -> Tuple[bool, str]:
    clean = sanitize_text(raw)
    if not clean:
        return False, "Name cannot be empty or whitespace."
    if clean.isdigit():
        return False, "Name cannot consist solely of digits."
    if not NAME_PATTERN.match(clean):
        return False, "Name must be 2-60 valid characters."
    return True, clean


def validate_cost(raw: str) -> Tuple[bool, Optional[float], str]:
    cleaned = raw.strip().replace("$", "").replace(",", "")
    if not cleaned:
        return False, None, "Cost cannot be blank."
    try:
        value = float(cleaned)
    except ValueError:
        return False, None, "Cost must be a valid number (e.g., 14.99)."
    if not math.isfinite(value) or value <= 0 or value > 10000:
        return False, None, "Cost must be greater than $0.00 and <= $10,000.00."
    return True, round(value, 2), "OK"


def validate_date(raw: str) -> Tuple[bool, str]:
    cleaned = raw.strip()
    if not DATE_PATTERN.match(cleaned):
        return False, "Date must follow YYYY-MM-DD format."
    try:
        parsed = datetime.strptime(cleaned, "%Y-%m-%d").date()
    except ValueError:
        return False, f"Calendar date '{cleaned}' does not exist."
    if parsed.year < 2000 or parsed.year > 2035:
        return False, "Year must fall between 2000 and 2035."
    return True, cleaned


def prompt_validated(label: str, validator) -> str:
    while True:
        user_val = input(f"  {label}: ")
        ok, result = validator(user_val)
        if ok:
            return result
        print(f"  {ANSI_RED}[Validation Error]{ANSI_RESET} {result}")


# ---------------------------------------------------------------------------
# Persistence Layer with Automatic File Corruption Recovery
# ---------------------------------------------------------------------------

def ensure_storage() -> List[Subscription]:
    DATA_DIR.mkdir(parents=True, exist_ok=True)
    try:
        raw_text = JSON_PATH.read_text(encoding="utf-8")
        payload = json.loads(raw_text)
        if not isinstance(payload, list):
            raise ValueError("Root JSON payload is not a list")
        return [Subscription(**item) for item in payload]
    except (FileNotFoundError, json.JSONDecodeError, TypeError, ValueError) as exc:
        print(
            f"{ANSI_YELLOW}[Storage Recovery]{ANSI_RESET} "
            f"Recovered from '{type(exc).__name__}'; initializing clean storage."
        )
        save_records([])
        return []


def save_records(records: List[Subscription]) -> None:
    DATA_DIR.mkdir(parents=True, exist_ok=True)
    JSON_PATH.write_text(
        json.dumps([asdict(r) for r in records], indent=2),
        encoding="utf-8",
    )
    with CSV_PATH.open("w", newline="", encoding="utf-8") as handle:
        writer = csv.DictWriter(
            handle,
            fieldnames=[
                "id", "name", "category", "cost",
                "billing_cycle", "renewal_date", "auto_renew", "notes",
            ],
        )
        writer.writeheader()
        for r in records:
            writer.writerow(asdict(r))


# ---------------------------------------------------------------------------
# Executive Summary, Warnings & Matplotlib Plots
# ---------------------------------------------------------------------------

def generate_summary(records: List[Subscription], monthly_budget: float = 450.0) -> Dict:
    if not records:
        return {"count": 0, "monthly_total": 0.0, "annual_total": 0.0, "warnings": []}

    monthly_vals = [r.monthly_equivalent() for r in records]
    monthly_total = sum(monthly_vals)
    avg_cost = statistics.mean(monthly_vals)
    overdue = [r for r in records if r.days_until_renewal() < 0]
    due_soon = [r for r in records if 0 <= r.days_until_renewal() <= 7]

    warnings: List[str] = []
    if monthly_total > monthly_budget:
        warnings.append(
            f"BUDGET BREACH: Monthly spend \${monthly_total:.2f} exceeds \${monthly_budget:.2f} limit."
        )
    if overdue:
        warnings.append(f"OVERDUE: {len(overdue)} subscription(s) require immediate renewal.")
    if due_soon:
        warnings.append(f"DUE SOON: {len(due_soon)} subscription(s) renew within 7 days.")

    return {
        "count": len(records),
        "monthly_total": monthly_total,
        "annual_total": monthly_total * 12.0,
        "average": avg_cost,
        "median": statistics.median(monthly_vals),
        "overdue": len(overdue),
        "due_soon": len(due_soon),
        "warnings": warnings,
    }


def export_charts(records: List[Subscription]) -> None:
    if not HAS_MATPLOTLIB:
        print(f"{ANSI_YELLOW}[Fallback]{ANSI_RESET} Matplotlib not installed; skipping PNG charts.")
        return
    if not records:
        print("No records available to plot.")
        return

    EXPORT_DIR.mkdir(parents=True, exist_ok=True)
    by_category: Dict[str, float] = {}
    for r in records:
        by_category[r.category] = by_category.get(r.category, 0.0) + r.monthly_equivalent()

    cats = sorted(by_category.keys(), key=lambda c: by_category[c], reverse=True)
    vals = [by_category[c] for c in cats]

    fig, ax = plt.subplots(figsize=(9, 4.5))
    ax.barh(cats, vals, color="#1D4ED8")
    ax.invert_yaxis()
    ax.set_xlabel("Normalized Monthly Spend (USD)")
    ax.set_title("Subscription Reminder — Monthly Cost by Category")
    plt.tight_layout()
    chart_file = EXPORT_DIR / "category_spend.png"
    fig.savefig(chart_file, dpi=150)
    plt.close(fig)
    print(f"{ANSI_GREEN}[Saved]{ANSI_RESET} Matplotlib chart exported to {chart_file}")


def print_paginated_table(records: List[Subscription], page_size: int = 10) -> None:
    if not records:
        print("  No subscription records stored yet.")
        return

    sep = "+------------------------+-------------------+-----------+----------+------------+------------+"
    for start in range(0, len(records), page_size):
        chunk = records[start:start + page_size]
        print(sep)
        print(
            f"| {'Name':<22} | {'Category':<17} | {'Cycle':<9} | {'Cost':>8} | {'Renewal':<10} | {'Status':<10} |"
        )
        print(sep)
        for r in chunk:
            days = r.days_until_renewal()
            status = f"OVERDUE" if days < 0 else ("DUE SOON" if days <= 7 else f"IN {days}d")
            print(
                f"| {r.name[:22]:<22} | {r.category[:17]:<17} | {r.billing_cycle:<9} | "
                f"\${r.cost:>7.2f} | {r.renewal_date:<10} | {status:<10} |"
            )
        print(sep)
        if start + page_size < len(records):
            cmd = input("  Press [Enter] for next page or 'q' to stop: ").strip().lower()
            if cmd == "q":
                break


def main() -> None:
    print(f"{ANSI_BOLD}{ANSI_CYAN}=== SUBSCRIPTION REMINDER (PYTHON FOR GOOD #16) ==={ANSI_RESET}")
    records = ensure_storage()

    while True:
        print("\\n  [1] Add Subscription   [2] View Records   [3] Executive Summary")
        print("  [4] Export Matplotlib Chart   [0] Save & Exit")
        choice = input("\\n  Select option > ").strip()

        if choice == "1":
            name = prompt_validated("Subscription Name", validate_name)
            while True:
                ok, cost, msg = validate_cost(input("  Cost (USD): "))
                if ok and cost is not None:
                    break
                print(f"  {ANSI_RED}[Validation Error]{ANSI_RESET} {msg}")
            renewal = prompt_validated("Renewal Date (YYYY-MM-DD)", validate_date)
            cycle = input(f"  Billing Cycle {BILLING_CYCLES} [Monthly]: ").strip() or "Monthly"
            if cycle not in BILLING_CYCLES:
                cycle = "Monthly"
            category = input(f"  Category {CATEGORIES} [Utilities]: ").strip() or "Utilities"
            if category not in CATEGORIES:
                category = "Utilities"

            rec = Subscription(
                id=f"sub-{int(datetime.now().timestamp())}",
                name=name,
                category=category,
                cost=cost,
                billing_cycle=cycle,
                renewal_date=renewal,
            )
            records.append(rec)
            save_records(records)
            print(f"  {ANSI_GREEN}[Saved]{ANSI_RESET} '{rec.name}' persisted to JSON & CSV.")
        elif choice == "2":
            print_paginated_table(records)
        elif choice == "3":
            summary = generate_summary(records)
            print(f"\\n  Total Records: {summary['count']}")
            print(f"  Monthly Spend: \${summary['monthly_total']:.2f}")
            print(f"  Annual Spend : \${summary['annual_total']:.2f}")
            for w in summary["warnings"]:
                print(f"  {ANSI_YELLOW}[WARNING]{ANSI_RESET} {w}")
        elif choice == "4":
            export_charts(records)
        elif choice == "0":
            save_records(records)
            print("  State saved to disk. Goodbye!")
            break
        else:
            print(f"  {ANSI_RED}Invalid option.{ANSI_RESET} Enter 0–4.")


if __name__ == "__main__":
    main()
`;

export const PYTHON_REQUIREMENTS = `matplotlib>=3.8.0
`;

export const PYTHON_README = `# Project #16: Subscription Reminder (Python for Good)

## Overview
A fault-tolerant Subscription Reminder application built with Python 3.10+ standard library and Matplotlib for personal finance tracking, defensive input validation, local JSON/CSV persistence, threshold warning indicators, and multi-format report generation.

## Quick Start (Python CLI)
\`\`\`bash
python3 -m venv .venv
source .venv/bin/activate
pip install -r requirements.txt
python3 subscription_reminder.py
\`\`\`

## Core Capabilities Demonstrated
1. **Interactive Menu-Driven Terminal**: Guided numeric menu loop with ANSI status feedback.
2. **Defensive Input Validation**: Regex name checks, numeric cost bounds ($0.01–$10,000), and strict ISO calendar verification (rejects invalid dates like \`2026-02-30\`).
3. **Local Persistence & Recovery**: Synchronizes \`data/subscriptions.json\` and \`data/subscriptions.csv\` on every mutation, recovering cleanly from \`FileNotFoundError\` or \`JSONDecodeError\`.
4. **Executive Analytics & Warnings**: Computes normalized monthly/annualized run rates, overdue counts, cost outliers, and budget ceiling breaches.
5. **Visual Plotting & Multi-Format Exports**: Exports Matplotlib category spend charts plus Markdown, plain-text audit logs, CSV, and JSON.
`;
