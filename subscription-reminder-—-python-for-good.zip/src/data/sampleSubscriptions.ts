import type { BillingCycle, SubscriptionCategory, SubscriptionRecord } from '../types/subscription.ts';

function addDaysIso(baseDate: Date, offsetDays: number): string {
  const d = new Date(Date.UTC(baseDate.getUTCFullYear(), baseDate.getUTCMonth(), baseDate.getUTCDate() + offsetDays));
  return d.toISOString().slice(0, 10);
}

interface SeedSpec {
  id: string;
  name: string;
  category: SubscriptionCategory;
  cost: number;
  billingCycle: BillingCycle;
  offsetDays: number;
  autoRenew: boolean;
  notes: string;
}

const SAMPLE_SPECS: SeedSpec[] = [
  // Overdue test cases (edge conditions)
  { id: 'sub-101', name: 'Adobe Creative Cloud', category: 'Productivity', cost: 59.99, billingCycle: 'Monthly', offsetDays: -11, autoRenew: false, notes: 'Overdue invoice - card expired' },
  { id: 'sub-102', name: 'AWS Personal Sandbox', category: 'Cloud & Dev', cost: 18.45, billingCycle: 'Monthly', offsetDays: -4, autoRenew: true, notes: 'EC2 + S3 lab buckets' },
  { id: 'sub-103', name: 'The Economist Digital', category: 'News & Reading', cost: 24.00, billingCycle: 'Monthly', offsetDays: -1, autoRenew: false, notes: 'Verify student discount renewal' },

  // Due Soon (0 to 7 days)
  { id: 'sub-104', name: 'GitHub Copilot Pro', category: 'Cloud & Dev', cost: 10.00, billingCycle: 'Monthly', offsetDays: 0, autoRenew: true, notes: 'Due today - coding assistant' },
  { id: 'sub-105', name: 'Spotify Duo', category: 'Streaming & Media', cost: 16.99, billingCycle: 'Monthly', offsetDays: 2, autoRenew: true, notes: 'Shared music plan' },
  { id: 'sub-106', name: 'Coursera Plus', category: 'Education', cost: 59.00, billingCycle: 'Monthly', offsetDays: 3, autoRenew: true, notes: 'Python & ML specialization' },
  { id: 'sub-107', name: 'Notion Plus', category: 'Productivity', cost: 12.00, billingCycle: 'Monthly', offsetDays: 5, autoRenew: true, notes: 'College notes workspace' },
  { id: 'sub-108', name: 'Proton VPN Plus', category: 'Security & VPN', cost: 9.99, billingCycle: 'Monthly', offsetDays: 6, autoRenew: true, notes: 'Campus Wi-Fi protection' },
  { id: 'sub-109', name: 'Vercel Pro Hosting', category: 'Cloud & Dev', cost: 20.00, billingCycle: 'Monthly', offsetDays: 7, autoRenew: true, notes: 'Portfolio deployment tier' },

  // Normal Active Monthly / Weekly / Quarterly / Annual entries (36 total)
  { id: 'sub-110', name: 'Netflix Standard', category: 'Streaming & Media', cost: 15.49, billingCycle: 'Monthly', offsetDays: 10, autoRenew: true, notes: 'No-ads HD plan' },
  { id: 'sub-111', name: 'iCloud+ 200GB', category: 'Cloud & Dev', cost: 2.99, billingCycle: 'Monthly', offsetDays: 12, autoRenew: true, notes: 'Phone backup storage' },
  { id: 'sub-112', name: 'Google One 100GB', category: 'Cloud & Dev', cost: 1.99, billingCycle: 'Monthly', offsetDays: 14, autoRenew: true, notes: 'Drive & Photos' },
  { id: 'sub-113', name: 'ChatGPT Plus', category: 'Productivity', cost: 20.00, billingCycle: 'Monthly', offsetDays: 15, autoRenew: true, notes: 'Research drafting' },
  { id: 'sub-114', name: '1Password Families', category: 'Security & VPN', cost: 4.99, billingCycle: 'Monthly', offsetDays: 16, autoRenew: true, notes: 'Credential vault' },
  { id: 'sub-115', name: 'Campus Gym Membership', category: 'Fitness & Health', cost: 34.50, billingCycle: 'Monthly', offsetDays: 18, autoRenew: true, notes: 'Rec center access' },
  { id: 'sub-116', name: 'Figma Professional', category: 'Productivity', cost: 15.00, billingCycle: 'Monthly', offsetDays: 19, autoRenew: true, notes: 'UI prototyping' },
  { id: 'sub-117', name: 'YouTube Premium Student', category: 'Streaming & Media', cost: 7.99, billingCycle: 'Monthly', offsetDays: 21, autoRenew: true, notes: 'Ad-free lectures & music' },
  { id: 'sub-118', name: 'Strava Summit', category: 'Fitness & Health', cost: 11.99, billingCycle: 'Monthly', offsetDays: 22, autoRenew: false, notes: 'Marathon training logs' },
  { id: 'sub-119', name: 'NYTimes Academic', category: 'News & Reading', cost: 4.00, billingCycle: 'Monthly', offsetDays: 24, autoRenew: true, notes: 'Student news rate' },
  { id: 'sub-120', name: 'Headspace Student', category: 'Fitness & Health', cost: 9.99, billingCycle: 'Annual', offsetDays: 26, autoRenew: true, notes: 'Boundary low annual student rate' },
  { id: 'sub-121', name: 'DigitalOcean Droplet', category: 'Cloud & Dev', cost: 12.00, billingCycle: 'Monthly', offsetDays: 28, autoRenew: true, notes: '2GB Flask test server' },
  { id: 'sub-122', name: 'Fresh Meal Prep Box', category: 'Utilities', cost: 14.50, billingCycle: 'Weekly', offsetDays: 4, autoRenew: true, notes: 'Weekly cadence boundary test' },
  { id: 'sub-123', name: 'Local Bike Share Pass', category: 'Utilities', cost: 5.00, billingCycle: 'Weekly', offsetDays: 9, autoRenew: true, notes: 'Weekly campus commute' },
  { id: 'sub-124', name: 'JetBrains All Products', category: 'Cloud & Dev', cost: 289.00, billingCycle: 'Annual', offsetDays: 45, autoRenew: false, notes: 'High annual boundary entry' },
  { id: 'sub-125', name: 'Cloudflare Registrar (.dev)', category: 'Cloud & Dev', cost: 12.18, billingCycle: 'Annual', offsetDays: 58, autoRenew: true, notes: 'Personal portfolio domain' },
  { id: 'sub-126', name: 'Medium Membership', category: 'News & Reading', cost: 50.00, billingCycle: 'Annual', offsetDays: 64, autoRenew: true, notes: 'Engineering articles' },
  { id: 'sub-127', name: 'O Reilly Learning', category: 'Education', cost: 139.00, billingCycle: 'Quarterly', offsetDays: 33, autoRenew: false, notes: 'Quarterly billing test' },
  { id: 'sub-128', name: 'Backblaze B2 Backup', category: 'Security & VPN', cost: 99.00, billingCycle: 'Annual', offsetDays: 72, autoRenew: true, notes: 'Laptop full backup' },
  { id: 'sub-129', name: 'Bitwarden Premium', category: 'Security & VPN', cost: 10.00, billingCycle: 'Annual', offsetDays: 88, autoRenew: true, notes: '2FA authenticator backup' },
  { id: 'sub-130', name: 'Amazon Prime Student', category: 'Utilities', cost: 69.00, billingCycle: 'Annual', offsetDays: 96, autoRenew: true, notes: 'Textbooks & delivery' },
  { id: 'sub-131', name: 'Substack Tech Newsletter', category: 'News & Reading', cost: 15.00, billingCycle: 'Quarterly', offsetDays: 41, autoRenew: true, notes: 'Systems design digest' },
  { id: 'sub-132', name: 'Linear Standard', category: 'Productivity', cost: 8.00, billingCycle: 'Monthly', offsetDays: 29, autoRenew: true, notes: 'Capstone issue tracker' },
  { id: 'sub-133', name: 'DataCamp Annual', category: 'Education', cost: 149.00, billingCycle: 'Annual', offsetDays: 112, autoRenew: false, notes: 'Python data tracks' },
  { id: 'sub-134', name: 'Micro Archive Tier', category: 'Cloud & Dev', cost: 0.99, billingCycle: 'Monthly', offsetDays: 20, autoRenew: true, notes: 'Minimum $0.99 boundary test' },
  { id: 'sub-135', name: 'Enterprise Lab Suite', category: 'Cloud & Dev', cost: 185.00, billingCycle: 'Monthly', offsetDays: 17, autoRenew: false, notes: 'Anomalous high monthly cost test' },
  { id: 'sub-136', name: 'Readwise Reader', category: 'News & Reading', cost: 23.97, billingCycle: 'Quarterly', offsetDays: 52, autoRenew: true, notes: 'Paper highlights sync' },
];

export function buildSampleSubscriptions(referenceDate: Date = new Date()): SubscriptionRecord[] {
  const nowIso = referenceDate.toISOString();
  return SAMPLE_SPECS.map((spec) => ({
    id: spec.id,
    name: spec.name,
    category: spec.category,
    cost: spec.cost,
    billingCycle: spec.billingCycle,
    renewalDate: addDaysIso(referenceDate, spec.offsetDays),
    autoRenew: spec.autoRenew,
    notes: spec.notes,
    createdAt: nowIso,
    updatedAt: nowIso,
  }));
}

export const SAMPLE_LEGACY_CSV_WITH_ERRORS = `name,category,cost,billingCycle,renewalDate,autoRenew,notes
"GitKraken Pro",Cloud & Dev,4.95,Monthly,2026-12-10,true,"Git GUI license"
"   ",Productivity,12.00,Monthly,2026-12-12,true,"Blank name should fail"
"Bad Date Service",Utilities,19.99,Monthly,2026-02-30,true,"Invalid Feb 30 calendar date"
"Negative Cost Plan",Education,-15.00,Monthly,2026-12-20,false,"Negative cost boundary check"
"Dropbox Plus",Cloud & Dev,$11.99,Monthly,2026-12-18,true,"Sanitizes dollar sign cleanly"
"Invalid Cycle App",Productivity,9.99,BiWeekly,2026-12-22,true,"Unsupported billing cycle"
"Disney Plus Bundle",Streaming & Media,14.99,Monthly,2026-12-28,true,"Valid streaming entry"`;
