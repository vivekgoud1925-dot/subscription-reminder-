import express from 'express';
import fs from 'fs';
import path from 'path';
import { createServer as createViteServer } from 'vite';
import { buildSampleSubscriptions } from './src/data/sampleSubscriptions.ts';
import type {
  BackendAuditEntry,
  BackupSnapshot,
  DiskStats,
  StorageRecoveryEvent,
  SubscriptionRecord,
  ThresholdSettings,
  WorkspacePayload,
} from './src/types/subscription.ts';
import {
  advanceRenewalDate,
  analyzeSubscriptions,
  DEFAULT_THRESHOLD_SETTINGS,
  generateMarkdownReport,
  generatePlainTextAuditLog,
  serializeRecordsToCsv,
} from './src/utils/analytics.ts';
import { parseAndValidateBulkCsv } from './src/utils/csvParser.ts';
import { validateSubscriptionInput } from './src/utils/validation.ts';

const PORT = Number(process.env.PORT || 3000);
const DATA_DIR = path.resolve(process.cwd(), 'data');
const BACKUP_DIR = path.join(DATA_DIR, 'backups');
const EXPORT_DIR = path.resolve(process.cwd(), 'exports');
const JSON_FILE = path.join(DATA_DIR, 'subscriptions.json');
const CSV_FILE = path.join(DATA_DIR, 'subscriptions.csv');
const SETTINGS_FILE = path.join(DATA_DIR, 'settings.json');
const AUDIT_FILE = path.join(DATA_DIR, 'audit.log');

function ensureDirs(): void {
  if (!fs.existsSync(DATA_DIR)) fs.mkdirSync(DATA_DIR, { recursive: true });
  if (!fs.existsSync(BACKUP_DIR)) fs.mkdirSync(BACKUP_DIR, { recursive: true });
  if (!fs.existsSync(EXPORT_DIR)) fs.mkdirSync(EXPORT_DIR, { recursive: true });
}

function appendAuditEntry(
  action: string,
  method: string,
  endpoint: string,
  statusCode: number,
  detail: string
): void {
  ensureDirs();
  const entry: BackendAuditEntry = {
    id: `evt-${Date.now().toString(36)}-${Math.random().toString(36).slice(2, 5)}`,
    timestamp: new Date().toISOString(),
    action,
    method,
    endpoint,
    statusCode,
    detail,
  };
  fs.appendFileSync(AUDIT_FILE, `${JSON.stringify(entry)}\n`, 'utf-8');
}

function readAuditEntries(limit = 40): BackendAuditEntry[] {
  ensureDirs();
  if (!fs.existsSync(AUDIT_FILE)) return [];
  try {
    const lines = fs
      .readFileSync(AUDIT_FILE, 'utf-8')
      .split('\n')
      .filter((l) => l.trim().length > 0);
    const parsed: BackendAuditEntry[] = [];
    for (let i = lines.length - 1; i >= 0 && parsed.length < limit; i--) {
      try {
        parsed.push(JSON.parse(lines[i]) as BackendAuditEntry);
      } catch {
        // Ignore malformed log line
      }
    }
    return parsed;
  } catch {
    return [];
  }
}

function createDiskBackup(records: SubscriptionRecord[], tag = 'auto'): BackupSnapshot {
  ensureDirs();
  const stamp = new Date().toISOString().replace(/[:.]/g, '-');
  const filename = `subscriptions_${tag}_${stamp}.json`;
  const target = path.join(BACKUP_DIR, filename);
  const content = JSON.stringify(records, null, 2);
  fs.writeFileSync(target, content, 'utf-8');

  // Retain latest 15 backups
  const all = fs
    .readdirSync(BACKUP_DIR)
    .filter((f) => f.endsWith('.json'))
    .sort()
    .reverse();
  for (const old of all.slice(15)) {
    try {
      fs.unlinkSync(path.join(BACKUP_DIR, old));
    } catch {
      // Ignore cleanup error
    }
  }

  return {
    filename,
    createdAt: new Date().toISOString(),
    sizeBytes: Buffer.byteLength(content, 'utf-8'),
    recordCount: records.length,
  };
}

function listBackups(): BackupSnapshot[] {
  ensureDirs();
  const files = fs
    .readdirSync(BACKUP_DIR)
    .filter((f) => f.endsWith('.json'))
    .sort()
    .reverse();

  return files.map((filename) => {
    const full = path.join(BACKUP_DIR, filename);
    const stat = fs.statSync(full);
    let recordCount = 0;
    try {
      const parsed = JSON.parse(fs.readFileSync(full, 'utf-8'));
      if (Array.isArray(parsed)) recordCount = parsed.length;
    } catch {
      recordCount = 0;
    }
    return {
      filename,
      createdAt: stat.mtime.toISOString(),
      sizeBytes: stat.size,
      recordCount,
    };
  });
}

function writeSubscriptionsToDisk(records: SubscriptionRecord[]): void {
  ensureDirs();
  fs.writeFileSync(JSON_FILE, JSON.stringify(records, null, 2), 'utf-8');
  fs.writeFileSync(CSV_FILE, serializeRecordsToCsv(records), 'utf-8');
}

function loadSubscriptionsWithRecovery(): {
  records: SubscriptionRecord[];
  recovery: StorageRecoveryEvent | null;
} {
  ensureDirs();
  if (!fs.existsSync(JSON_FILE)) {
    const seeded = buildSampleSubscriptions();
    writeSubscriptionsToDisk(seeded);
    createDiskBackup(seeded, 'init');
    appendAuditEntry(
      'STORAGE_INIT',
      'SYSTEM',
      '/data/subscriptions.json',
      200,
      `Initialized missing storage with ${seeded.length} sample records.`
    );
    return {
      records: seeded,
      recovery: {
        recovered: true,
        reason: 'FileNotFoundError: subscriptions.json was missing. Seeded 36 validated sample records.',
        timestamp: new Date().toISOString(),
        recordCount: seeded.length,
      },
    };
  }

  try {
    const raw = fs.readFileSync(JSON_FILE, 'utf-8');
    const parsed = JSON.parse(raw);
    if (!Array.isArray(parsed)) {
      throw new Error('SchemaError: Root JSON structure is not an array.');
    }
    const validRecords: SubscriptionRecord[] = [];
    for (const item of parsed) {
      if (item && typeof item.name === 'string' && typeof item.cost === 'number' && typeof item.renewalDate === 'string') {
        validRecords.push(item as SubscriptionRecord);
      }
    }
    if (!fs.existsSync(CSV_FILE)) {
      fs.writeFileSync(CSV_FILE, serializeRecordsToCsv(validRecords), 'utf-8');
    }
    return { records: validRecords, recovery: null };
  } catch (err) {
    const message = err instanceof Error ? err.message : 'Unknown JSON parse failure';
    const fallback = buildSampleSubscriptions();
    writeSubscriptionsToDisk(fallback);
    appendAuditEntry(
      'CORRUPT_RECOVERY',
      'SYSTEM',
      '/data/subscriptions.json',
      200,
      `Caught JSONDecodeError (${message}); rebuilt clean JSON & CSV templates.`
    );
    return {
      records: fallback,
      recovery: {
        recovered: true,
        reason: `JSONDecodeError (${message}): Automatically rebuilt clean JSON and CSV storage templates.`,
        timestamp: new Date().toISOString(),
        recordCount: fallback.length,
      },
    };
  }
}

function loadSettings(): ThresholdSettings {
  ensureDirs();
  if (!fs.existsSync(SETTINGS_FILE)) {
    fs.writeFileSync(SETTINGS_FILE, JSON.stringify(DEFAULT_THRESHOLD_SETTINGS, null, 2), 'utf-8');
    return DEFAULT_THRESHOLD_SETTINGS;
  }
  try {
    const raw = fs.readFileSync(SETTINGS_FILE, 'utf-8');
    const parsed = JSON.parse(raw) as Partial<ThresholdSettings>;
    return {
      monthlyBudgetLimit:
        typeof parsed.monthlyBudgetLimit === 'number' && parsed.monthlyBudgetLimit > 0
          ? parsed.monthlyBudgetLimit
          : DEFAULT_THRESHOLD_SETTINGS.monthlyBudgetLimit,
      dueSoonDays:
        typeof parsed.dueSoonDays === 'number' && parsed.dueSoonDays >= 1
          ? parsed.dueSoonDays
          : DEFAULT_THRESHOLD_SETTINGS.dueSoonDays,
      anomalyMultiplier:
        typeof parsed.anomalyMultiplier === 'number' && parsed.anomalyMultiplier >= 1.2
          ? parsed.anomalyMultiplier
          : DEFAULT_THRESHOLD_SETTINGS.anomalyMultiplier,
      currencySymbol: typeof parsed.currencySymbol === 'string' ? parsed.currencySymbol : '$',
    };
  } catch {
    fs.writeFileSync(SETTINGS_FILE, JSON.stringify(DEFAULT_THRESHOLD_SETTINGS, null, 2), 'utf-8');
    return DEFAULT_THRESHOLD_SETTINGS;
  }
}

function getDiskStats(): DiskStats {
  ensureDirs();
  const jsonStat = fs.existsSync(JSON_FILE) ? fs.statSync(JSON_FILE) : null;
  const csvStat = fs.existsSync(CSV_FILE) ? fs.statSync(CSV_FILE) : null;
  const auditStat = fs.existsSync(AUDIT_FILE) ? fs.statSync(AUDIT_FILE) : null;
  const backupCount = fs.readdirSync(BACKUP_DIR).filter((f) => f.endsWith('.json')).length;
  const exportFileCount = fs.readdirSync(EXPORT_DIR).length;

  return {
    jsonBytes: jsonStat?.size ?? 0,
    csvBytes: csvStat?.size ?? 0,
    auditLogBytes: auditStat?.size ?? 0,
    backupCount,
    exportFileCount,
    lastSavedAt: jsonStat ? jsonStat.mtime.toISOString() : new Date().toISOString(),
  };
}

function buildWorkspacePayload(recovery: StorageRecoveryEvent | null = null): WorkspacePayload {
  const loaded = loadSubscriptionsWithRecovery();
  const settings = loadSettings();
  const { enriched, summary } = analyzeSubscriptions(loaded.records, settings);
  return {
    records: loaded.records,
    enriched,
    summary,
    settings,
    diskStats: getDiskStats(),
    backups: listBackups(),
    auditLog: readAuditEntries(40),
    recovery: recovery ?? loaded.recovery,
  };
}

async function startServer(): Promise<void> {
  const app = express();
  app.use(express.json({ limit: '2mb' }));

  // Ensure initial storage exists on boot
  loadSubscriptionsWithRecovery();
  loadSettings();

  // Unified Backend-Computed Workspace Endpoint
  app.get('/api/workspace', (_req, res) => {
    res.json(buildWorkspacePayload());
  });

  app.get('/api/subscriptions', (req, res) => {
    const { records, recovery } = loadSubscriptionsWithRecovery();
    const settings = loadSettings();
    const { enriched } = analyzeSubscriptions(records, settings);

    const q = typeof req.query.q === 'string' ? req.query.q.trim().toLowerCase() : '';
    const category = typeof req.query.category === 'string' ? req.query.category : '';
    const status = typeof req.query.status === 'string' ? req.query.status : '';

    const filtered = enriched.filter((item) => {
      if (category && category !== 'All' && item.category !== category) return false;
      if (status && status !== 'All' && item.status !== status) return false;
      if (q) {
        const hay = `${item.name} ${item.category} ${item.notes ?? ''} ${item.billingCycle}`.toLowerCase();
        if (!hay.includes(q)) return false;
      }
      return true;
    });

    res.json({ records: filtered, totalCount: records.length, recovery });
  });

  app.post('/api/subscriptions', (req, res) => {
    const validation = validateSubscriptionInput(req.body ?? {});
    if (!validation.valid || !validation.sanitized) {
      appendAuditEntry(
        'VALIDATION_REJECTED',
        'POST',
        '/api/subscriptions',
        400,
        `Rejected invalid input: ${Object.values(validation.errors).join('; ')}`
      );
      res.status(400).json({ error: 'Defensive validation failed', errors: validation.errors });
      return;
    }
    const { records } = loadSubscriptionsWithRecovery();
    const now = new Date().toISOString();
    const created: SubscriptionRecord = {
      id: `sub-${Date.now().toString(36)}-${Math.random().toString(36).slice(2, 6)}`,
      ...validation.sanitized,
      createdAt: now,
      updatedAt: now,
    };
    const next = [created, ...records];
    writeSubscriptionsToDisk(next);
    appendAuditEntry(
      'CREATE_RECORD',
      'POST',
      '/api/subscriptions',
      201,
      `Created '${created.name}' ($${created.cost.toFixed(2)}/${created.billingCycle}) -> synced JSON & CSV.`
    );
    res.status(201).json({ record: created, workspace: buildWorkspacePayload() });
  });

  app.put('/api/subscriptions/:id', (req, res) => {
    const { id } = req.params;
    const validation = validateSubscriptionInput(req.body ?? {});
    if (!validation.valid || !validation.sanitized) {
      appendAuditEntry(
        'VALIDATION_REJECTED',
        'PUT',
        `/api/subscriptions/${id}`,
        400,
        `Rejected update: ${Object.values(validation.errors).join('; ')}`
      );
      res.status(400).json({ error: 'Defensive validation failed', errors: validation.errors });
      return;
    }
    const { records } = loadSubscriptionsWithRecovery();
    const index = records.findIndex((r) => r.id === id);
    if (index === -1) {
      res.status(404).json({ error: 'Subscription record not found' });
      return;
    }
    const updated: SubscriptionRecord = {
      ...records[index],
      ...validation.sanitized,
      updatedAt: new Date().toISOString(),
    };
    const next = [...records];
    next[index] = updated;
    writeSubscriptionsToDisk(next);
    appendAuditEntry(
      'UPDATE_RECORD',
      'PUT',
      `/api/subscriptions/${id}`,
      200,
      `Updated '${updated.name}' ($${updated.cost.toFixed(2)}/${updated.billingCycle}, ${updated.renewalDate}).`
    );
    res.json({ record: updated, workspace: buildWorkspacePayload() });
  });

  app.post('/api/subscriptions/:id/renew', (req, res) => {
    const { id } = req.params;
    const { records } = loadSubscriptionsWithRecovery();
    const index = records.findIndex((r) => r.id === id);
    if (index === -1) {
      res.status(404).json({ error: 'Subscription record not found' });
      return;
    }
    const current = records[index];
    const nextDate = advanceRenewalDate(current.renewalDate, current.billingCycle);
    const updated: SubscriptionRecord = {
      ...current,
      renewalDate: nextDate,
      updatedAt: new Date().toISOString(),
    };
    const next = [...records];
    next[index] = updated;
    writeSubscriptionsToDisk(next);
    appendAuditEntry(
      'RENEW_CYCLE',
      'POST',
      `/api/subscriptions/${id}/renew`,
      200,
      `Advanced '${updated.name}' renewal date ${current.renewalDate} -> ${nextDate}.`
    );
    res.json({ record: updated, workspace: buildWorkspacePayload() });
  });

  app.post('/api/subscriptions/renew-overdue', (_req, res) => {
    const { records } = loadSubscriptionsWithRecovery();
    const settings = loadSettings();
    const { enriched } = analyzeSubscriptions(records, settings);
    const overdueIds = new Set(enriched.filter((r) => r.daysUntilRenewal < 0).map((r) => r.id));

    if (overdueIds.size === 0) {
      res.json({ renewedCount: 0, workspace: buildWorkspacePayload() });
      return;
    }

    createDiskBackup(records, 'pre-batch-renew');
    const now = new Date().toISOString();
    const next = records.map((r) =>
      overdueIds.has(r.id)
        ? { ...r, renewalDate: advanceRenewalDate(r.renewalDate, r.billingCycle), updatedAt: now }
        : r
    );
    writeSubscriptionsToDisk(next);
    appendAuditEntry(
      'BATCH_RENEW_OVERDUE',
      'POST',
      '/api/subscriptions/renew-overdue',
      200,
      `Created snapshot backup and advanced ${overdueIds.size} overdue subscription(s) by 1 cycle.`
    );
    res.json({ renewedCount: overdueIds.size, workspace: buildWorkspacePayload() });
  });

  app.delete('/api/subscriptions/:id', (req, res) => {
    const { id } = req.params;
    const { records } = loadSubscriptionsWithRecovery();
    const target = records.find((r) => r.id === id);
    if (!target) {
      res.status(404).json({ error: 'Subscription record not found' });
      return;
    }
    const next = records.filter((r) => r.id !== id);
    writeSubscriptionsToDisk(next);
    appendAuditEntry(
      'DELETE_RECORD',
      'DELETE',
      `/api/subscriptions/${id}`,
      200,
      `Removed '${target.name}' from JSON & CSV persistence.`
    );
    res.json({ deletedId: id, workspace: buildWorkspacePayload() });
  });

  app.post('/api/subscriptions/bulk', (req, res) => {
    const csvText = typeof req.body?.csvText === 'string' ? req.body.csvText : '';
    if (!csvText.trim()) {
      res.status(400).json({ error: 'CSV payload is empty.' });
      return;
    }
    const { results, acceptedRecords } = parseAndValidateBulkCsv(csvText);
    const { records } = loadSubscriptionsWithRecovery();
    const next = [...acceptedRecords, ...records];
    if (acceptedRecords.length > 0) {
      createDiskBackup(records, 'pre-bulk-import');
      writeSubscriptionsToDisk(next);
    }
    const rejectedCount = results.length - acceptedRecords.length;
    appendAuditEntry(
      'BULK_CSV_IMPORT',
      'POST',
      '/api/subscriptions/bulk',
      200,
      `Processed ${results.length} CSV rows: ${acceptedRecords.length} accepted, ${rejectedCount} rejected.`
    );
    res.json({
      results,
      importedCount: acceptedRecords.length,
      rejectedCount,
      workspace: buildWorkspacePayload(),
    });
  });

  // Disk Snapshots & Restore
  app.get('/api/storage/backups', (_req, res) => {
    res.json({ backups: listBackups() });
  });

  app.post('/api/storage/backups', (_req, res) => {
    const { records } = loadSubscriptionsWithRecovery();
    const snapshot = createDiskBackup(records, 'manual');
    appendAuditEntry(
      'SNAPSHOT_CREATED',
      'POST',
      '/api/storage/backups',
      201,
      `Created manual snapshot ${snapshot.filename} (${snapshot.recordCount} records, ${snapshot.sizeBytes} B).`
    );
    res.status(201).json({ snapshot, workspace: buildWorkspacePayload() });
  });

  app.post('/api/storage/restore/:filename', (req, res) => {
    const safeName = path.basename(req.params.filename);
    const full = path.join(BACKUP_DIR, safeName);
    if (!fs.existsSync(full)) {
      res.status(404).json({ error: 'Snapshot file not found' });
      return;
    }
    try {
      const parsed = JSON.parse(fs.readFileSync(full, 'utf-8'));
      if (!Array.isArray(parsed)) throw new Error('Invalid snapshot payload');
      writeSubscriptionsToDisk(parsed as SubscriptionRecord[]);
      appendAuditEntry(
        'SNAPSHOT_RESTORED',
        'POST',
        `/api/storage/restore/${safeName}`,
        200,
        `Restored ${parsed.length} records from ${safeName} -> synced JSON & CSV.`
      );
      res.json({ workspace: buildWorkspacePayload() });
    } catch {
      res.status(400).json({ error: 'Snapshot file is malformed' });
    }
  });

  app.post('/api/storage/seed', (_req, res) => {
    const { records } = loadSubscriptionsWithRecovery();
    if (records.length > 0) createDiskBackup(records, 'pre-seed');
    const seeded = buildSampleSubscriptions();
    writeSubscriptionsToDisk(seeded);
    appendAuditEntry(
      'SEED_DATASET',
      'POST',
      '/api/storage/seed',
      200,
      `Seeded ${seeded.length} sample entries (normal, overdue, due-soon, and boundary cases).`
    );
    res.json({ workspace: buildWorkspacePayload(), message: `Seeded ${seeded.length} sample records.` });
  });

  app.post('/api/storage/corrupt-test', (_req, res) => {
    ensureDirs();
    fs.writeFileSync(JSON_FILE, '{ "corrupted_json": [INVALID_TOKEN_EOF', 'utf-8');
    const { recovery } = loadSubscriptionsWithRecovery();
    res.json({ workspace: buildWorkspacePayload(recovery) });
  });

  app.get('/api/storage/files', (_req, res) => {
    const { records } = loadSubscriptionsWithRecovery();
    const jsonContent = fs.existsSync(JSON_FILE) ? fs.readFileSync(JSON_FILE, 'utf-8') : '[]';
    const csvContent = fs.existsSync(CSV_FILE) ? fs.readFileSync(CSV_FILE, 'utf-8') : '';
    const stat = fs.existsSync(JSON_FILE) ? fs.statSync(JSON_FILE) : null;
    res.json({
      jsonPath: 'data/subscriptions.json',
      csvPath: 'data/subscriptions.csv',
      jsonContent,
      csvContent,
      recordCount: records.length,
      lastModified: stat ? stat.mtime.toISOString() : new Date().toISOString(),
    });
  });

  // Server-Side Report Generation onto Disk (exports/)
  app.post('/api/exports/generate', (_req, res) => {
    ensureDirs();
    const { records } = loadSubscriptionsWithRecovery();
    const settings = loadSettings();
    const { enriched, summary } = analyzeSubscriptions(records, settings);

    const mdContent = generateMarkdownReport(enriched, summary, settings);
    const txtContent = generatePlainTextAuditLog(enriched, summary, settings);
    const csvContent = serializeRecordsToCsv(records);
    const jsonContent = JSON.stringify({ generatedAt: new Date().toISOString(), summary, records }, null, 2);

    fs.writeFileSync(path.join(EXPORT_DIR, 'executive_summary.md'), mdContent, 'utf-8');
    fs.writeFileSync(path.join(EXPORT_DIR, 'audit_log.txt'), txtContent, 'utf-8');
    fs.writeFileSync(path.join(EXPORT_DIR, 'subscriptions_export.csv'), csvContent, 'utf-8');
    fs.writeFileSync(path.join(EXPORT_DIR, 'report_bundle.json'), jsonContent, 'utf-8');

    appendAuditEntry(
      'EXPORT_GENERATED',
      'POST',
      '/api/exports/generate',
      200,
      'Wrote 4 report artifacts (.md, .txt, .csv, .json) to exports/ directory.'
    );
    res.json({
      files: ['executive_summary.md', 'audit_log.txt', 'subscriptions_export.csv', 'report_bundle.json'],
      workspace: buildWorkspacePayload(),
    });
  });

  app.get('/api/exports/download/:filename', (req, res) => {
    const safeName = path.basename(req.params.filename);
    const full = path.join(EXPORT_DIR, safeName);
    if (!fs.existsSync(full)) {
      res.status(404).json({ error: 'Export file not generated yet' });
      return;
    }
    res.download(full, safeName);
  });

  app.get('/api/settings', (_req, res) => {
    res.json({ settings: loadSettings() });
  });

  app.put('/api/settings', (req, res) => {
    const current = loadSettings();
    const body = req.body ?? {};
    const next: ThresholdSettings = {
      monthlyBudgetLimit:
        typeof body.monthlyBudgetLimit === 'number' && body.monthlyBudgetLimit >= 10 && body.monthlyBudgetLimit <= 100000
          ? Math.round(body.monthlyBudgetLimit * 100) / 100
          : current.monthlyBudgetLimit,
      dueSoonDays:
        typeof body.dueSoonDays === 'number' && body.dueSoonDays >= 1 && body.dueSoonDays <= 60
          ? Math.round(body.dueSoonDays)
          : current.dueSoonDays,
      anomalyMultiplier:
        typeof body.anomalyMultiplier === 'number' && body.anomalyMultiplier >= 1.2 && body.anomalyMultiplier <= 10
          ? Math.round(body.anomalyMultiplier * 10) / 10
          : current.anomalyMultiplier,
      currencySymbol: current.currencySymbol,
    };
    ensureDirs();
    fs.writeFileSync(SETTINGS_FILE, JSON.stringify(next, null, 2), 'utf-8');
    appendAuditEntry(
      'SETTINGS_UPDATED',
      'PUT',
      '/api/settings',
      200,
      `Threshold settings updated: $${next.monthlyBudgetLimit}/mo cap, ${next.dueSoonDays}d due window, ${next.anomalyMultiplier}x outlier.`
    );
    res.json({ settings: next, workspace: buildWorkspacePayload() });
  });

  if (process.env.NODE_ENV !== 'production') {
    const vite = await createViteServer({
      server: { middlewareMode: true },
      appType: 'spa',
    });
    app.use(vite.middlewares);
  } else {
    const distDir = path.resolve(process.cwd(), 'dist');
    app.use(express.static(distDir));
    app.get('/{*splat}', (_req, res) => {
      res.sendFile(path.join(distDir, 'index.html'));
    });
  }

  app.listen(PORT, '0.0.0.0', () => {
    console.log(`Subscription Reminder server listening on http://0.0.0.0:${PORT}`);
  });
}

startServer();
